<?php
/**
 * Admin Class — WP Content Writer AI Pro
 * Menu, Pages, Asset loading — Enhanced with SEO, Plugin KB, and more
 */

if (!defined('ABSPATH')) exit;

class WPCW_Admin {

    private $settings;
    private $api;
    /** @var WPCW_Provider_Manager */
    private $providers;

    public function __construct($settings, $api, $providers = null) {
        $this->settings  = $settings;
        $this->api       = $api;
        $this->providers = $providers instanceof WPCW_Provider_Manager ? $providers : new WPCW_Provider_Manager();
        add_action('admin_menu',             array($this, 'register_menu'));
        add_action('admin_init',             array($this, 'handle_actions'));
        add_action('admin_enqueue_scripts',  array($this, 'enqueue_assets'));
        add_action('admin_enqueue_scripts',  array($this, 'enqueue_global_notifier'));
    }

    public function register_menu() {
        add_menu_page(
            'Content Writer AI Pro',
            'AI Writer Pro',
            'edit_posts',
            'wp-content-writer',
            array($this, 'render_writer_page'),
            'dashicons-edit-page',
            4
        );

        add_submenu_page('wp-content-writer', 'Content Writer',  'Write Content',   'edit_posts',      'wp-content-writer',            array($this, 'render_writer_page'));
        add_submenu_page('wp-content-writer', 'SEO Analyzer',    'SEO Analyzer',    'edit_posts',      'wp-content-writer-seo',        array($this, 'render_seo_page'));
        add_submenu_page('wp-content-writer', 'Plugin Knowledge', 'Plugin KB (500+)','edit_posts',      'wp-content-writer-plugins',    array($this, 'render_plugins_page'));
        add_submenu_page('wp-content-writer', 'Website Analyzer', 'Website Analyzer','manage_options',  'wp-content-writer-site',       array($this, 'render_site_analyzer_page'));
        add_submenu_page('wp-content-writer', 'Site-Wide Changes','Site Changes',    'manage_options',  'wp-content-writer-changes',    array($this, 'render_site_changes_page'));
        add_submenu_page('wp-content-writer', 'AI Providers',    'AI Providers',    'manage_options',  'wp-content-writer-providers',  array($this, 'render_providers_page'));
        add_submenu_page('wp-content-writer', 'Usage Analytics', 'Usage Analytics', 'manage_options',  'wp-content-writer-usage',      array($this, 'render_usage_page'));
        add_submenu_page('wp-content-writer', 'License',         'License',         'manage_options',  'wp-content-writer-license',    array($this, 'render_license_page'));
        add_submenu_page('wp-content-writer', 'Settings',        'Settings',        'manage_options',  'wp-content-writer-settings',   array($this, 'render_settings_page'));
        add_submenu_page(null,                'Onboarding',      'Onboarding',      'manage_options',  'wp-content-writer-onboarding', array($this, 'render_onboarding_page'));
    }

    public function handle_actions() {
        if (!isset($_POST['wpcw_action']) || 'save_settings' !== $_POST['wpcw_action']) return;
        if (!current_user_can('manage_options')) return;
        check_admin_referer('wpcw_save_settings');

        // Save the non-secret settings first.
        $this->settings->update_settings(array(
            'ollama_url'       => isset($_POST['wpcw_ollama_url'])       ? esc_url_raw(wp_unslash($_POST['wpcw_ollama_url']))           : WPCW_Settings::DEFAULT_GROQ_API_BASE,
            'model'            => isset($_POST['wpcw_model'])            ? sanitize_text_field(wp_unslash($_POST['wpcw_model']))         : WPCW_Settings::DEFAULT_GROQ_MODEL,
            'host_header'      => isset($_POST['wpcw_host_header'])      ? sanitize_text_field(wp_unslash($_POST['wpcw_host_header']))   : '',
            'origin_header'    => isset($_POST['wpcw_origin_header'])    ? esc_url_raw(wp_unslash($_POST['wpcw_origin_header']))         : '',
            'request_timeout'  => isset($_POST['wpcw_request_timeout'])  ? absint($_POST['wpcw_request_timeout'])                        : 120,
            'default_language' => isset($_POST['wpcw_default_language']) ? sanitize_text_field(wp_unslash($_POST['wpcw_default_language'])) : 'Hindi',
            'default_tone'     => isset($_POST['wpcw_default_tone'])     ? sanitize_key(wp_unslash($_POST['wpcw_default_tone']))             : 'professional',
        ));

        // Persist the API key separately into the encrypted provider config.
        if (isset($_POST['wpcw_groq_api_key'])) {
            $key = trim((string) wp_unslash($_POST['wpcw_groq_api_key']));
            if ('' !== $key && 0 !== strpos($key, '••')) { // Ignore the masked placeholder shown in the UI.
                $data = $this->providers->get_settings_data();
                if (!isset($data['configs']['groq'])) $data['configs']['groq'] = array();
                $data['configs']['groq']['api_key']  = sanitize_text_field($key);
                $data['configs']['groq']['model']    = isset($_POST['wpcw_model']) ? sanitize_text_field(wp_unslash($_POST['wpcw_model'])) : '';
                $data['configs']['groq']['base_url'] = isset($_POST['wpcw_ollama_url']) ? esc_url_raw(wp_unslash($_POST['wpcw_ollama_url'])) : '';
                $this->providers->save_settings_data($data);
            }
        }

        wp_safe_redirect(add_query_arg(array('page' => 'wp-content-writer-settings', 'wpcw_saved' => 1), admin_url('admin.php')));
        exit;
    }

    public function enqueue_assets($hook) {
        $allowed_hooks = array(
            'toplevel_page_wp-content-writer',
            'ai-writer-pro_page_wp-content-writer-seo',
            'ai-writer-pro_page_wp-content-writer-plugins',
            'ai-writer-pro_page_wp-content-writer-site',
            'ai-writer-pro_page_wp-content-writer-changes',
            'ai-writer-pro_page_wp-content-writer-providers',
            'ai-writer-pro_page_wp-content-writer-usage',
            'ai-writer-pro_page_wp-content-writer-license',
            'ai-writer-pro_page_wp-content-writer-settings',
            'admin_page_wp-content-writer-onboarding',
        );
        if (!in_array($hook, $allowed_hooks, true)) return;

        wp_enqueue_style('dashicons');
        wp_enqueue_style('wpcw-admin', WP_CONTENT_WRITER_PLUGIN_URL . 'assets/css/admin.css', array(), WP_CONTENT_WRITER_VERSION);
        wp_enqueue_style('wpcw-saas',  WP_CONTENT_WRITER_PLUGIN_URL . 'assets/css/saas.css',  array(), WP_CONTENT_WRITER_VERSION);
        wp_enqueue_script('wpcw-admin', WP_CONTENT_WRITER_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), WP_CONTENT_WRITER_VERSION, true);

        // Marked.js for markdown rendering
        wp_enqueue_script('wpcw-marked', 'https://cdn.jsdelivr.net/npm/marked/marked.min.js', array(), '12.0.0', true);

        // SaaS pages also need Chart.js + the SaaS JS module.
        if (in_array($hook, array(
            'ai-writer-pro_page_wp-content-writer-usage',
            'ai-writer-pro_page_wp-content-writer-providers',
            'ai-writer-pro_page_wp-content-writer-license',
            'admin_page_wp-content-writer-onboarding',
        ), true)) {
            wp_enqueue_script('wpcw-chartjs', 'https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js', array(), '4.4.4', true);
            wp_enqueue_script('wpcw-saas',    WP_CONTENT_WRITER_PLUGIN_URL . 'assets/js/saas.js', array('jquery', 'wpcw-chartjs'), WP_CONTENT_WRITER_VERSION, true);
        }

        wp_localize_script('wpcw-admin', 'wpcwData', array(
            'restUrl'       => esc_url_raw(rest_url('wpcw/v1/')),
            'nonce'         => wp_create_nonce('wp_rest'),
            'templates'     => WPCW_Templates::get_all(),
            'tones'         => WPCW_Templates::get_tones(),
            'languages'     => WPCW_Templates::get_languages(),
            'groupIcons'    => WPCW_Templates::get_groups_with_icons(),
            'defLang'       => $this->settings->get_setting('default_language'),
            'defTone'       => $this->settings->get_setting('default_tone'),
            'seoPlugin'     => WPCW_SEO::get_active_seo_plugin(),
            'totalTemplates' => count(WPCW_Templates::get_all()),
            'totalPlugins'  => WPCW_Plugins_KB::get_total_count(),
            'currentPage'   => $hook,
        ));
    }

    /**
     * Global floating AI chat widget — loads on ALL admin pages
     */
    public function enqueue_global_notifier() {
        if (!current_user_can('edit_posts')) return;

        wp_enqueue_style('wpcw-chat', WP_CONTENT_WRITER_PLUGIN_URL . 'assets/css/chat-widget.css', array(), WP_CONTENT_WRITER_VERSION);
        wp_enqueue_script('wpcw-marked-global', 'https://cdn.jsdelivr.net/npm/marked/marked.min.js', array(), '12.0.0', true);
        wp_enqueue_script('wpcw-chat', WP_CONTENT_WRITER_PLUGIN_URL . 'assets/js/chat-widget.js', array('jquery', 'wpcw-marked-global'), WP_CONTENT_WRITER_VERSION, true);

        wp_localize_script('wpcw-chat', 'wpcwChat', array(
            'restUrl'   => esc_url_raw(rest_url('wpcw/v1/')),
            'nonce'     => wp_create_nonce('wp_rest'),
            'model'     => $this->settings->get_setting('model'),
            'writerUrl' => admin_url('admin.php?page=wp-content-writer'),
            'seoUrl'    => admin_url('admin.php?page=wp-content-writer-seo'),
            'pluginsUrl'=> admin_url('admin.php?page=wp-content-writer-plugins'),
            'siteUrl'   => admin_url('admin.php?page=wp-content-writer-site'),
            'changesUrl'=> admin_url('admin.php?page=wp-content-writer-changes'),
        ));
    }

    // ========================================================================
    // MAIN WRITER PAGE
    // ========================================================================

    public function render_writer_page() {
        $online = $this->api->is_ollama_online();
        $model  = $this->settings->get_setting('model');
        $groups = array();
        $group_icons = WPCW_Templates::get_groups_with_icons();
        foreach (WPCW_Templates::get_all() as $key => $tpl) {
            $groups[$tpl['group']][$key] = $tpl;
        }
        ?>
        <div class="wrap wpcw-wrap">
            <div class="wpcw-header">
                <div class="wpcw-header-left">
                    <div class="wpcw-logo">
                        <span class="dashicons dashicons-edit-page"></span>
                        Content Writer AI Pro
                    </div>
                    <div class="wpcw-header-badges">
                        <span class="wpcw-badge"><?php echo count(WPCW_Templates::get_all()); ?> Templates</span>
                        <span class="wpcw-badge"><?php echo esc_html(WPCW_Plugins_KB::get_total_count()); ?>+ Plugins KB</span>
                        <?php if (WPCW_SEO::is_rankmath_active()): ?>
                            <span class="wpcw-badge wpcw-badge-green">Rank Math Active</span>
                        <?php elseif (WPCW_SEO::is_yoast_active()): ?>
                            <span class="wpcw-badge wpcw-badge-green">Yoast Active</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="wpcw-status <?php echo $online ? 'online' : 'offline'; ?>">
                    <span class="wpcw-status-dot"></span>
                    <?php echo $online ? esc_html($model) . ' - Online' : 'Groq Offline'; ?>
                </div>
            </div>

            <div class="wpcw-main-layout">

                <!-- LEFT SIDEBAR: Template chooser -->
                <div class="wpcw-sidebar">
                    <div class="wpcw-sidebar-search">
                        <span class="dashicons dashicons-search wpcw-search-icon"></span>
                        <input type="text" id="wpcw-template-search" placeholder="Search templates..." />
                    </div>
                    <?php foreach ($groups as $group => $templates): ?>
                    <div class="wpcw-template-group">
                        <div class="wpcw-group-label">
                            <span class="dashicons dashicons-<?php echo esc_attr(isset($group_icons[$group]) ? $group_icons[$group] : 'marker'); ?>"></span>
                            <?php echo esc_html($group); ?>
                            <span class="wpcw-group-count"><?php echo count($templates); ?></span>
                        </div>
                        <?php foreach ($templates as $key => $tpl): ?>
                        <div class="wpcw-template-item" data-key="<?php echo esc_attr($key); ?>" data-search="<?php echo esc_attr(strtolower($tpl['label'] . ' ' . $group . ' ' . $tpl['description'])); ?>">
                            <span class="wpcw-tpl-icon dashicons dashicons-<?php echo esc_attr(isset($tpl['icon']) ? $tpl['icon'] : 'edit'); ?>"></span>
                            <div class="wpcw-tpl-text">
                                <span class="wpcw-tpl-label"><?php echo esc_html($tpl['label']); ?></span>
                                <span class="wpcw-tpl-desc"><?php echo esc_html($tpl['description']); ?></span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endforeach; ?>

                    <!-- Custom prompt -->
                    <div class="wpcw-template-group">
                        <div class="wpcw-group-label">
                            <span class="dashicons dashicons-lightbulb"></span>
                            Custom
                        </div>
                        <div class="wpcw-template-item wpcw-custom-item" data-key="__custom__" data-search="custom freeform prompt ai chat">
                            <span class="wpcw-tpl-icon dashicons dashicons-admin-generic"></span>
                            <div class="wpcw-tpl-text">
                                <span class="wpcw-tpl-label">Custom Prompt</span>
                                <span class="wpcw-tpl-desc">Write any custom prompt for AI</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- CENTER: Form -->
                <div class="wpcw-form-panel">
                    <div id="wpcw-placeholder" class="wpcw-placeholder">
                        <div class="wpcw-placeholder-icon"><span class="dashicons dashicons-edit-large"></span></div>
                        <h2>Choose a Template</h2>
                        <p>Select a template from the sidebar to start generating content</p>
                        <p class="wpcw-sub">Jasper/Copy.ai style content powered by your local <?php echo esc_html($model); ?></p>

                        <div class="wpcw-quick-stats">
                            <div class="wpcw-stat-card">
                                <span class="wpcw-stat-number"><?php echo count(WPCW_Templates::get_all()); ?>+</span>
                                <span class="wpcw-stat-label">Templates</span>
                            </div>
                            <div class="wpcw-stat-card">
                                <span class="wpcw-stat-number"><?php echo count(WPCW_Templates::get_tones()); ?></span>
                                <span class="wpcw-stat-label">Tones</span>
                            </div>
                            <div class="wpcw-stat-card">
                                <span class="wpcw-stat-number"><?php echo count(WPCW_Templates::get_languages()); ?></span>
                                <span class="wpcw-stat-label">Languages</span>
                            </div>
                            <div class="wpcw-stat-card">
                                <span class="wpcw-stat-number"><?php echo esc_html(WPCW_Plugins_KB::get_total_count()); ?>+</span>
                                <span class="wpcw-stat-label">Plugin KB</span>
                            </div>
                        </div>
                    </div>
                    <div id="wpcw-form-container" style="display:none;">
                        <h2 id="wpcw-form-title"></h2>
                        <p id="wpcw-form-desc" class="wpcw-form-desc"></p>
                        <div id="wpcw-dynamic-fields"></div>
                        <button id="wpcw-generate-btn" class="button button-primary wpcw-generate-btn">
                            <span class="dashicons dashicons-controls-play"></span> Generate Content
                        </button>
                        <div id="wpcw-loading" class="wpcw-loading" style="display:none;">
                            <div class="wpcw-spinner"></div>
                            <span>Generating content...</span>
                        </div>
                    </div>

                    <!-- Custom prompt panel -->
                    <div id="wpcw-custom-panel" style="display:none;">
                        <h2><span class="dashicons dashicons-admin-generic"></span> Custom Prompt</h2>
                        <p class="wpcw-form-desc">Write any prompt and let AI generate content for you</p>
                        <textarea id="wpcw-custom-prompt" rows="8" placeholder="Write your prompt here...&#10;&#10;Example: Write a 500-word Hindi blog post about benefits of yoga for beginners with SEO optimization..."></textarea>
                        <button id="wpcw-custom-generate-btn" class="button button-primary wpcw-generate-btn">
                            <span class="dashicons dashicons-controls-play"></span> Generate Content
                        </button>
                        <div id="wpcw-custom-loading" class="wpcw-loading" style="display:none;">
                            <div class="wpcw-spinner"></div>
                            <span>Generating content...</span>
                        </div>
                    </div>
                </div>

                <!-- RIGHT: Output -->
                <div class="wpcw-output-panel" id="wpcw-output-panel" style="display:none;">
                    <div class="wpcw-output-header">
                        <span><span class="dashicons dashicons-media-text"></span> Generated Content</span>
                        <div class="wpcw-output-actions">
                            <button class="button wpcw-btn-icon" id="wpcw-copy-btn" title="Copy"><span class="dashicons dashicons-clipboard"></span> Copy</button>
                            <button class="button wpcw-btn-icon" id="wpcw-new-post-btn" title="Save as Draft"><span class="dashicons dashicons-welcome-write-blog"></span> Save Draft</button>
                            <button class="button wpcw-btn-icon" id="wpcw-seo-check-btn" title="SEO Check"><span class="dashicons dashicons-chart-line"></span> SEO</button>
                            <button class="button wpcw-btn-icon" id="wpcw-clear-btn" title="Clear"><span class="dashicons dashicons-trash"></span></button>
                        </div>
                    </div>
                    <div id="wpcw-word-count" class="wpcw-word-count"></div>
                    <div id="wpcw-output-content" class="wpcw-output-content" contenteditable="true"></div>

                    <!-- SEO Analysis Panel -->
                    <div id="wpcw-seo-panel" class="wpcw-seo-panel" style="display:none;">
                        <div class="wpcw-seo-header">
                            <h3><span class="dashicons dashicons-chart-line"></span> SEO Analysis</h3>
                            <button class="button" id="wpcw-seo-close"><span class="dashicons dashicons-no"></span></button>
                        </div>
                        <div class="wpcw-seo-fields">
                            <label>Focus Keyword *</label>
                            <input type="text" id="wpcw-seo-keyword" placeholder="e.g. WordPress SEO" />
                            <label>SEO Title</label>
                            <input type="text" id="wpcw-seo-title" placeholder="SEO title (50-60 chars)" />
                            <label>Meta Description</label>
                            <textarea id="wpcw-seo-description" rows="2" placeholder="Meta description (150-155 chars)"></textarea>
                            <button class="button button-primary" id="wpcw-run-seo">
                                <span class="dashicons dashicons-chart-line"></span> Analyze SEO
                            </button>
                        </div>
                        <div id="wpcw-seo-results" style="display:none;"></div>
                    </div>

                    <!-- Post Creation Panel -->
                    <div id="wpcw-post-panel" class="wpcw-post-panel" style="display:none;">
                        <div class="wpcw-post-header">
                            <h3><span class="dashicons dashicons-welcome-write-blog"></span> Save as WordPress Post</h3>
                            <button class="button" id="wpcw-post-close"><span class="dashicons dashicons-no"></span></button>
                        </div>
                        <div class="wpcw-post-fields">
                            <label>Post Title *</label>
                            <input type="text" id="wpcw-post-title" placeholder="Post title" />
                            <label>Category</label>
                            <input type="text" id="wpcw-post-category" placeholder="e.g. WordPress, Tutorials" />
                            <label>Tags (comma separated)</label>
                            <input type="text" id="wpcw-post-tags" placeholder="e.g. SEO, WordPress, Tips" />
                            <label>Focus Keyword (Rank Math / Yoast)</label>
                            <input type="text" id="wpcw-post-keyword" placeholder="e.g. WordPress SEO tips" />
                            <label>Meta Description</label>
                            <textarea id="wpcw-post-meta-desc" rows="2" placeholder="SEO meta description"></textarea>
                            <label>Post Status</label>
                            <select id="wpcw-post-status">
                                <option value="draft">Draft</option>
                                <option value="publish">Publish Now</option>
                                <option value="pending">Pending Review</option>
                            </select>
                            <button class="button button-primary" id="wpcw-create-post-btn">
                                <span class="dashicons dashicons-welcome-write-blog"></span> Create Post with SEO
                            </button>
                        </div>
                    </div>
                </div>

            </div><!-- .wpcw-main-layout -->
        </div>
        <?php
    }

    // ========================================================================
    // SEO ANALYZER PAGE
    // ========================================================================

    public function render_seo_page() {
        $online = $this->api->is_ollama_online();
        ?>
        <div class="wrap wpcw-wrap">
            <div class="wpcw-header">
                <div class="wpcw-header-left">
                    <div class="wpcw-logo">
                        <span class="dashicons dashicons-chart-line"></span>
                        SEO Analyzer & Rank Math Optimizer
                    </div>
                </div>
                <div class="wpcw-status <?php echo $online ? 'online' : 'offline'; ?>">
                    <span class="wpcw-status-dot"></span>
                    <?php
                    if (WPCW_SEO::is_rankmath_active()) echo 'Rank Math Active';
                    elseif (WPCW_SEO::is_yoast_active()) echo 'Yoast Active';
                    else echo 'No SEO Plugin';
                    ?>
                </div>
            </div>

            <div class="wpcw-seo-page-layout">
                <div class="wpcw-seo-input-section">
                    <h2>Analyze Your Content for SEO</h2>
                    <p>Paste your content and focus keyword to get a Rank Math style SEO score with actionable recommendations.</p>

                    <div class="wpcw-field">
                        <label>Focus Keyword *</label>
                        <input type="text" id="wpcw-seo-page-keyword" placeholder="e.g. WordPress speed optimization" />
                    </div>
                    <div class="wpcw-field">
                        <label>SEO Title</label>
                        <input type="text" id="wpcw-seo-page-title" placeholder="Page/Post title (50-60 chars)" />
                        <span class="wpcw-char-count" id="wpcw-title-chars">0/60</span>
                    </div>
                    <div class="wpcw-field">
                        <label>Meta Description</label>
                        <textarea id="wpcw-seo-page-desc" rows="2" placeholder="Meta description (150-155 chars)"></textarea>
                        <span class="wpcw-char-count" id="wpcw-desc-chars">0/155</span>
                    </div>
                    <div class="wpcw-field">
                        <label>URL Slug</label>
                        <input type="text" id="wpcw-seo-page-url" placeholder="e.g. wordpress-speed-optimization" />
                    </div>
                    <div class="wpcw-field">
                        <label>Content *</label>
                        <textarea id="wpcw-seo-page-content" rows="12" placeholder="Paste your full blog post content here..."></textarea>
                    </div>

                    <button class="button button-primary wpcw-generate-btn" id="wpcw-seo-page-analyze">
                        <span class="dashicons dashicons-chart-line"></span> Analyze SEO Score
                    </button>
                </div>

                <div class="wpcw-seo-results-section" id="wpcw-seo-page-results" style="display:none;">
                    <!-- Results rendered by JS -->
                </div>

                <!-- Rank Math Checklist -->
                <div class="wpcw-seo-checklist-section">
                    <h2><span class="dashicons dashicons-yes-alt"></span> Rank Math 100% Score Checklist</h2>
                    <?php
                    $checklist = WPCW_SEO::get_rankmath_checklist();
                    foreach ($checklist as $section => $items): ?>
                    <div class="wpcw-checklist-group">
                        <h3><?php echo esc_html(ucfirst(str_replace('_', ' ', $section))); ?></h3>
                        <ul class="wpcw-checklist">
                            <?php foreach ($items as $item): ?>
                            <li><span class="dashicons dashicons-marker"></span> <?php echo esc_html($item); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
    }

    // ========================================================================
    // PLUGIN KNOWLEDGE BASE PAGE
    // ========================================================================

    public function render_plugins_page() {
        $categories = WPCW_Plugins_KB::get_categories();
        $total = WPCW_Plugins_KB::get_total_count();
        ?>
        <div class="wrap wpcw-wrap">
            <div class="wpcw-header">
                <div class="wpcw-header-left">
                    <div class="wpcw-logo">
                        <span class="dashicons dashicons-admin-plugins"></span>
                        WordPress Plugin Knowledge Base
                    </div>
                    <span class="wpcw-badge"><?php echo esc_html($total); ?>+ Plugins</span>
                </div>
            </div>

            <div class="wpcw-plugins-layout">
                <!-- Search -->
                <div class="wpcw-plugins-search-bar">
                    <span class="dashicons dashicons-search"></span>
                    <input type="text" id="wpcw-plugin-search" placeholder="Search plugins by name, feature, or category..." />
                    <select id="wpcw-plugin-type-filter">
                        <option value="all">All Types</option>
                        <option value="free">Free</option>
                        <option value="freemium">Freemium</option>
                        <option value="premium">Premium</option>
                    </select>
                </div>

                <!-- Categories Grid -->
                <div class="wpcw-plugins-categories" id="wpcw-plugin-categories">
                    <?php foreach ($categories as $cat_key => $cat_label):
                        $plugins = WPCW_Plugins_KB::get_plugins_by_category($cat_key);
                        $count = count($plugins);
                    ?>
                    <div class="wpcw-plugin-category-card" data-category="<?php echo esc_attr($cat_key); ?>">
                        <div class="wpcw-cat-count"><?php echo esc_html($count); ?></div>
                        <div class="wpcw-cat-name"><?php echo esc_html($cat_label); ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Plugin Results -->
                <div id="wpcw-plugin-results" class="wpcw-plugin-results" style="display:none;">
                    <div class="wpcw-results-header">
                        <h2 id="wpcw-results-title">Search Results</h2>
                        <button class="button" id="wpcw-back-to-categories">
                            <span class="dashicons dashicons-arrow-left-alt"></span> Back to Categories
                        </button>
                    </div>
                    <div id="wpcw-plugin-list" class="wpcw-plugin-list"></div>
                </div>
            </div>
        </div>
        <?php
    }

    // ========================================================================
    // SETTINGS PAGE
    // ========================================================================

    public function render_settings_page() {
        $s = $this->settings->get_settings();
        $online = $this->api->is_ollama_online();
        ?>
        <div class="wrap wpcw-wrap">
            <div class="wpcw-header">
                <div class="wpcw-header-left">
                    <div class="wpcw-logo">
                        <span class="dashicons dashicons-admin-generic"></span>
                        Content Writer AI Pro - Settings
                    </div>
                </div>
                <div class="wpcw-status <?php echo $online ? 'online' : 'offline'; ?>">
                    <span class="wpcw-status-dot"></span>
                    <?php echo $online ? 'Groq Online' : 'Groq Offline'; ?>
                </div>
            </div>

            <?php if (!empty($_GET['wpcw_saved'])): ?>
            <div class="notice notice-success is-dismissible"><p>Settings saved successfully!</p></div>
            <?php endif; ?>

            <form method="post" class="wpcw-settings-form">
                <?php wp_nonce_field('wpcw_save_settings'); ?>
                <input type="hidden" name="wpcw_action" value="save_settings" />

                <div class="wpcw-settings-card">
                    <h3><span class="dashicons dashicons-admin-generic"></span> Groq / LLM Configuration</h3>
                    <table class="form-table">
                        <tr>
                            <th>Groq API Base URL</th>
                            <td>
                                <input type="url" name="wpcw_ollama_url" value="<?php echo esc_attr($s['ollama_url']); ?>" class="regular-text" />
                                <p class="description">Default: <code>https://api.groq.com/openai/v1</code> — Groq Cloud OpenAI-compatible endpoint</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Groq API Key</th>
                            <td>
                                <?php
                                $providers_data = $this->providers->get_settings_data();
                                $groq_cfg = isset($providers_data['configs']['groq']) ? $providers_data['configs']['groq'] : array();
                                $masked = '';
                                if (!empty($groq_cfg['api_key'])) {
                                    $tail = substr($groq_cfg['api_key'], -4);
                                    $masked = str_repeat('•', max(4, strlen($groq_cfg['api_key']) - 4)) . $tail;
                                }
                                ?>
                                <input type="password" name="wpcw_groq_api_key" value="<?php echo esc_attr($masked); ?>" class="regular-text" autocomplete="new-password" placeholder="sk-…" />
                                <p class="description">Get one at <a href="https://console.groq.com/keys" target="_blank" rel="noopener">console.groq.com/keys</a>. The key is stored encrypted at rest. To unlock more providers (OpenAI, Anthropic, Gemini, OpenRouter), visit <a href="<?php echo esc_url(admin_url('admin.php?page=wp-content-writer-providers')); ?>">AI Providers</a>.</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Model</th>
                            <td>
                                <input type="text" name="wpcw_model" value="<?php echo esc_attr($s['model']); ?>" class="regular-text" />
                                <p class="description">e.g. <code>llama-3.1-8b-instant</code>, <code>llama-3.3-70b-versatile</code>, <code>llama3-8b-8192</code>, <code>mixtral-8x7b-32768</code></p>
                            </td>
                        </tr>
                        <tr>
                            <th>Request Timeout (sec)</th>
                            <td><input type="number" name="wpcw_request_timeout" value="<?php echo esc_attr($s['request_timeout']); ?>" min="30" max="600" /></td>
                        </tr>
                        <tr>
                            <th>Host Header <small>(optional)</small></th>
                            <td><input type="text" name="wpcw_host_header" value="<?php echo esc_attr($s['host_header']); ?>" class="regular-text" placeholder="For tunnel use" /></td>
                        </tr>
                        <tr>
                            <th>Origin Header <small>(optional)</small></th>
                            <td><input type="url" name="wpcw_origin_header" value="<?php echo esc_attr($s['origin_header']); ?>" class="regular-text" /></td>
                        </tr>
                    </table>
                </div>

                <div class="wpcw-settings-card">
                    <h3><span class="dashicons dashicons-translation"></span> Content Defaults</h3>
                    <table class="form-table">
                        <tr>
                            <th>Default Language</th>
                            <td>
                                <select name="wpcw_default_language">
                                    <?php foreach (WPCW_Templates::get_languages() as $lang): ?>
                                    <option value="<?php echo esc_attr($lang); ?>" <?php selected($s['default_language'], $lang); ?>><?php echo esc_html($lang); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th>Default Tone</th>
                            <td>
                                <select name="wpcw_default_tone">
                                    <?php foreach (WPCW_Templates::get_tones() as $key => $label): ?>
                                    <option value="<?php echo esc_attr($key); ?>" <?php selected($s['default_tone'], $key); ?>><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="wpcw-settings-card">
                    <h3><span class="dashicons dashicons-info"></span> System Information</h3>
                    <table class="form-table">
                        <tr>
                            <th>Plugin Version</th>
                            <td><code><?php echo esc_html(WP_CONTENT_WRITER_VERSION); ?></code></td>
                        </tr>
                        <tr>
                            <th>Templates Available</th>
                            <td><code><?php echo count(WPCW_Templates::get_all()); ?></code></td>
                        </tr>
                        <tr>
                            <th>Plugin KB Size</th>
                            <td><code><?php echo esc_html(WPCW_Plugins_KB::get_total_count()); ?>+ plugins</code></td>
                        </tr>
                        <tr>
                            <th>SEO Plugin</th>
                            <td><code><?php echo esc_html(WPCW_SEO::get_active_seo_plugin()); ?></code></td>
                        </tr>
                        <tr>
                            <th>cURL Available</th>
                            <td><code><?php echo function_exists('curl_init') ? 'Yes' : 'No'; ?></code></td>
                        </tr>
                    </table>
                </div>

                <p><button type="submit" class="button button-primary button-large"><span class="dashicons dashicons-saved"></span> Save Settings</button></p>
            </form>
        </div>
        <?php
    }

    // ========================================================================
    // WEBSITE ANALYZER PAGE
    // ========================================================================

    public function render_site_analyzer_page() {
        $online = $this->api->is_ollama_online();
        ?>
        <div class="wrap wpcw-wrap">
            <div class="wpcw-header">
                <div class="wpcw-header-left">
                    <div class="wpcw-logo">
                        <span class="dashicons dashicons-visibility"></span>
                        Website Analyzer - AI Screen Viewer
                    </div>
                    <span class="wpcw-badge">Powered by <?php echo esc_html($this->settings->get_setting('model')); ?></span>
                </div>
                <div class="wpcw-status <?php echo $online ? 'online' : 'offline'; ?>">
                    <span class="wpcw-status-dot"></span>
                    <?php echo $online ? 'AI Online' : 'AI Offline'; ?>
                </div>
            </div>

            <div class="wpcw-site-analyzer-layout">

                <!-- Quick Stats -->
                <div class="wpcw-site-stats-grid" id="wpcw-site-stats">
                    <div class="wpcw-site-stat-card loading">
                        <span class="dashicons dashicons-update wpcw-spin"></span>
                        Loading site data...
                    </div>
                </div>

                <!-- AI Analysis Section -->
                <div class="wpcw-site-ai-section">
                    <div class="wpcw-site-ai-input">
                        <h2><span class="dashicons dashicons-admin-generic"></span> Ask AI About Your Website</h2>
                        <p>AI will analyze your entire website (pages, posts, theme, plugins, SEO, settings) and answer your question.</p>
                        <textarea id="wpcw-site-question" rows="3" placeholder="Examples:&#10;- Meri website ki speed kaise improve hogi?&#10;- Konse plugins remove karne chahiye?&#10;- SEO me kya improve kar sakte hain?&#10;- Meri website ka overall health score kya hai?"></textarea>
                        <div class="wpcw-site-ai-buttons">
                            <button class="button button-primary wpcw-generate-btn" id="wpcw-site-analyze-btn">
                                <span class="dashicons dashicons-visibility"></span> Analyze Website with AI
                            </button>
                            <button class="button" id="wpcw-site-full-scan-btn">
                                <span class="dashicons dashicons-search"></span> Full Site Scan
                            </button>
                        </div>
                    </div>
                    <div id="wpcw-site-ai-result" class="wpcw-site-ai-result" style="display:none;"></div>
                    <div id="wpcw-site-ai-loading" class="wpcw-loading" style="display:none;">
                        <div class="wpcw-spinner"></div>
                        <span>AI is analyzing your website... (this may take 30-60 seconds)</span>
                    </div>
                </div>

                <!-- Site Data Sections -->
                <div class="wpcw-site-data-grid">
                    <!-- Pages -->
                    <div class="wpcw-site-data-card">
                        <h3><span class="dashicons dashicons-admin-page"></span> Pages <span class="wpcw-data-count" id="wpcw-pages-count">-</span></h3>
                        <div id="wpcw-site-pages-list" class="wpcw-site-data-list">Loading...</div>
                    </div>
                    <!-- Posts -->
                    <div class="wpcw-site-data-card">
                        <h3><span class="dashicons dashicons-admin-post"></span> Posts <span class="wpcw-data-count" id="wpcw-posts-count">-</span></h3>
                        <div id="wpcw-site-posts-list" class="wpcw-site-data-list">Loading...</div>
                    </div>
                    <!-- Plugins -->
                    <div class="wpcw-site-data-card">
                        <h3><span class="dashicons dashicons-admin-plugins"></span> Active Plugins <span class="wpcw-data-count" id="wpcw-active-plugins-count">-</span></h3>
                        <div id="wpcw-site-plugins-list" class="wpcw-site-data-list">Loading...</div>
                    </div>
                    <!-- SEO Status -->
                    <div class="wpcw-site-data-card">
                        <h3><span class="dashicons dashicons-chart-line"></span> SEO Status</h3>
                        <div id="wpcw-site-seo-status" class="wpcw-site-data-list">Loading...</div>
                    </div>
                </div>

            </div>
        </div>
        <?php
    }

    // ========================================================================
    // SITE-WIDE CHANGES PAGE
    // ========================================================================

    public function render_site_changes_page() {
        $online = $this->api->is_ollama_online();
        ?>
        <div class="wrap wpcw-wrap">
            <div class="wpcw-header">
                <div class="wpcw-header-left">
                    <div class="wpcw-logo">
                        <span class="dashicons dashicons-admin-tools"></span>
                        Site-Wide Changes
                    </div>
                    <span class="wpcw-badge wpcw-badge-green">Admin Only</span>
                </div>
                <div class="wpcw-status <?php echo $online ? 'online' : 'offline'; ?>">
                    <span class="wpcw-status-dot"></span>
                    <?php echo $online ? 'AI Online' : 'AI Offline'; ?>
                </div>
            </div>

            <div class="wpcw-changes-layout">

                <!-- AI-Powered Changes -->
                <div class="wpcw-changes-section wpcw-changes-ai">
                    <h2><span class="dashicons dashicons-superhero"></span> AI-Powered Site Changes</h2>
                    <p>Apni website me koi bhi change karna hai? Hindi ya English me likho, AI samajh ke puri site me apply kar dega.</p>
                    <textarea id="wpcw-ai-instruction" rows="4" placeholder="Examples:&#10;- Sabhi posts me 'old company name' ko 'new company name' se replace karo&#10;- Website ka font size bada karo aur background color change karo&#10;- Sabhi posts me SEO meta description add karo&#10;- Header ka color red se blue karo&#10;- Footer me copyright year update karo"></textarea>
                    <div class="wpcw-changes-ai-buttons">
                        <button class="button button-primary wpcw-generate-btn" id="wpcw-ai-change-btn">
                            <span class="dashicons dashicons-superhero"></span> Generate Changes with AI
                        </button>
                    </div>
                    <div id="wpcw-ai-change-loading" class="wpcw-loading" style="display:none;">
                        <div class="wpcw-spinner"></div>
                        <span>AI is generating changes...</span>
                    </div>
                    <div id="wpcw-ai-change-preview" style="display:none;"></div>
                </div>

                <!-- Manual Tools Grid -->
                <div class="wpcw-changes-tools-grid">

                    <!-- Find & Replace -->
                    <div class="wpcw-changes-tool-card">
                        <h3><span class="dashicons dashicons-search"></span> Find & Replace</h3>
                        <p>Puri website me text find & replace karo (titles, content, excerpts)</p>
                        <div class="wpcw-field">
                            <label>Search Text *</label>
                            <input type="text" id="wpcw-fr-search" placeholder="Text to find..." />
                        </div>
                        <div class="wpcw-field">
                            <label>Replace With</label>
                            <input type="text" id="wpcw-fr-replace" placeholder="Replace with..." />
                        </div>
                        <div class="wpcw-field wpcw-checkbox-row">
                            <label><input type="checkbox" id="wpcw-fr-title" checked /> Titles</label>
                            <label><input type="checkbox" id="wpcw-fr-content" checked /> Content</label>
                            <label><input type="checkbox" id="wpcw-fr-excerpt" /> Excerpts</label>
                            <label><input type="checkbox" id="wpcw-fr-case" /> Case Sensitive</label>
                        </div>
                        <div class="wpcw-field wpcw-checkbox-row">
                            <label><input type="checkbox" id="wpcw-fr-dry" checked /> <strong>Dry Run (Preview Only)</strong></label>
                        </div>
                        <button class="button button-primary" id="wpcw-fr-btn">
                            <span class="dashicons dashicons-search"></span> Find & Replace
                        </button>
                        <div id="wpcw-fr-result" style="display:none;"></div>
                    </div>

                    <!-- Bulk SEO Update -->
                    <div class="wpcw-changes-tool-card">
                        <h3><span class="dashicons dashicons-chart-line"></span> Bulk SEO Update</h3>
                        <p>Sabhi posts/pages me missing SEO meta (focus keyword, meta description) auto-generate karo</p>
                        <div class="wpcw-field wpcw-checkbox-row">
                            <label><input type="checkbox" id="wpcw-seo-empty" checked /> Only empty (missing SEO)</label>
                            <label><input type="checkbox" id="wpcw-seo-dry" checked /> <strong>Dry Run</strong></label>
                        </div>
                        <button class="button button-primary" id="wpcw-bulk-seo-btn">
                            <span class="dashicons dashicons-chart-line"></span> Bulk Update SEO
                        </button>
                        <div id="wpcw-bulk-seo-result" style="display:none;"></div>
                    </div>

                    <!-- Custom CSS -->
                    <div class="wpcw-changes-tool-card">
                        <h3><span class="dashicons dashicons-editor-code"></span> Global Custom CSS</h3>
                        <p>Puri website me CSS changes apply karo — fonts, colors, spacing, layout, etc.</p>
                        <div class="wpcw-field">
                            <textarea id="wpcw-css-code" rows="6" placeholder="body { font-size: 16px; }&#10;h1 { color: #333; }&#10;.header { background: #1e1b4b; }"></textarea>
                        </div>
                        <div class="wpcw-field">
                            <label>Mode:</label>
                            <select id="wpcw-css-mode">
                                <option value="append">Append to existing CSS</option>
                                <option value="prepend">Prepend before existing CSS</option>
                                <option value="replace">Replace all custom CSS</option>
                            </select>
                        </div>
                        <button class="button button-primary" id="wpcw-css-btn">
                            <span class="dashicons dashicons-editor-code"></span> Apply CSS
                        </button>
                        <div id="wpcw-css-result" style="display:none;"></div>
                    </div>

                    <!-- Bulk Image Alt -->
                    <div class="wpcw-changes-tool-card">
                        <h3><span class="dashicons dashicons-format-image"></span> Bulk Image Alt Text</h3>
                        <p>Sabhi images ke missing alt text auto-generate karo (filename se) for SEO</p>
                        <div class="wpcw-field wpcw-checkbox-row">
                            <label><input type="checkbox" id="wpcw-alt-dry" checked /> <strong>Dry Run</strong></label>
                        </div>
                        <button class="button button-primary" id="wpcw-alt-btn">
                            <span class="dashicons dashicons-format-image"></span> Fix Image Alt Text
                        </button>
                        <div id="wpcw-alt-result" style="display:none;"></div>
                    </div>

                </div><!-- .wpcw-changes-tools-grid -->
            </div>
        </div>
        <?php
    }

    // ========================================================================
    // AI PROVIDERS PAGE (Phase 1 SaaS)
    // ========================================================================

    public function render_providers_page() {
        $data        = $this->providers->get_settings_data();
        $available   = $this->providers->available_providers();
        $multi_ok    = WPCW_License::is_feature_enabled('multi_provider');
        $tier_label  = WPCW_License::get_plan_label();
        ?>
        <div class="wrap wpcw-wrap">
            <div class="wpcw-header">
                <div class="wpcw-header-left">
                    <div class="wpcw-logo"><span class="dashicons dashicons-admin-network"></span> AI Providers</div>
                    <div class="wpcw-header-badges">
                        <span class="wpcw-badge wpcw-badge-blue"><?php echo esc_html($tier_label); ?> Plan</span>
                        <?php if (!$multi_ok): ?>
                            <span class="wpcw-badge">Upgrade to Pro for multi-provider + failover</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="wpcw-saas-grid" id="wpcw-providers-app" data-multi="<?php echo $multi_ok ? '1' : '0'; ?>">
                <?php foreach ($available as $id => $class):
                    $p = $this->providers->get($id);
                    if (!$p) continue;
                    $cfg = isset($data['configs'][$id]) ? $data['configs'][$id] : array();
                    $masked = '';
                    if (!empty($cfg['api_key'])) {
                        $tail = substr($cfg['api_key'], -4);
                        $masked = str_repeat('•', max(4, strlen($cfg['api_key']) - 4)) . $tail;
                    }
                    $disabled = (!$multi_ok && 'groq' !== $id);
                ?>
                <div class="wpcw-saas-card wpcw-provider-card <?php echo $disabled ? 'is-locked' : ''; ?>" data-provider="<?php echo esc_attr($id); ?>">
                    <div class="wpcw-saas-card-head">
                        <h3>
                            <span class="dashicons dashicons-admin-site-alt3"></span>
                            <?php echo esc_html($p->label()); ?>
                        </h3>
                        <label class="wpcw-radio">
                            <input type="radio" name="wpcw-active-provider" value="<?php echo esc_attr($id); ?>"
                                <?php checked($data['active'], $id); ?>
                                <?php disabled($disabled); ?> />
                            Active
                        </label>
                    </div>

                    <label class="wpcw-field">
                        <span>API Key</span>
                        <input type="password" class="regular-text wpcw-prov-key" placeholder="<?php echo $masked ? esc_attr($masked) : 'Enter API key…'; ?>" autocomplete="new-password" <?php disabled($disabled); ?> />
                    </label>

                    <label class="wpcw-field">
                        <span>Default Model</span>
                        <select class="wpcw-prov-model" <?php disabled($disabled); ?>>
                            <option value="">— vendor default (<?php echo esc_html($p->default_model()); ?>) —</option>
                            <?php foreach ($p->models() as $m): ?>
                                <option value="<?php echo esc_attr($m); ?>" <?php selected(isset($cfg['model']) ? $cfg['model'] : '', $m); ?>><?php echo esc_html($m); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>

                    <label class="wpcw-field">
                        <span>Custom base URL <small>(optional)</small></span>
                        <input type="url" class="regular-text wpcw-prov-base" value="<?php echo esc_attr(isset($cfg['base_url']) ? $cfg['base_url'] : ''); ?>" placeholder="leave empty for vendor default" <?php disabled($disabled); ?> />
                    </label>

                    <label class="wpcw-field">
                        <span>Use as fallback</span>
                        <input type="checkbox" class="wpcw-prov-fallback" value="<?php echo esc_attr($id); ?>"
                            <?php checked(in_array($id, (array) $data['fallback'], true)); ?>
                            <?php disabled($disabled); ?> />
                    </label>

                    <div class="wpcw-prov-actions">
                        <button class="button wpcw-prov-test" type="button" <?php disabled($disabled); ?>>Test</button>
                        <span class="wpcw-prov-test-result"></span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <p class="wpcw-saas-actions">
                <button class="button button-primary button-hero" id="wpcw-providers-save">Save All Providers</button>
                <span class="wpcw-saas-save-msg"></span>
            </p>
        </div>
        <?php
    }

    // ========================================================================
    // USAGE ANALYTICS PAGE (Phase 1 SaaS)
    // ========================================================================

    public function render_usage_page() {
        $summary = WPCW_Usage::summary();
        ?>
        <div class="wrap wpcw-wrap">
            <div class="wpcw-header">
                <div class="wpcw-header-left">
                    <div class="wpcw-logo"><span class="dashicons dashicons-chart-bar"></span> Usage Analytics</div>
                    <div class="wpcw-header-badges">
                        <span class="wpcw-badge wpcw-badge-blue"><?php echo esc_html($summary['plan']); ?> Plan</span>
                        <span class="wpcw-badge"><?php echo esc_html($summary['period_label']); ?></span>
                    </div>
                </div>
            </div>

            <div class="wpcw-stat-row">
                <?php
                $cards = array(
                    array('label' => 'Words Generated', 'used' => $summary['usage']['words'],     'limit' => $summary['quota']['words'],     'icon' => 'editor-textcolor'),
                    array('label' => 'Posts Created',   'used' => $summary['usage']['posts'],     'limit' => $summary['quota']['posts'],     'icon' => 'admin-post'),
                    array('label' => 'API Calls',       'used' => $summary['usage']['api_calls'], 'limit' => $summary['quota']['api_calls'], 'icon' => 'rest-api'),
                    array('label' => 'Estimated Cost',  'used' => '$' . number_format($summary['usage']['cost_usd'], 4), 'limit' => '—',          'icon' => 'money-alt'),
                );
                foreach ($cards as $c):
                    $pct = is_numeric($c['used']) && is_numeric($c['limit']) && $c['limit'] > 0 ? min(100, ($c['used'] / $c['limit']) * 100) : 0;
                    $cls = $pct >= 90 ? 'wpcw-pct-danger' : ($pct >= 70 ? 'wpcw-pct-warn' : 'wpcw-pct-ok');
                ?>
                <div class="wpcw-stat-tile">
                    <div class="wpcw-stat-icon"><span class="dashicons dashicons-<?php echo esc_attr($c['icon']); ?>"></span></div>
                    <div class="wpcw-stat-body">
                        <div class="wpcw-stat-num"><?php echo esc_html(is_numeric($c['used']) ? number_format($c['used']) : $c['used']); ?></div>
                        <div class="wpcw-stat-cap">
                            <?php echo esc_html($c['label']); ?>
                            <small>
                                <?php if (-1 === $c['limit']): ?>Unlimited<?php elseif ('—' === $c['limit']): ?>—<?php else: echo '/ ' . esc_html(number_format($c['limit'])); endif; ?>
                            </small>
                        </div>
                        <?php if (is_numeric($c['limit']) && $c['limit'] > 0): ?>
                        <div class="wpcw-pct"><div class="wpcw-pct-bar <?php echo esc_attr($cls); ?>" style="width:<?php echo (int) $pct; ?>%"></div></div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="wpcw-saas-grid">
                <div class="wpcw-saas-card">
                    <h3>Daily activity (this month)</h3>
                    <canvas id="wpcw-chart-daily" height="120"></canvas>
                </div>
                <div class="wpcw-saas-card">
                    <h3>Last 12 months — words</h3>
                    <canvas id="wpcw-chart-months" height="120"></canvas>
                </div>
                <div class="wpcw-saas-card">
                    <h3>By provider (this month)</h3>
                    <canvas id="wpcw-chart-providers" height="120"></canvas>
                </div>
                <div class="wpcw-saas-card">
                    <h3>Top users (this month)</h3>
                    <table class="wpcw-saas-table">
                        <thead><tr><th>User</th><th>Words</th><th>Calls</th><th>Posts</th></tr></thead>
                        <tbody>
                            <?php foreach ($summary['by_user'] as $u): ?>
                            <tr>
                                <td><?php echo esc_html($u['name']); ?></td>
                                <td><?php echo esc_html(number_format($u['words'])); ?></td>
                                <td><?php echo esc_html(number_format($u['api_calls'])); ?></td>
                                <td><?php echo esc_html(number_format($u['posts'])); ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($summary['by_user'])): ?>
                            <tr><td colspan="4"><em>No usage recorded yet this month.</em></td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <script>window.wpcwUsageData = <?php echo wp_json_encode($summary); ?>;</script>
        </div>
        <?php
    }

    // ========================================================================
    // LICENSE PAGE (Phase 1 SaaS)
    // ========================================================================

    public function render_license_page() {
        $data    = WPCW_License::get_data();
        $matrix  = WPCW_License::feature_matrix();
        $tier    = WPCW_License::get_tier();
        $masked  = '';
        if (!empty($data['key'])) {
            $tail = substr($data['key'], -4);
            $masked = str_repeat('•', max(4, strlen($data['key']) - 4)) . $tail;
        }
        ?>
        <div class="wrap wpcw-wrap">
            <div class="wpcw-header">
                <div class="wpcw-header-left">
                    <div class="wpcw-logo"><span class="dashicons dashicons-admin-network"></span> License</div>
                    <div class="wpcw-header-badges">
                        <span class="wpcw-badge wpcw-badge-blue"><?php echo esc_html(WPCW_License::get_plan_label()); ?></span>
                        <span class="wpcw-badge"><?php echo $data['expires_at'] ? 'Expires ' . esc_html(date_i18n(get_option('date_format'), $data['expires_at'])) : 'No expiry'; ?></span>
                    </div>
                </div>
            </div>

            <div class="wpcw-saas-card" id="wpcw-license-app">
                <h3>Activate your license</h3>
                <p class="description">Enter your license key to unlock Pro / Agency features. Your domain (<code><?php echo esc_html(WPCW_License::current_domain()); ?></code>) will be bound to the license.</p>
                <p>
                    <input type="text" class="regular-text" id="wpcw-license-key" placeholder="<?php echo $masked ? esc_attr($masked) : 'PRO-XXXX-XXXX-XXXX'; ?>" />
                    <button class="button button-primary" id="wpcw-license-activate-btn">Activate</button>
                    <?php if ('active' === $data['status']): ?>
                        <button class="button" id="wpcw-license-deactivate-btn">Deactivate</button>
                    <?php endif; ?>
                </p>
                <p class="wpcw-license-msg"></p>
            </div>

            <div class="wpcw-saas-card">
                <h3>Plan comparison</h3>
                <table class="wpcw-saas-table wpcw-license-matrix">
                    <thead><tr><th>Feature</th><?php foreach (array_keys($matrix) as $t): ?><th><?php echo esc_html(ucfirst($t)); ?></th><?php endforeach; ?></tr></thead>
                    <tbody>
                    <?php
                    $rows = array_keys($matrix['agency']);
                    foreach ($rows as $feature): ?>
                        <tr>
                            <td><?php echo esc_html(ucwords(str_replace('_', ' ', $feature))); ?></td>
                            <?php foreach ($matrix as $tname => $flags): ?>
                                <td class="<?php echo $tier === $tname ? 'is-current' : ''; ?>"><?php echo !empty($flags[$feature]) ? '<span class="dashicons dashicons-yes" style="color:#16a34a"></span>' : '<span class="dashicons dashicons-minus" style="color:#9ca3af"></span>'; ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    // ========================================================================
    // ONBOARDING WIZARD (Phase 1 SaaS)
    // ========================================================================

    public function render_onboarding_page() {
        ?>
        <div class="wrap wpcw-wrap wpcw-onboarding" id="wpcw-onboarding-app">
            <div class="wpcw-onboarding-header">
                <div class="wpcw-logo"><span class="dashicons dashicons-edit-page"></span> WP Content Writer AI Pro</div>
                <h1>Welcome — let's get you set up in 3 steps.</h1>
            </div>

            <div class="wpcw-steps">
                <div class="wpcw-step is-active" data-step="1"><span>1</span> Provider</div>
                <div class="wpcw-step" data-step="2"><span>2</span> License</div>
                <div class="wpcw-step" data-step="3"><span>3</span> Defaults</div>
            </div>

            <div class="wpcw-onboarding-body">
                <section class="wpcw-onboarding-section is-visible" data-step="1">
                    <h2>Pick your AI provider</h2>
                    <p>Free tier ships with Groq Cloud (fast Llama 3.x). Pro/Agency users can choose any provider below. Your key is stored encrypted at rest.</p>
                    <div class="wpcw-prov-pick">
                        <?php foreach ($this->providers->available_providers() as $id => $class):
                            $p = $this->providers->get($id);
                            if (!$p) continue;
                        ?>
                        <label class="wpcw-prov-pick-item">
                            <input type="radio" name="onboard-provider" value="<?php echo esc_attr($id); ?>" <?php checked($id, 'groq'); ?> />
                            <strong><?php echo esc_html($p->label()); ?></strong>
                            <small><?php echo count($p->models()); ?> models</small>
                        </label>
                        <?php endforeach; ?>
                    </div>
                    <label class="wpcw-field">
                        <span>API Key</span>
                        <input type="password" id="wpcw-onboard-key" class="regular-text" placeholder="sk-… / gsk_…" autocomplete="new-password" />
                    </label>
                    <p class="wpcw-onboarding-actions">
                        <button class="button button-primary" data-next="2">Continue</button>
                        <span class="wpcw-onboard-msg"></span>
                    </p>
                </section>

                <section class="wpcw-onboarding-section" data-step="2">
                    <h2>Activate license <small>(optional)</small></h2>
                    <p>Skip this step to keep using the Free tier. You can activate a license later from <em>License</em> in the menu.</p>
                    <label class="wpcw-field">
                        <span>License Key</span>
                        <input type="text" id="wpcw-onboard-license" class="regular-text" placeholder="PRO-XXXX-XXXX-XXXX" />
                    </label>
                    <p class="wpcw-onboarding-actions">
                        <button class="button" data-prev="1">Back</button>
                        <button class="button button-primary" data-next="3">Continue</button>
                    </p>
                </section>

                <section class="wpcw-onboarding-section" data-step="3">
                    <h2>Set your defaults</h2>
                    <label class="wpcw-field">
                        <span>Default language</span>
                        <select id="wpcw-onboard-lang">
                            <option value="Hindi">Hindi</option>
                            <option value="English">English</option>
                            <option value="Hinglish">Hinglish</option>
                        </select>
                    </label>
                    <label class="wpcw-field">
                        <span>Default tone</span>
                        <select id="wpcw-onboard-tone">
                            <option value="professional">Professional</option>
                            <option value="casual">Casual</option>
                            <option value="friendly">Friendly</option>
                            <option value="persuasive">Persuasive</option>
                        </select>
                    </label>
                    <p class="wpcw-onboarding-actions">
                        <button class="button" data-prev="2">Back</button>
                        <button class="button button-primary" id="wpcw-onboard-finish">Finish setup</button>
                    </p>
                </section>
            </div>
        </div>
        <?php
    }
}
