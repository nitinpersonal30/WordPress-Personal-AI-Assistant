<?php
/**
 * Plugin Name: WP Content Writer AI Pro
 * Description: SaaS-grade WordPress AI content suite — multi-provider (Groq, OpenAI, Anthropic, Gemini, OpenRouter), license tiers, usage analytics, 80+ templates, SEO Rank Math 100% optimization, 500+ plugin knowledge base, blog posts, ads, emails, code generation aur bahut kuch.
 * Version: 4.0.0
 * Author: Programming with Nitin
 * Text Domain: wp-content-writer
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WP_CONTENT_WRITER_VERSION', '4.0.0');
define('WP_CONTENT_WRITER_PLUGIN_FILE', __FILE__);
define('WP_CONTENT_WRITER_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('WP_CONTENT_WRITER_PLUGIN_URL', plugin_dir_url(__FILE__));

function wp_content_writer_activate() {
    require_once plugin_dir_path(__FILE__) . 'includes/class-settings.php';
    require_once plugin_dir_path(__FILE__) . 'includes/class-encryption.php';
    require_once plugin_dir_path(__FILE__) . 'includes/class-provider-manager.php';

    $default_settings = array(
        'ollama_url'      => WPCW_Settings::DEFAULT_GROQ_API_BASE,
        'model'           => WPCW_Settings::DEFAULT_GROQ_MODEL,
        'host_header'     => '',
        'origin_header'   => '',
        'request_timeout' => 120,
        'default_language'=> 'Hindi',
        'default_tone'    => 'professional',
    );

    if (false === get_option('wpcw_settings')) {
        add_option('wpcw_settings', $default_settings);
    } else {
        $saved = get_option('wpcw_settings', array());
        if (is_array($saved)) {
            unset($saved['groq_api_key']); // No longer stored here — moved to provider manager.
            update_option('wpcw_settings', wp_parse_args($saved, $default_settings));
        }
    }

    // Migrate legacy hardcoded API key out of settings into the provider
    // manager (still empty by default — user must supply their own).
    $manager = new WPCW_Provider_Manager();
    $data = $manager->get_settings_data();
    if (empty($data['configs']['groq']['api_key'])) {
        $legacy = get_option('wpcw_legacy_groq_key', '');
        if ($legacy) {
            $data['configs']['groq']['api_key'] = $legacy;
            $manager->save_settings_data($data);
            delete_option('wpcw_legacy_groq_key');
        }
    }
}
register_activation_hook(__FILE__, 'wp_content_writer_activate');

final class WP_Content_Writer {

    private static $instance = null;
    public $settings;
    public $api;
    public $admin;
    public $providers;

    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->includes();
        $this->init_classes();
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        add_action('rest_api_init', array($this->api, 'register_rest_routes'));
        add_action('admin_notices', array('WPCW_Onboarding', 'render_notice'));
    }

    public function load_textdomain() {
        load_plugin_textdomain('wp-content-writer', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    private function includes() {
        $base = WP_CONTENT_WRITER_PLUGIN_PATH . 'includes/';
        require_once $base . 'class-encryption.php';
        require_once $base . 'class-license.php';
        require_once $base . 'class-usage.php';
        require_once $base . 'class-rate-limiter.php';
        require_once $base . 'class-onboarding.php';
        require_once $base . 'providers/class-provider-base.php';
        require_once $base . 'providers/class-provider-groq.php';
        require_once $base . 'providers/class-provider-openai.php';
        require_once $base . 'providers/class-provider-anthropic.php';
        require_once $base . 'providers/class-provider-gemini.php';
        require_once $base . 'providers/class-provider-openrouter.php';
        require_once $base . 'class-provider-manager.php';
        require_once $base . 'class-settings.php';
        require_once $base . 'class-templates.php';
        require_once $base . 'class-seo.php';
        require_once $base . 'class-plugins-kb.php';
        require_once $base . 'class-site-analyzer.php';
        require_once $base . 'class-site-changer.php';
        require_once $base . 'class-api.php';
        require_once $base . 'class-admin.php';
    }

    private function init_classes() {
        $this->settings  = new WPCW_Settings();
        $this->providers = new WPCW_Provider_Manager();
        $this->api       = new WPCW_API($this->settings, $this->providers);
        $this->admin     = new WPCW_Admin($this->settings, $this->api, $this->providers);
    }
}

function wp_content_writer() {
    return WP_Content_Writer::instance();
}

wp_content_writer();
