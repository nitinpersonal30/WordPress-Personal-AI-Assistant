/**
 * WP Content Writer AI Pro — Admin JS
 * Streaming (SSE), dynamic forms, SEO analysis, Plugin KB, post creation
 */

(function ($) {
    'use strict';

    var D         = window.wpcwData || {};
    var templates = D.templates    || {};
    var tones     = D.tones        || {};
    var languages = D.languages    || [];
    var defLang   = D.defLang      || 'Hindi';
    var defTone   = D.defTone      || 'professional';
    var restUrl   = D.restUrl      || '';
    var nonce     = D.nonce        || '';

    var $placeholder   = $('#wpcw-placeholder');
    var $formContainer = $('#wpcw-form-container');
    var $customPanel   = $('#wpcw-custom-panel');
    var $outputPanel   = $('#wpcw-output-panel');
    var $outputContent = $('#wpcw-output-content');
    var $wordCount     = $('#wpcw-word-count');

    var currentTemplate = null;
    var activeTone      = defTone;
    var isGenerating    = false;
    var lastGeneratedText = '';
    var GEN_STATE_KEY   = 'wpcw_gen_state';

    // =========================================================================
    // GENERATION STATE PERSISTENCE (localStorage)
    // =========================================================================
    function saveGenState(status, text, template) {
        try {
            localStorage.setItem(GEN_STATE_KEY, JSON.stringify({
                status:   status,
                text:     text || '',
                template: template || currentTemplate || '',
                time:     Date.now(),
            }));
        } catch(e) {}
    }

    function getGenState() {
        try {
            var s = JSON.parse(localStorage.getItem(GEN_STATE_KEY) || 'null');
            if (s && (Date.now() - s.time) > 3600000) {
                localStorage.removeItem(GEN_STATE_KEY);
                return null;
            }
            return s;
        } catch(e) { return null; }
    }

    function clearGenState() {
        try { localStorage.removeItem(GEN_STATE_KEY); } catch(e) {}
    }

    // Restore content from previous generation on page load
    (function restoreGenState() {
        var state = getGenState();
        if (!state || !state.text) return;

        if (state.status === 'generating') {
            saveGenState('interrupted', state.text, state.template);
            state.status = 'interrupted';
        }

        if (state.status === 'interrupted' || state.status === 'completed') {
            lastGeneratedText = state.text;
            renderMarkdown(state.text);
            $outputPanel.show();
            $placeholder.hide();
            updateWordCount(state.text);

            var label = state.status === 'interrupted'
                ? 'Content generation interrupted — showing saved content'
                : 'Previously generated content restored';

            $outputContent.before(
                '<div class="wpcw-restore-notice" style="background:#fef3c7;border:1px solid #f59e0b;border-radius:8px;padding:10px 14px;margin-bottom:12px;font-size:13px;color:#92400e;display:flex;align-items:center;gap:8px;">' +
                '<span class="dashicons dashicons-warning" style="color:#f59e0b;"></span>' +
                '<span>' + label + '</span>' +
                '<button class="wpcw-dismiss-restore" style="margin-left:auto;background:none;border:none;color:#92400e;cursor:pointer;font-size:16px;">&times;</button>' +
                '</div>'
            );
        }
    })();

    $(document).on('click', '.wpcw-dismiss-restore', function() {
        $(this).closest('.wpcw-restore-notice').remove();
        clearGenState();
    });

    // Save state before user navigates away
    $(window).on('beforeunload', function () {
        if (isGenerating && lastGeneratedText) {
            saveGenState('interrupted', lastGeneratedText, currentTemplate);
        }
    });

    // =========================================================================
    // TEMPLATE SEARCH
    // =========================================================================
    $('#wpcw-template-search').on('input', function () {
        var q = this.value.toLowerCase().trim();
        $('.wpcw-template-item').each(function () {
            $(this).toggle(!q || String($(this).data('search')).indexOf(q) !== -1);
        });
        $('.wpcw-template-group').each(function () {
            var $visible = $(this).find('.wpcw-template-item:visible');
            $(this).toggle($visible.length > 0);
        });
    });

    // =========================================================================
    // TEMPLATE CLICK
    // =========================================================================
    $(document).on('click', '.wpcw-template-item', function () {
        var key = String($(this).data('key'));
        $('.wpcw-template-item').removeClass('active');
        $(this).addClass('active');

        clearOutput();

        if (key === '__custom__') {
            $placeholder.hide(); $formContainer.hide(); $customPanel.show();
            currentTemplate = null;
            return;
        }

        currentTemplate = key;
        $placeholder.hide(); $customPanel.hide();
        renderForm(key);
        $formContainer.show();
    });

    // =========================================================================
    // RENDER DYNAMIC FORM
    // =========================================================================
    function renderForm(key) {
        var tpl = templates[key];
        if (!tpl) return;

        $('#wpcw-form-title').text(tpl.label);
        $('#wpcw-form-desc').text(tpl.description);
        var $f = $('#wpcw-dynamic-fields').empty();

        $.each(tpl.fields, function (i, field) {
            var id   = 'wpcw-f-' + field.name;
            var $row = $('<div class="wpcw-field"></div>');
            $row.append('<label for="' + id + '">' + field.label + '</label>');

            if (field.type === 'text') {
                $row.append($('<input type="text">').attr({ id: id, 'data-name': field.name, placeholder: field.placeholder || '' }));

            } else if (field.type === 'textarea') {
                $row.append($('<textarea rows="4"></textarea>').attr({ id: id, 'data-name': field.name, placeholder: field.placeholder || '' }));

            } else if (field.type === 'select') {
                var $s = $('<select>').attr({ id: id, 'data-name': field.name });
                $.each(field.options, function (j, o) { $s.append($('<option>').val(o).text(o)); });
                $row.append($s);

            } else if (field.type === 'tone') {
                var $hidden = $('<input type="hidden">').attr({ id: id, 'data-name': field.name }).val(activeTone);
                var $grid   = $('<div class="wpcw-tone-grid">');
                $.each(tones, function (tk, tl) {
                    $('<div class="wpcw-tone-pill">').text(tl).attr('data-tone', tk)
                        .toggleClass('active', tk === activeTone).appendTo($grid);
                });
                $row.append($hidden).append($grid);

            } else if (field.type === 'language') {
                var $l = $('<select>').attr({ id: id, 'data-name': field.name });
                $.each(languages, function (j, lang) {
                    $('<option>').val(lang).text(lang).prop('selected', lang === defLang).appendTo($l);
                });
                $row.append($l);
            }

            $f.append($row);
        });
    }

    // =========================================================================
    // TONE PILL
    // =========================================================================
    $(document).on('click', '.wpcw-tone-pill', function () {
        activeTone = String($(this).data('tone'));
        $('.wpcw-tone-pill').removeClass('active');
        $(this).addClass('active');
        $(this).closest('.wpcw-field').find('input[type="hidden"]').val(activeTone);
    });

    // =========================================================================
    // COLLECT FIELDS
    // =========================================================================
    function collectFields() {
        var v = {};
        $('#wpcw-dynamic-fields [data-name]').each(function () { v[$(this).data('name')] = $(this).val(); });
        return v;
    }

    function validate() {
        var ok = true;
        $('#wpcw-dynamic-fields input[type="text"]').each(function () {
            if ($.trim($(this).val()) === '' && $(this).closest('.wpcw-field').find('label').text().indexOf('*') > -1) {
                $(this).addClass('wpcw-error');
                ok = false;
            } else {
                $(this).removeClass('wpcw-error');
            }
        });
        return ok;
    }

    // =========================================================================
    // GENERATE BUTTONS
    // =========================================================================
    $('#wpcw-generate-btn').on('click', function () {
        if (isGenerating || !currentTemplate) return;
        if (!validate()) { alert('Please fill in all required fields!'); return; }
        streamGenerate({ template: currentTemplate, fields: collectFields() }, '#wpcw-generate-btn', '#wpcw-loading');
    });

    $('#wpcw-custom-generate-btn').on('click', function () {
        if (isGenerating) return;
        var prompt = $.trim($('#wpcw-custom-prompt').val());
        if (!prompt) { alert('Please write a prompt first!'); return; }
        streamGenerate({ prompt: prompt }, '#wpcw-custom-generate-btn', '#wpcw-custom-loading');
    });

    // =========================================================================
    // STREAMING FETCH (SSE)
    // =========================================================================
    function streamGenerate(payload, btnSel, loadingSel) {
        isGenerating = true;
        $(btnSel).prop('disabled', true);
        $(loadingSel).show();
        $outputContent.html('');
        $('.wpcw-restore-notice').remove();
        $outputPanel.show();
        $wordCount.text('Generating...');
        lastGeneratedText = '';

        var fullText = '';
        var tokenCount = 0;

        // Save initial generating state
        saveGenState('generating', '', currentTemplate);

        fetch(restUrl + 'stream', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce':   nonce,
            },
            body: JSON.stringify(payload),
        })
        .then(function (response) {
            if (!response.ok) {
                return response.json().then(function (e) { throw new Error(e.message || 'Server error'); });
            }

            var reader  = response.body.getReader();
            var decoder = new TextDecoder();
            var buffer  = '';

            function pump() {
                return reader.read().then(function (result) {
                    if (result.done) {
                        doneGenerating(btnSel, loadingSel, fullText);
                        return;
                    }

                    buffer += decoder.decode(result.value, { stream: true });

                    var lines = buffer.split('\n');
                    buffer = lines.pop();

                    lines.forEach(function (line) {
                        line = line.trim();
                        if (!line.startsWith('data: ')) return;
                        var json = line.slice(6);
                        try {
                            var obj = JSON.parse(json);
                            if (obj.error) {
                                $outputContent.html('<div class="wpcw-error-msg">Error: ' + obj.error + '</div>');
                                doneGenerating(btnSel, loadingSel, '');
                                return;
                            }
                            if (obj.token) {
                                fullText += obj.token;
                                lastGeneratedText = fullText;
                                renderMarkdown(fullText);
                                $outputContent[0].scrollTop = $outputContent[0].scrollHeight;

                                // Save to localStorage every 10 tokens for performance
                                tokenCount++;
                                if (tokenCount % 10 === 0) {
                                    saveGenState('generating', fullText, currentTemplate);
                                }
                            }
                        } catch (e) {}
                    });

                    return pump();
                });
            }

            return pump();
        })
        .catch(function (err) {
            console.warn('Streaming failed, fallback:', err);
            fallbackGenerate(payload, btnSel, loadingSel);
        });
    }

    function fallbackGenerate(payload, btnSel, loadingSel) {
        saveGenState('generating', '', currentTemplate);
        $.ajax({
            url: restUrl + 'generate',
            method: 'POST',
            beforeSend: function (xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); },
            contentType: 'application/json',
            data: JSON.stringify(payload),
            timeout: 300000,
            success: function (resp) {
                var content = resp.content || '';
                renderMarkdown(content);
                doneGenerating(btnSel, loadingSel, content);
            },
            error: function (xhr) {
                var msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'Something went wrong!';
                alert('Error: ' + msg);
                doneGenerating(btnSel, loadingSel, '');
            },
        });
    }

    function doneGenerating(btnSel, loadingSel, text) {
        isGenerating = false;
        lastGeneratedText = text;
        $(btnSel).prop('disabled', false);
        $(loadingSel).hide();
        updateWordCount(text);

        // Save completed state so other pages can show notification
        if (text) {
            saveGenState('completed', text, currentTemplate);
        } else {
            clearGenState();
        }
    }

    // =========================================================================
    // MARKDOWN RENDERING
    // =========================================================================
    function renderMarkdown(text) {
        if (typeof marked !== 'undefined' && marked.parse) {
            $outputContent.html(marked.parse(text));
        } else {
            $outputContent.html('<pre style="white-space:pre-wrap;">' + escapeHtml(text) + '</pre>');
        }
    }

    function escapeHtml(text) {
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(text));
        return div.innerHTML;
    }

    // =========================================================================
    // OUTPUT HELPERS
    // =========================================================================
    function clearOutput() {
        $outputContent.html('');
        $wordCount.text('');
        $outputPanel.hide();
        lastGeneratedText = '';
        clearGenState();
        $('.wpcw-restore-notice').remove();
        $('#wpcw-seo-panel').hide();
        $('#wpcw-post-panel').hide();
    }

    function updateWordCount(text) {
        if (!text) { $wordCount.text(''); return; }
        var words = text.trim().split(/\s+/).length;
        $wordCount.text(words + ' words | ' + text.length + ' chars');
    }

    $outputContent.on('input', function () {
        var text = $outputContent.text();
        updateWordCount(text);
    });

    // =========================================================================
    // COPY
    // =========================================================================
    $('#wpcw-copy-btn').on('click', function () {
        var text = lastGeneratedText || $outputContent.text();
        if (!text) return;
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(function () {
                flashBtn('#wpcw-copy-btn', '<span class="dashicons dashicons-yes"></span> Copied!', '<span class="dashicons dashicons-clipboard"></span> Copy');
            });
        } else {
            var $t = $('<textarea style="position:fixed;opacity:0">').val(text).appendTo('body');
            $t[0].select(); document.execCommand('copy'); $t.remove();
            flashBtn('#wpcw-copy-btn', '<span class="dashicons dashicons-yes"></span> Copied!', '<span class="dashicons dashicons-clipboard"></span> Copy');
        }
    });

    // =========================================================================
    // SEO CHECK BUTTON
    // =========================================================================
    $('#wpcw-seo-check-btn').on('click', function () {
        $('#wpcw-seo-panel').toggle();
        $('#wpcw-post-panel').hide();
    });

    $('#wpcw-seo-close').on('click', function () {
        $('#wpcw-seo-panel').hide();
    });

    $('#wpcw-run-seo').on('click', function () {
        var keyword = $.trim($('#wpcw-seo-keyword').val());
        var content = lastGeneratedText || $outputContent.text();
        if (!keyword) { alert('Enter a focus keyword!'); return; }
        if (!content) { alert('No content to analyze!'); return; }

        var $btn = $(this);
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update wpcw-spin"></span> Analyzing...');

        $.ajax({
            url: restUrl + 'seo-analyze',
            method: 'POST',
            beforeSend: function (xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); },
            contentType: 'application/json',
            data: JSON.stringify({
                content: content,
                keyword: keyword,
                title: $.trim($('#wpcw-seo-title').val()),
                description: $.trim($('#wpcw-seo-description').val()),
            }),
            success: function (resp) {
                renderSeoResults(resp.analysis, '#wpcw-seo-results');
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-chart-line"></span> Analyze SEO');
            },
            error: function () {
                alert('SEO analysis failed!');
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-chart-line"></span> Analyze SEO');
            },
        });
    });

    // =========================================================================
    // SEO RESULTS RENDERER
    // =========================================================================
    function renderSeoResults(analysis, targetSel) {
        var $target = $(targetSel);
        var scoreClass = analysis.score >= 80 ? 'excellent' : (analysis.score >= 60 ? 'good' : (analysis.score >= 40 ? 'needs-work' : 'poor'));

        var html = '<div class="wpcw-seo-score-card ' + scoreClass + '">';
        html += '<div class="wpcw-seo-score-circle"><span class="wpcw-score-num">' + analysis.score + '</span><span class="wpcw-score-max">/' + analysis.max_score + '</span></div>';
        html += '<div class="wpcw-seo-score-label">' + analysis.rating.replace('_', ' ').toUpperCase() + '</div>';
        html += '<div class="wpcw-seo-score-meta">' + analysis.word_count + ' words | Keyword density: ' + analysis.keyword_density + '%</div>';
        html += '</div>';

        html += '<div class="wpcw-seo-checks">';
        $.each(analysis.checks, function (key, check) {
            var icon = check.status === 'pass' ? 'yes-alt' : (check.status === 'fail' ? 'dismiss' : 'warning');
            var cls = 'wpcw-check-' + check.status;
            html += '<div class="wpcw-seo-check-item ' + cls + '">';
            html += '<span class="dashicons dashicons-' + icon + '"></span>';
            html += '<span class="wpcw-check-msg">' + check.message + '</span>';
            html += '<span class="wpcw-check-points">' + check.points + ' pts</span>';
            html += '</div>';
        });
        html += '</div>';

        $target.html(html).show();
    }

    // =========================================================================
    // SAVE AS DRAFT (enhanced)
    // =========================================================================
    $('#wpcw-new-post-btn').on('click', function () {
        var content = lastGeneratedText || $outputContent.text();
        if (!content) { alert('Generate content first!'); return; }

        // Extract title from content
        var lines = content.trim().split('\n');
        var title = lines[0].replace(/^#+\s*/, '').replace(/\*+/g, '').trim() || 'AI Generated Post';
        if (title.length > 120) title = title.substring(0, 120);

        $('#wpcw-post-title').val(title);
        $('#wpcw-post-panel').toggle();
        $('#wpcw-seo-panel').hide();
    });

    $('#wpcw-post-close').on('click', function () {
        $('#wpcw-post-panel').hide();
    });

    $('#wpcw-create-post-btn').on('click', function () {
        var content = lastGeneratedText || $outputContent.text();
        if (!content) return;

        var $btn = $(this);
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update wpcw-spin"></span> Creating...');

        $.ajax({
            url: restUrl + 'create-post',
            method: 'POST',
            beforeSend: function (xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); },
            contentType: 'application/json',
            data: JSON.stringify({
                title: $.trim($('#wpcw-post-title').val()) || 'AI Generated Post',
                content: content,
                status: $('#wpcw-post-status').val(),
                category: $.trim($('#wpcw-post-category').val()),
                tags: $.trim($('#wpcw-post-tags').val()),
                focus_keyword: $.trim($('#wpcw-post-keyword').val()),
                seo_title: $.trim($('#wpcw-post-title').val()),
                seo_description: $.trim($('#wpcw-post-meta-desc').val()),
            }),
            success: function (resp) {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-welcome-write-blog"></span> Create Post with SEO');
                var seoMsg = resp.seo_applied ? '\nSEO meta applied via ' + resp.seo_plugin : '';
                var go = confirm('Post created successfully!' + seoMsg + '\n\nOpen in editor?');
                if (go && resp.edit_url) window.open(resp.edit_url, '_blank');
                $('#wpcw-post-panel').hide();
            },
            error: function (xhr) {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-welcome-write-blog"></span> Create Post with SEO');
                var msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'Post creation failed';
                alert('Error: ' + msg);
            },
        });
    });

    // =========================================================================
    // CLEAR
    // =========================================================================
    $('#wpcw-clear-btn').on('click', clearOutput);

    // =========================================================================
    // SEO PAGE
    // =========================================================================
    // Character counters
    $('#wpcw-seo-page-title').on('input', function () {
        $('#wpcw-title-chars').text(this.value.length + '/60');
    });
    $('#wpcw-seo-page-desc').on('input', function () {
        $('#wpcw-desc-chars').text(this.value.length + '/155');
    });

    $('#wpcw-seo-page-analyze').on('click', function () {
        var keyword = $.trim($('#wpcw-seo-page-keyword').val());
        var content = $.trim($('#wpcw-seo-page-content').val());
        if (!keyword || !content) { alert('Keyword and content are required!'); return; }

        var $btn = $(this);
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update wpcw-spin"></span> Analyzing...');

        $.ajax({
            url: restUrl + 'seo-analyze',
            method: 'POST',
            beforeSend: function (xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); },
            contentType: 'application/json',
            data: JSON.stringify({
                content: content,
                keyword: keyword,
                title: $.trim($('#wpcw-seo-page-title').val()),
                description: $.trim($('#wpcw-seo-page-desc').val()),
                url: $.trim($('#wpcw-seo-page-url').val()),
            }),
            success: function (resp) {
                renderSeoResults(resp.analysis, '#wpcw-seo-page-results');
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-chart-line"></span> Analyze SEO Score');
            },
            error: function () {
                alert('SEO analysis failed!');
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-chart-line"></span> Analyze SEO Score');
            },
        });
    });

    // =========================================================================
    // PLUGIN KB PAGE
    // =========================================================================
    var $pluginCategories = $('#wpcw-plugin-categories');
    var $pluginResults    = $('#wpcw-plugin-results');
    var $pluginList       = $('#wpcw-plugin-list');

    // Category click
    $(document).on('click', '.wpcw-plugin-category-card', function () {
        var cat = $(this).data('category');
        var catName = $(this).find('.wpcw-cat-name').text();

        $pluginCategories.hide();
        $pluginResults.show();
        $('#wpcw-results-title').text(catName);

        // Fetch from REST
        $.ajax({
            url: restUrl + 'plugins/search?q=' + encodeURIComponent(cat),
            beforeSend: function (xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); },
            success: function (resp) {
                renderPluginList(resp.results);
            },
        });
    });

    // Search
    var pluginSearchTimer;
    $('#wpcw-plugin-search').on('input', function () {
        var q = $.trim(this.value);
        clearTimeout(pluginSearchTimer);
        if (q.length < 2) {
            $pluginResults.hide();
            $pluginCategories.show();
            return;
        }
        pluginSearchTimer = setTimeout(function () {
            $pluginCategories.hide();
            $pluginResults.show();
            $('#wpcw-results-title').text('Search: "' + q + '"');

            $.ajax({
                url: restUrl + 'plugins/search?q=' + encodeURIComponent(q),
                beforeSend: function (xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); },
                success: function (resp) {
                    renderPluginList(resp.results);
                },
            });
        }, 300);
    });

    // Type filter
    $('#wpcw-plugin-type-filter').on('change', function () {
        var type = this.value;
        $('.wpcw-plugin-card').each(function () {
            if (type === 'all') { $(this).show(); return; }
            $(this).toggle($(this).data('type') === type);
        });
    });

    // Back to categories
    $('#wpcw-back-to-categories').on('click', function () {
        $pluginResults.hide();
        $pluginCategories.show();
    });

    function renderPluginList(plugins) {
        if (!plugins || !plugins.length) {
            $pluginList.html('<p class="wpcw-no-results">No plugins found.</p>');
            return;
        }

        var html = '';
        $.each(plugins, function (i, p) {
            var typeClass = p.type === 'free' ? 'wpcw-type-free' : (p.type === 'premium' ? 'wpcw-type-premium' : 'wpcw-type-freemium');
            var stars = '';
            for (var s = 0; s < 5; s++) {
                stars += s < p.rating ? '<span class="dashicons dashicons-star-filled"></span>' : '<span class="dashicons dashicons-star-empty"></span>';
            }

            html += '<div class="wpcw-plugin-card" data-type="' + p.type + '">';
            html += '<div class="wpcw-plugin-card-header">';
            html += '<h3>' + escapeHtml(p.name) + '</h3>';
            html += '<span class="wpcw-plugin-type ' + typeClass + '">' + p.type.toUpperCase() + '</span>';
            html += '</div>';
            html += '<div class="wpcw-plugin-rating">' + stars + '</div>';
            html += '<p class="wpcw-plugin-desc">' + escapeHtml(p.desc) + '</p>';
            html += '<div class="wpcw-plugin-best-for"><strong>Best for:</strong> ' + escapeHtml(p.best_for) + '</div>';
            if (p.slug && p.slug !== 'flavor') {
                html += '<a href="https://wordpress.org/plugins/' + p.slug + '/" target="_blank" class="button wpcw-btn-small">View on WordPress.org</a>';
            }
            html += '</div>';
        });

        $pluginList.html(html);
    }

    // =========================================================================
    // WEBSITE ANALYZER PAGE
    // =========================================================================

    // Load site overview on page load
    if ($('#wpcw-site-stats').length) {
        loadSiteOverview();
    }

    function loadSiteOverview() {
        $.ajax({
            url: restUrl + 'site/overview',
            beforeSend: function (xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); },
            success: function (resp) {
                renderSiteStats(resp);
                renderSitePages(resp);
                renderSitePosts(resp);
                renderSitePlugins(resp);
                renderSiteSeoStatus(resp);
            },
            error: function () {
                $('#wpcw-site-stats').html('<p class="wpcw-error-msg">Failed to load site data. Make sure you are an admin.</p>');
            },
        });
    }

    function renderSiteStats(data) {
        var si = data.site_info || {};
        var cs = data.content_stats || {};
        var seo = data.seo_status || {};
        var perf = data.performance || {};
        var media = data.media_stats || {};

        var posts_count = cs.post ? cs.post.published : 0;
        var pages_count = cs.page ? cs.page.published : 0;

        var html = '';
        html += '<div class="wpcw-site-stat-card"><span class="wpcw-stat-number">' + posts_count + '</span><span class="wpcw-stat-label">Published Posts</span></div>';
        html += '<div class="wpcw-site-stat-card"><span class="wpcw-stat-number">' + pages_count + '</span><span class="wpcw-stat-label">Published Pages</span></div>';
        html += '<div class="wpcw-site-stat-card"><span class="wpcw-stat-number">' + (data.active_plugins ? data.active_plugins.length : 0) + '</span><span class="wpcw-stat-label">Active Plugins</span></div>';
        html += '<div class="wpcw-site-stat-card"><span class="wpcw-stat-number">' + (seo.without_seo_meta || 0) + '</span><span class="wpcw-stat-label">Posts Missing SEO</span></div>';
        html += '<div class="wpcw-site-stat-card"><span class="wpcw-stat-number">' + (seo.without_featured_image || 0) + '</span><span class="wpcw-stat-label">No Featured Image</span></div>';
        html += '<div class="wpcw-site-stat-card"><span class="wpcw-stat-number">' + (media.total || 0) + '</span><span class="wpcw-stat-label">Media Files</span></div>';
        html += '<div class="wpcw-site-stat-card"><span class="wpcw-stat-number">' + escapeHtml(si.wp_version || '') + '</span><span class="wpcw-stat-label">WordPress</span></div>';
        html += '<div class="wpcw-site-stat-card"><span class="wpcw-stat-number">' + escapeHtml((data.theme_info || {}).name || '') + '</span><span class="wpcw-stat-label">Theme</span></div>';

        $('#wpcw-site-stats').html(html);
    }

    function renderSitePages(data) {
        var pages = [];
        // Get from overview — load separately
        $.ajax({
            url: restUrl + 'site/pages?limit=50',
            beforeSend: function (xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); },
            success: function (resp) {
                var items = resp.pages || [];
                $('#wpcw-pages-count').text(items.length);
                var html = '';
                $.each(items, function (i, p) {
                    html += '<div class="wpcw-site-data-item">';
                    html += '<span class="wpcw-data-title">' + escapeHtml(p.title || 'Untitled') + '</span>';
                    html += '<span class="wpcw-data-meta">' + p.word_count + ' words | ' + p.status + '</span>';
                    html += '</div>';
                });
                $('#wpcw-site-pages-list').html(html || '<p>No pages found.</p>');
            },
        });
    }

    function renderSitePosts(data) {
        $.ajax({
            url: restUrl + 'site/posts?limit=50',
            beforeSend: function (xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); },
            success: function (resp) {
                var items = resp.posts || [];
                $('#wpcw-posts-count').text(items.length);
                var html = '';
                $.each(items, function (i, p) {
                    var seoIcon = (p.seo && p.seo.focus_keyword) ? '<span class="dashicons dashicons-yes" style="color:#22c55e;font-size:14px;width:14px;height:14px;"></span>' : '<span class="dashicons dashicons-no" style="color:#ef4444;font-size:14px;width:14px;height:14px;"></span>';
                    html += '<div class="wpcw-site-data-item">';
                    html += '<span class="wpcw-data-title">' + escapeHtml(p.title || 'Untitled') + ' ' + seoIcon + '</span>';
                    html += '<span class="wpcw-data-meta">' + p.word_count + ' words | ' + (p.categories || []).join(', ') + '</span>';
                    html += '</div>';
                });
                $('#wpcw-site-posts-list').html(html || '<p>No posts found.</p>');
            },
        });
    }

    function renderSitePlugins(data) {
        var plugins = data.active_plugins || [];
        $('#wpcw-active-plugins-count').text(plugins.length);
        var html = '';
        $.each(plugins, function (i, p) {
            html += '<div class="wpcw-site-data-item">';
            html += '<span class="wpcw-data-title">' + escapeHtml(p.name) + '</span>';
            html += '<span class="wpcw-data-meta">v' + escapeHtml(p.version) + '</span>';
            html += '</div>';
        });
        $('#wpcw-site-plugins-list').html(html || '<p>No plugins found.</p>');
    }

    function renderSiteSeoStatus(data) {
        var seo = data.seo_status || {};
        var html = '<div class="wpcw-site-seo-summary">';
        html += '<p><strong>SEO Plugin:</strong> ' + (seo.seo_plugin || 'None') + '</p>';
        html += '<p><strong>Published:</strong> ' + (seo.total_published || 0) + ' pages/posts</p>';
        html += '<p><strong>Missing SEO:</strong> ' + (seo.without_seo_meta || 0) + '</p>';
        html += '<p><strong>No Featured Image:</strong> ' + (seo.without_featured_image || 0) + '</p>';
        html += '</div>';
        $('#wpcw-site-seo-status').html(html);
    }

    // AI Analyze button
    $('#wpcw-site-analyze-btn').on('click', function () {
        var question = $.trim($('#wpcw-site-question').val());
        runSiteAiAnalysis(question);
    });

    $('#wpcw-site-full-scan-btn').on('click', function () {
        runSiteAiAnalysis('');
    });

    function runSiteAiAnalysis(question) {
        var $result  = $('#wpcw-site-ai-result');
        var $loading = $('#wpcw-site-ai-loading');
        $result.hide();
        $loading.show();

        $.ajax({
            url: restUrl + 'site/ai-analyze',
            method: 'POST',
            beforeSend: function (xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); },
            contentType: 'application/json',
            data: JSON.stringify({ question: question }),
            timeout: 200000,
            success: function (resp) {
                $loading.hide();
                var analysisHtml = '';
                if (typeof marked !== 'undefined' && marked.parse) {
                    analysisHtml = marked.parse(resp.analysis || '');
                } else {
                    analysisHtml = '<pre style="white-space:pre-wrap;">' + escapeHtml(resp.analysis || '') + '</pre>';
                }
                $result.html('<div class="wpcw-ai-analysis-output">' + analysisHtml + '</div>').show();
            },
            error: function () {
                $loading.hide();
                $result.html('<div class="wpcw-error-msg">AI analysis failed. Make sure your Groq API key is valid.</div>').show();
            },
        });
    }

    // =========================================================================
    // SITE-WIDE CHANGES PAGE
    // =========================================================================

    // AI-Powered Changes
    $('#wpcw-ai-change-btn').on('click', function () {
        var instruction = $.trim($('#wpcw-ai-instruction').val());
        if (!instruction) { alert('Instruction likho pehle!'); return; }

        var $btn     = $(this);
        var $loading = $('#wpcw-ai-change-loading');
        var $preview = $('#wpcw-ai-change-preview');
        $btn.prop('disabled', true);
        $loading.show();
        $preview.hide();

        $.ajax({
            url: restUrl + 'changes/ai-apply',
            method: 'POST',
            beforeSend: function (xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); },
            contentType: 'application/json',
            data: JSON.stringify({ instruction: instruction }),
            timeout: 200000,
            success: function (resp) {
                $btn.prop('disabled', false);
                $loading.hide();

                if (resp.success && resp.preview) {
                    renderAiChangesPreview(resp.changes, resp.instruction);
                } else if (resp.ai_response) {
                    var html = '<div class="wpcw-ai-suggestion">';
                    html += '<h4>AI Suggestion:</h4>';
                    if (typeof marked !== 'undefined') html += marked.parse(resp.ai_response);
                    else html += '<pre>' + escapeHtml(resp.ai_response) + '</pre>';
                    html += '</div>';
                    $preview.html(html).show();
                } else {
                    alert('No changes generated.');
                }
            },
            error: function () {
                $btn.prop('disabled', false);
                $loading.hide();
                alert('AI change generation failed!');
            },
        });
    });

    function renderAiChangesPreview(changes, instruction) {
        var $preview = $('#wpcw-ai-change-preview');
        var html = '<div class="wpcw-changes-preview">';
        html += '<h3><span class="dashicons dashicons-visibility"></span> Preview of ' + changes.length + ' Changes</h3>';
        html += '<p class="wpcw-preview-instruction"><strong>Instruction:</strong> ' + escapeHtml(instruction) + '</p>';

        $.each(changes, function (i, ch) {
            html += '<div class="wpcw-change-item">';
            html += '<span class="wpcw-change-type">' + (ch.type || 'unknown').toUpperCase() + '</span> ';
            if (ch.type === 'find_replace') {
                html += 'Replace "' + escapeHtml(ch.search || '') + '" with "' + escapeHtml(ch.replace || '') + '"';
            } else if (ch.type === 'add_css') {
                html += 'Add CSS: <code>' + escapeHtml((ch.css || '').substring(0, 80)) + '</code>';
            } else if (ch.type === 'update_post') {
                html += 'Update post ID ' + (ch.post_id || '?');
            } else if (ch.type === 'site_identity') {
                html += 'Update site: ' + escapeHtml(JSON.stringify(ch.data || {}));
            } else {
                html += escapeHtml(JSON.stringify(ch));
            }
            html += '</div>';
        });

        html += '<div class="wpcw-preview-actions">';
        html += '<button class="button button-primary" id="wpcw-apply-ai-changes"><span class="dashicons dashicons-yes"></span> Apply All Changes</button>';
        html += '<button class="button" id="wpcw-cancel-ai-changes"><span class="dashicons dashicons-no"></span> Cancel</button>';
        html += '</div>';
        html += '</div>';

        $preview.html(html).show();

        // Store changes for apply
        $preview.data('changes', changes);
    }

    $(document).on('click', '#wpcw-apply-ai-changes', function () {
        var $preview = $('#wpcw-ai-change-preview');
        var changes  = $preview.data('changes');
        if (!changes || !changes.length) return;

        if (!confirm('Are you sure? This will modify your website content. ' + changes.length + ' changes will be applied.')) return;

        var $btn = $(this);
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update wpcw-spin"></span> Applying...');

        // Apply changes one by one using the appropriate endpoints
        var completed = 0;
        var results = [];

        function applyNext() {
            if (completed >= changes.length) {
                $btn.html('<span class="dashicons dashicons-yes"></span> Done!');
                alert('All ' + changes.length + ' changes applied successfully!');
                return;
            }

            var ch = changes[completed];
            var ajaxConfig = null;

            if (ch.type === 'find_replace') {
                ajaxConfig = { url: restUrl + 'changes/find-replace', data: JSON.stringify({ search: ch.search, replace: ch.replace, options: ch.options || {} }) };
            } else if (ch.type === 'add_css') {
                ajaxConfig = { url: restUrl + 'changes/css', data: JSON.stringify({ css: ch.css, mode: ch.mode || 'append' }) };
            } else if (ch.type === 'bulk_seo') {
                ajaxConfig = { url: restUrl + 'changes/bulk-seo', data: JSON.stringify({ options: ch.options || {} }) };
            } else if (ch.type === 'image_alt') {
                ajaxConfig = { url: restUrl + 'changes/image-alt', data: JSON.stringify({ options: ch.options || {} }) };
            }

            if (ajaxConfig) {
                $.ajax({
                    url: ajaxConfig.url,
                    method: 'POST',
                    beforeSend: function (xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); },
                    contentType: 'application/json',
                    data: ajaxConfig.data,
                    success: function () { completed++; applyNext(); },
                    error: function () { completed++; applyNext(); },
                });
            } else {
                completed++;
                applyNext();
            }
        }

        applyNext();
    });

    $(document).on('click', '#wpcw-cancel-ai-changes', function () {
        $('#wpcw-ai-change-preview').hide();
    });

    // Find & Replace
    $('#wpcw-fr-btn').on('click', function () {
        var search  = $.trim($('#wpcw-fr-search').val());
        if (!search) { alert('Search text is required!'); return; }

        var fields = [];
        if ($('#wpcw-fr-title').is(':checked'))   fields.push('title');
        if ($('#wpcw-fr-content').is(':checked')) fields.push('content');
        if ($('#wpcw-fr-excerpt').is(':checked')) fields.push('excerpt');

        var $btn = $(this);
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update wpcw-spin"></span> Processing...');

        $.ajax({
            url: restUrl + 'changes/find-replace',
            method: 'POST',
            beforeSend: function (xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); },
            contentType: 'application/json',
            data: JSON.stringify({
                search: search,
                replace: $.trim($('#wpcw-fr-replace').val()),
                options: {
                    fields: fields,
                    case_sensitive: $('#wpcw-fr-case').is(':checked'),
                    dry_run: $('#wpcw-fr-dry').is(':checked'),
                },
            }),
            success: function (resp) {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-search"></span> Find & Replace');
                var html = '<div class="wpcw-tool-result">';
                html += '<p><strong>' + (resp.dry_run ? 'DRY RUN - ' : '') + resp.total_replacements + ' replacements</strong> in ' + resp.posts_changed + ' posts (scanned ' + resp.total_posts_scanned + ')</p>';
                if (resp.changed && resp.changed.length) {
                    html += '<ul>';
                    $.each(resp.changed, function (i, c) {
                        html += '<li>' + escapeHtml(c.title) + ' (' + c.type + ') - ' + c.replacements + ' replacements</li>';
                    });
                    html += '</ul>';
                }
                html += '</div>';
                $('#wpcw-fr-result').html(html).show();
            },
            error: function () {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-search"></span> Find & Replace');
                alert('Find & Replace failed!');
            },
        });
    });

    // Bulk SEO
    $('#wpcw-bulk-seo-btn').on('click', function () {
        var $btn = $(this);
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update wpcw-spin"></span> Processing...');

        $.ajax({
            url: restUrl + 'changes/bulk-seo',
            method: 'POST',
            beforeSend: function (xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); },
            contentType: 'application/json',
            data: JSON.stringify({
                options: {
                    only_empty: $('#wpcw-seo-empty').is(':checked'),
                    dry_run: $('#wpcw-seo-dry').is(':checked'),
                },
            }),
            success: function (resp) {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-chart-line"></span> Bulk Update SEO');
                var html = '<div class="wpcw-tool-result">';
                html += '<p><strong>' + (resp.dry_run ? 'DRY RUN - ' : '') + resp.total_updated + ' posts updated</strong> (scanned ' + resp.total_scanned + ')</p>';
                if (resp.updated && resp.updated.length) {
                    html += '<ul>';
                    $.each(resp.updated.slice(0, 20), function (i, u) {
                        html += '<li>' + escapeHtml(u.title) + ' → keyword: "' + escapeHtml(u.keyword) + '"</li>';
                    });
                    html += '</ul>';
                }
                html += '</div>';
                $('#wpcw-bulk-seo-result').html(html).show();
            },
            error: function (xhr) {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-chart-line"></span> Bulk Update SEO');
                var msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : 'Bulk SEO update failed!';
                alert(msg);
            },
        });
    });

    // Custom CSS
    $('#wpcw-css-btn').on('click', function () {
        var css = $.trim($('#wpcw-css-code').val());
        if (!css) { alert('CSS code is required!'); return; }

        var $btn = $(this);
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update wpcw-spin"></span> Applying...');

        $.ajax({
            url: restUrl + 'changes/css',
            method: 'POST',
            beforeSend: function (xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); },
            contentType: 'application/json',
            data: JSON.stringify({ css: css, mode: $('#wpcw-css-mode').val() }),
            success: function (resp) {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-editor-code"></span> Apply CSS');
                $('#wpcw-css-result').html('<div class="wpcw-tool-result"><p>CSS applied successfully! Total CSS length: ' + resp.css_length + ' chars</p></div>').show();
            },
            error: function () {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-editor-code"></span> Apply CSS');
                alert('CSS update failed!');
            },
        });
    });

    // Image Alt Text
    $('#wpcw-alt-btn').on('click', function () {
        var $btn = $(this);
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update wpcw-spin"></span> Processing...');

        $.ajax({
            url: restUrl + 'changes/image-alt',
            method: 'POST',
            beforeSend: function (xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); },
            contentType: 'application/json',
            data: JSON.stringify({ options: { dry_run: $('#wpcw-alt-dry').is(':checked') } }),
            success: function (resp) {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-format-image"></span> Fix Image Alt Text');
                var html = '<div class="wpcw-tool-result">';
                html += '<p><strong>' + (resp.dry_run ? 'DRY RUN - ' : '') + resp.without_alt + ' images</strong> without alt text (total: ' + resp.total_images + ')</p>';
                if (resp.updated && resp.updated.length) {
                    html += '<ul>';
                    $.each(resp.updated.slice(0, 15), function (i, u) {
                        html += '<li>' + escapeHtml(u.title) + ' → "' + escapeHtml(u.alt) + '"</li>';
                    });
                    html += '</ul>';
                }
                html += '</div>';
                $('#wpcw-alt-result').html(html).show();
            },
            error: function () {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-format-image"></span> Fix Image Alt Text');
                alert('Image alt update failed!');
            },
        });
    });

    // =========================================================================
    // HELPERS
    // =========================================================================
    function flashBtn(sel, tempHtml, origHtml) {
        $(sel).html(tempHtml);
        setTimeout(function () { $(sel).html(origHtml); }, 2000);
    }

})(jQuery);
