/**
 * Front-end JS for the SaaS admin pages — Providers, Usage Analytics,
 * License, Onboarding. Uses the existing wpcwData.restUrl + nonce so it
 * works with the same REST permission_callback.
 */
(function ($) {
    'use strict';

    function rest(method, path, body) {
        return $.ajax({
            url: wpcwData.restUrl + path,
            method: method,
            contentType: 'application/json',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', wpcwData.nonce);
            },
            data: body ? JSON.stringify(body) : undefined,
        });
    }

    // ── PROVIDERS ─────────────────────────────────────────────────────
    function initProvidersPage() {
        var $app = $('#wpcw-providers-app');
        if (!$app.length) return;

        $app.on('click', '.wpcw-prov-test', function () {
            var $card = $(this).closest('.wpcw-provider-card');
            var id    = $card.data('provider');
            var $msg  = $card.find('.wpcw-prov-test-result');
            var key   = ($card.find('.wpcw-prov-key').val() || '').trim();
            var model = $card.find('.wpcw-prov-model').val();
            var base  = $card.find('.wpcw-prov-base').val();

            // Save the in-flight key before testing so the manager can use it.
            var saveBody = collectAll();
            if (key) saveBody.configs[id].api_key = key;
            if (model) saveBody.configs[id].model = model;
            if (base) saveBody.configs[id].base_url = base;

            $msg.removeClass('is-ok is-error').text('Testing…');
            rest('POST', 'providers', saveBody).then(function () {
                return rest('POST', 'providers/test', { provider: id });
            }).done(function (res) {
                if (res && res.success) {
                    $msg.addClass('is-ok').text('OK — ' + (res.model || 'reachable'));
                } else {
                    $msg.addClass('is-error').text((res && res.message) || 'Test failed.');
                }
            }).fail(function (xhr) {
                $msg.addClass('is-error').text(xhrMessage(xhr) || 'Test failed.');
            });
        });

        function collectAll() {
            var data = { active: 'groq', fallback: [], configs: {} };
            $app.find('input[name="wpcw-active-provider"]:checked').each(function () {
                data.active = $(this).val();
            });
            $app.find('.wpcw-provider-card').each(function () {
                var $c = $(this);
                var id = $c.data('provider');
                if (!id) return;
                var key = ($c.find('.wpcw-prov-key').val() || '').trim();
                data.configs[id] = data.configs[id] || {};
                if (key) data.configs[id].api_key = key;
                data.configs[id].model    = $c.find('.wpcw-prov-model').val() || '';
                data.configs[id].base_url = $c.find('.wpcw-prov-base').val() || '';
                if ($c.find('.wpcw-prov-fallback').is(':checked')) data.fallback.push(id);
            });
            return data;
        }

        $('#wpcw-providers-save').on('click', function () {
            var $msg = $('.wpcw-saas-save-msg');
            $msg.removeClass('is-ok is-error').text('Saving…');
            rest('POST', 'providers', collectAll())
                .done(function () { $msg.addClass('is-ok').text('Saved.'); })
                .fail(function (xhr) { $msg.addClass('is-error').text(xhrMessage(xhr) || 'Save failed.'); });
        });
    }

    // ── USAGE ─────────────────────────────────────────────────────────
    function initUsagePage() {
        if (!window.wpcwUsageData || typeof Chart === 'undefined') return;
        var d = window.wpcwUsageData;

        var dailyEl = document.getElementById('wpcw-chart-daily');
        if (dailyEl && d.daily) {
            new Chart(dailyEl, {
                type: 'bar',
                data: {
                    labels: d.daily.map(function (x) { return x.day; }),
                    datasets: [{
                        label: 'Words',
                        data: d.daily.map(function (x) { return x.words; }),
                        backgroundColor: '#6366f1',
                    }],
                },
                options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } },
            });
        }

        var monthsEl = document.getElementById('wpcw-chart-months');
        if (monthsEl && d.months) {
            new Chart(monthsEl, {
                type: 'line',
                data: {
                    labels: d.months.map(function (x) { return x.label; }),
                    datasets: [{
                        label: 'Words',
                        data: d.months.map(function (x) { return x.words; }),
                        borderColor: '#16a34a',
                        backgroundColor: 'rgba(22,163,74,0.1)',
                        fill: true,
                        tension: 0.3,
                    }],
                },
                options: { plugins: { legend: { display: false } } },
            });
        }

        var provEl = document.getElementById('wpcw-chart-providers');
        if (provEl && d.by_provider) {
            var provLabels = Object.keys(d.by_provider);
            var provValues = provLabels.map(function (k) { return d.by_provider[k].words; });
            new Chart(provEl, {
                type: 'doughnut',
                data: {
                    labels: provLabels,
                    datasets: [{
                        data: provValues,
                        backgroundColor: ['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981'],
                    }],
                },
            });
        }
    }

    // ── LICENSE ───────────────────────────────────────────────────────
    function initLicensePage() {
        var $app = $('#wpcw-license-app');
        if (!$app.length) return;

        $('#wpcw-license-activate-btn').on('click', function () {
            var key = ($('#wpcw-license-key').val() || '').trim();
            var $msg = $('.wpcw-license-msg');
            if (!key) {
                $msg.attr('class', 'wpcw-license-msg is-error').text('License key required.');
                return;
            }
            $msg.attr('class', 'wpcw-license-msg').text('Activating…');
            rest('POST', 'license/activate', { license_key: key })
                .done(function (res) {
                    if (res && res.success) {
                        $msg.attr('class', 'wpcw-license-msg is-ok').text(res.message || 'Activated.');
                        setTimeout(function () { window.location.reload(); }, 800);
                    } else {
                        $msg.attr('class', 'wpcw-license-msg is-error').text((res && res.message) || 'Activation failed.');
                    }
                })
                .fail(function (xhr) {
                    $msg.attr('class', 'wpcw-license-msg is-error').text(xhrMessage(xhr) || 'Activation failed.');
                });
        });

        $('#wpcw-license-deactivate-btn').on('click', function () {
            if (!window.confirm('Deactivate license? This site will revert to the Free tier.')) return;
            rest('POST', 'license/deactivate', {}).done(function () { window.location.reload(); });
        });
    }

    // ── ONBOARDING ────────────────────────────────────────────────────
    function initOnboardingPage() {
        var $app = $('#wpcw-onboarding-app');
        if (!$app.length) return;

        function go(step) {
            $app.find('.wpcw-onboarding-section').removeClass('is-visible');
            $app.find('.wpcw-onboarding-section[data-step="' + step + '"]').addClass('is-visible');
            $app.find('.wpcw-step').removeClass('is-active').filter('[data-step="' + step + '"]').addClass('is-active');
        }

        $app.on('click', '[data-next]', function () {
            var next = parseInt($(this).data('next'), 10);
            // Step 1 — save provider key.
            if (next === 2) {
                var pid = $app.find('input[name="onboard-provider"]:checked').val();
                var key = ($('#wpcw-onboard-key').val() || '').trim();
                if (!pid || !key) {
                    $('.wpcw-onboard-msg').attr('class', 'wpcw-onboard-msg is-error').text('Provider + API key required.');
                    return;
                }
                $('.wpcw-onboard-msg').attr('class', 'wpcw-onboard-msg').text('Saving…');
                var body = { active: pid, fallback: [], configs: {} };
                body.configs[pid] = { api_key: key };
                rest('POST', 'providers', body)
                    .done(function () { go(next); })
                    .fail(function (xhr) { $('.wpcw-onboard-msg').attr('class', 'wpcw-onboard-msg is-error').text(xhrMessage(xhr) || 'Save failed.'); });
                return;
            }
            // Step 2 — optional license.
            if (next === 3) {
                var lic = ($('#wpcw-onboard-license').val() || '').trim();
                if (lic) {
                    rest('POST', 'license/activate', { license_key: lic }).always(function () { go(next); });
                } else {
                    go(next);
                }
                return;
            }
            go(next);
        });

        $app.on('click', '[data-prev]', function () {
            go(parseInt($(this).data('prev'), 10));
        });

        $('#wpcw-onboard-finish').on('click', function () {
            rest('POST', 'onboarding/complete', {}).always(function () {
                window.location.href = (wpcwData.writerUrl || (window.location.origin + '/wp-admin/admin.php?page=wp-content-writer'));
            });
        });
    }

    function xhrMessage(xhr) {
        try {
            var j = JSON.parse(xhr.responseText);
            if (j && j.message) return j.message;
        } catch (_) {}
        return '';
    }

    $(function () {
        initProvidersPage();
        initUsagePage();
        initLicensePage();
        initOnboardingPage();
    });
})(jQuery);
