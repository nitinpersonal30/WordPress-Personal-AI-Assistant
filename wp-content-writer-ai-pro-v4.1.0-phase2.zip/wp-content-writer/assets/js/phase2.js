/* eslint-env browser, jquery */
/*
 * Phase 2 admin module — calendar, review queue, brand voice, bulk
 * generation, activity log, and team. One bundle for all six pages;
 * each renderer gates on the current page hook so unused pieces don't
 * boot.
 */
(function ($) {
    'use strict';

    var cfg = window.wpcwPhase2 || {};

    function api(path, options) {
        options = options || {};
        return $.ajax({
            url: cfg.restUrl + path.replace(/^\//, ''),
            method: options.method || 'GET',
            data: options.data,
            contentType: options.contentType || 'application/json',
            dataType: 'json',
            beforeSend: function (xhr) {
                if (cfg.nonce) xhr.setRequestHeader('X-WP-Nonce', cfg.nonce);
            }
        });
    }
    function apiJson(path, body, method) {
        return api(path, { method: method || 'POST', data: JSON.stringify(body || {}) });
    }
    function escHtml(s) {
        return $('<div/>').text(s == null ? '' : String(s)).html();
    }
    function notify(msg, type) {
        var el = $('<div class="notice notice-' + (type || 'success') + ' is-dismissible"><p></p></div>');
        el.find('p').text(msg);
        $('.wrap.wpcw-phase2 > h1').first().after(el);
        setTimeout(function () { el.fadeOut(400, function () { el.remove(); }); }, 4000);
    }

    var page = cfg.currentPage || '';

    $(function () {
        if (page.indexOf('calendar') > -1)     initCalendar();
        if (page.indexOf('workflow') > -1)     initWorkflow();
        if (page.indexOf('brand-voice') > -1)  initBrandVoice();
        if (page.indexOf('bulk') > -1)         initBulk();
        if (page.indexOf('activity') > -1)     initActivity();
        if (page.indexOf('team') > -1)         initTeam();
    });

    // =================================================================
    // CALENDAR
    // =================================================================
    function initCalendar() {
        var view = new Date(); view.setDate(1);

        function fmt(d) { return d.toISOString().slice(0, 10); }
        function pad(n) { return n < 10 ? '0' + n : '' + n; }

        function rangeForView(date) {
            var first = new Date(date.getFullYear(), date.getMonth(), 1);
            var last  = new Date(date.getFullYear(), date.getMonth() + 1, 0);
            // Pad to the start of the calendar grid (Mon as week start).
            var start = new Date(first); start.setDate(first.getDate() - ((first.getDay() + 6) % 7));
            var end   = new Date(last);  end.setDate(last.getDate() + (6 - ((last.getDay() + 6) % 7)));
            return { first: first, last: last, start: start, end: end };
        }

        function render() {
            var r = rangeForView(view);
            $('#wpcw-cal-month').text(view.toLocaleString(undefined, { month: 'long', year: 'numeric' }));
            api('calendar?start=' + fmt(r.start) + '&end=' + fmt(r.end)).done(function (data) {
                paint(r, data || { by_day: {} });
            }).fail(function (xhr) { notify((xhr.responseJSON && xhr.responseJSON.message) || 'Failed to load calendar.', 'error'); });
        }

        function paint(r, data) {
            var grid = $('#wpcw-calendar-grid').empty();
            var weekDays = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
            weekDays.forEach(function (d) {
                grid.append('<div class="wpcw-cal-day wpcw-cal-head"><strong>' + d + '</strong></div>');
            });
            var d = new Date(r.start);
            while (d <= r.end) {
                var iso = fmt(d);
                var inMonth = d.getMonth() === view.getMonth();
                var today = iso === cfg.today;
                var $cell = $('<div class="wpcw-cal-day"></div>')
                    .toggleClass('is-today', today)
                    .toggleClass('is-other-month', !inMonth)
                    .attr('data-date', iso)
                    .append('<div class="wpcw-cal-daynum"><span>' + pad(d.getDate()) + '</span></div>');
                var items = data.by_day[iso] || [];
                items.forEach(function (it) {
                    var $it = $('<div class="wpcw-cal-item" draggable="true"></div>')
                        .addClass('wpcw-cal-item--' + (it.workflow || 'draft'))
                        .attr('data-id', it.id)
                        .attr('title', it.title + ' — ' + (it.author_name || ''))
                        .text(it.title);
                    if (it.post_status === 'future') $it.addClass('wpcw-cal-item--scheduled');
                    $cell.append($it);
                });
                grid.append($cell);
                d.setDate(d.getDate() + 1);
            }
            wireDnd();
        }

        function wireDnd() {
            $('.wpcw-cal-item').on('dragstart', function (e) {
                e.originalEvent.dataTransfer.setData('text/plain', $(this).data('id'));
                e.originalEvent.dataTransfer.effectAllowed = 'move';
            });
            $('.wpcw-cal-day[data-date]').on('dragover', function (e) {
                e.preventDefault();
                $(this).addClass('is-drop-target');
            }).on('dragleave drop', function () { $(this).removeClass('is-drop-target'); });

            $('.wpcw-cal-day[data-date]').on('drop', function (e) {
                e.preventDefault();
                var id = e.originalEvent.dataTransfer.getData('text/plain');
                var date = $(this).data('date');
                if (!id || !date) return;
                apiJson('calendar/move', { post_id: parseInt(id, 10), date: date })
                    .done(function () { notify('Moved.'); render(); })
                    .fail(function (xhr) { notify((xhr.responseJSON && xhr.responseJSON.message) || 'Move failed.', 'error'); });
            });
        }

        $('#wpcw-cal-prev').on('click', function () { view.setMonth(view.getMonth() - 1); render(); });
        $('#wpcw-cal-next').on('click', function () { view.setMonth(view.getMonth() + 1); render(); });
        $('#wpcw-cal-today').on('click', function () { view = new Date(); view.setDate(1); render(); });
        $('#wpcw-cal-quick').on('submit', function (e) {
            e.preventDefault();
            var data = {
                title: $('#wpcw-cal-title').val(),
                date:  $('#wpcw-cal-date').val(),
                post_type: $('#wpcw-cal-type').val()
            };
            apiJson('calendar/quick-create', data).done(function () {
                notify('Calendar item created.'); $('#wpcw-cal-quick')[0].reset(); render();
            }).fail(function (xhr) { notify((xhr.responseJSON && xhr.responseJSON.message) || 'Create failed.', 'error'); });
        });

        render();
    }

    // =================================================================
    // WORKFLOW
    // =================================================================
    function initWorkflow() {
        var state = 'review';
        var selected = 0;

        function loadList() {
            api('workflow/queue?state=' + encodeURIComponent(state) + '&per_page=50').done(function (data) {
                var $list = $('#wpcw-wf-list').empty();
                if (!data.items.length) { $list.append('<p class="description">No posts in this state.</p>'); return; }
                data.items.forEach(function (item) {
                    var $row = $('<div class="wpcw-wf-row"></div>')
                        .toggleClass('is-active', item.post_id === selected)
                        .attr('data-id', item.post_id)
                        .append('<div><strong>' + escHtml(item.title) + '</strong><div class="description">'
                            + escHtml(item.modified || '') + '</div></div>')
                        .append('<span class="wpcw-chip wpcw-chip--' + item.state + '">' + escHtml(item.state_label || item.state) + '</span>');
                    $list.append($row);
                });
            });
        }

        function loadDetail(id) {
            if (!id) return;
            api('workflow/post/' + id).done(function (item) {
                renderDetail(item);
            });
        }

        function renderDetail(item) {
            var $d = $('#wpcw-wf-detail').empty().addClass('wpcw-wf-detail');
            $d.append('<h2>' + escHtml(item.title) + '</h2>');
            $d.append('<p><span class="wpcw-chip wpcw-chip--' + item.state + '">' + escHtml(item.state_label) + '</span> '
                + (item.reviewer ? 'Reviewer: ' + escHtml(item.reviewer.name) : 'No reviewer assigned') + '</p>');
            $d.append('<p><a class="button" target="_blank" href="' + item.edit_url + '">Edit post</a> '
                + '<a class="button" target="_blank" href="' + item.view_url + '">Preview</a></p>');

            // Action buttons.
            var $actions = $('<div class="wpcw-wf-actions"></div>');
            (item.transitions || []).forEach(function (target) {
                $actions.append('<button class="button button-primary" data-trans="' + target + '">'
                    + (cfg.workflowStates[target] || target) + '</button>');
            });
            $d.append($actions);

            // Comment form.
            $d.append('<form class="wpcw-wf-comment-form wpcw-form" style="margin-top:12px;">'
                + '<label>Add comment<textarea required></textarea></label>'
                + '<p class="wpcw-form-actions"><button class="button">Post comment</button></p></form>');

            if ((item.comments || []).length) {
                var $c = $('<ul class="wpcw-wf-comments"></ul>');
                item.comments.forEach(function (c) {
                    $c.append('<li><strong>' + escHtml(c.actor_name) + '</strong> · ' + escHtml(c.date) + '<br>' + escHtml(c.body) + '</li>');
                });
                $d.append('<h3>Comments</h3>').append($c);
            }
            if ((item.history || []).length) {
                var $h = $('<ul class="wpcw-wf-history"></ul>');
                item.history.slice().reverse().forEach(function (h) {
                    $h.append('<li>' + escHtml(h.date) + ' · ' + escHtml(h.actor_name) + ' · '
                        + escHtml(h.from) + ' → ' + escHtml(h.to)
                        + (h.note ? ' — ' + escHtml(h.note) : '') + '</li>');
                });
                $d.append('<h3>History</h3>').append($h);
            }

            $d.find('[data-trans]').on('click', function () {
                var target = $(this).data('trans');
                var note = window.prompt('Optional note for this transition:') || '';
                apiJson('workflow/transition', { post_id: item.post_id, state: target, note: note })
                    .done(function (next) { renderDetail(next); loadList(); notify('Updated.'); })
                    .fail(function (xhr) { notify((xhr.responseJSON && xhr.responseJSON.message) || 'Failed.', 'error'); });
            });
            $d.find('.wpcw-wf-comment-form').on('submit', function (e) {
                e.preventDefault();
                var body = $(this).find('textarea').val();
                apiJson('workflow/comment', { post_id: item.post_id, body: body })
                    .done(function (next) { renderDetail(next); notify('Comment added.'); })
                    .fail(function (xhr) { notify((xhr.responseJSON && xhr.responseJSON.message) || 'Failed.', 'error'); });
            });
        }

        $('#wpcw-wf-tabs').on('click', '.wpcw-tab', function () {
            $('.wpcw-tab').removeClass('is-active');
            $(this).addClass('is-active');
            state = $(this).data('state');
            selected = 0;
            loadList();
            $('#wpcw-wf-detail').empty().append('<p class="description">Select a post on the left to review.</p>');
        });
        $('#wpcw-wf-list').on('click', '.wpcw-wf-row', function () {
            $('.wpcw-wf-row').removeClass('is-active');
            $(this).addClass('is-active');
            selected = parseInt($(this).data('id'), 10);
            loadDetail(selected);
        });

        loadList();
    }

    // =================================================================
    // BRAND VOICE
    // =================================================================
    function initBrandVoice() {
        var current = null;

        function load() {
            api('brand-voice').done(function (data) {
                var $list = $('#wpcw-bv-list').empty();
                (data.voices || []).forEach(function (v) {
                    var $li = $('<li></li>')
                        .text(v.name)
                        .toggleClass('is-active', v.id === data.active)
                        .attr('data-id', v.id);
                    var $btn = $('<button class="button-link" style="float:right;">Set active</button>');
                    $btn.on('click', function (e) {
                        e.stopPropagation();
                        apiJson('brand-voice/active', { id: v.id }).done(function () { load(); notify('Active brand voice updated.'); });
                    });
                    $li.append($btn);
                    var $del = $('<button class="button-link" style="float:right; color:#b91c1c; margin-right:6px;">Delete</button>');
                    $del.on('click', function (e) {
                        e.stopPropagation();
                        if (!confirm('Delete brand voice "' + v.name + '"?')) return;
                        api('brand-voice/' + encodeURIComponent(v.id), { method: 'DELETE' }).done(function () { load(); notify('Deleted.'); });
                    });
                    $li.append($del);
                    $li.on('click', function () { fill(v); });
                    $list.append($li);
                });
            });
        }

        function fill(v) {
            current = v;
            $('#wpcw-bv-id').val(v.id || '');
            $('#wpcw-bv-name').val(v.name || '');
            $('#wpcw-bv-desc').val(v.description || '');
            $('#wpcw-bv-tags').val((v.tone_tags || []).join(', '));
            $('#wpcw-bv-level').val(v.reading_level || 'general');
            $('#wpcw-bv-do').val((v.do_list || []).join('\n'));
            $('#wpcw-bv-dont').val((v.dont_list || []).join('\n'));
            $('#wpcw-bv-sample').val(v.sample || '');
            $('#wpcw-bv-guide').val(v.guide || '');
        }

        $('#wpcw-bv-new').on('click', function () { fill({}); });
        $('#wpcw-bv-form').on('submit', function (e) {
            e.preventDefault();
            var body = {
                id:            $('#wpcw-bv-id').val(),
                name:          $('#wpcw-bv-name').val(),
                description:   $('#wpcw-bv-desc').val(),
                tone_tags:     $('#wpcw-bv-tags').val(),
                reading_level: $('#wpcw-bv-level').val(),
                do_list:       $('#wpcw-bv-do').val(),
                dont_list:     $('#wpcw-bv-dont').val(),
                sample:        $('#wpcw-bv-sample').val(),
                guide:         $('#wpcw-bv-guide').val()
            };
            apiJson('brand-voice', body).done(function (saved) {
                fill(saved); load(); notify('Profile saved.');
            }).fail(function (xhr) { notify((xhr.responseJSON && xhr.responseJSON.message) || 'Save failed.', 'error'); });
        });
        $('#wpcw-bv-analyze').on('click', function () {
            var sample = $('#wpcw-bv-sample').val();
            if (!sample) { notify('Add a writing sample first.', 'warning'); return; }
            var $btn = $(this).prop('disabled', true).text('Analyzing…');
            apiJson('brand-voice/analyze', { sample: sample }).done(function (res) {
                $('#wpcw-bv-guide').val(res.guide || '');
                notify('Style guide generated.');
            }).fail(function (xhr) { notify((xhr.responseJSON && xhr.responseJSON.message) || 'Analyze failed.', 'error'); })
              .always(function () { $btn.prop('disabled', false).text('Analyze sample with AI'); });
        });

        load();
    }

    // =================================================================
    // BULK
    // =================================================================
    function initBulk() {
        function load() {
            api('bulk/jobs').done(function (data) {
                var $tbody = $('#wpcw-bulk-jobs tbody').empty();
                (data.jobs || []).forEach(function (j) {
                    var pct = j.total_items ? Math.round(((+j.done_items + +j.failed_items) / j.total_items) * 100) : 0;
                    var $tr = $('<tr></tr>')
                        .append('<td>#' + j.id + '</td>')
                        .append('<td>' + escHtml(j.name) + '</td>')
                        .append('<td><span class="wpcw-bulk-row-status wpcw-bulk-row-status--' + j.status + '">' + escHtml(j.status) + '</span></td>')
                        .append('<td><progress value="' + pct + '" max="100"></progress> '
                            + j.done_items + '/' + j.total_items + (j.failed_items ? ' (' + j.failed_items + ' failed)' : '')
                            + '</td>')
                        .append('<td>' + escHtml(j.created_at) + '</td>')
                        .append('<td><button class="button button-link" data-view="' + j.id + '">View</button>'
                            + (j.status === 'queued' || j.status === 'processing'
                                ? ' <button class="button button-link" data-cancel="' + j.id + '">Cancel</button>'
                                : ' <button class="button button-link" data-delete="' + j.id + '">Delete</button>') + '</td>');
                    $tbody.append($tr);
                });
            });
        }

        function viewJob(id) {
            api('bulk/jobs/' + id).done(function (data) {
                var $body = $('#wpcw-bulk-detail-body').empty();
                $body.append('<p><strong>' + escHtml(data.job.name) + '</strong> — ' + escHtml(data.job.status) + '</p>');
                var $tbl = $('<table class="widefat striped"><thead><tr><th>#</th><th>Status</th><th>Title</th><th>Post</th><th>Error</th></tr></thead><tbody></tbody></table>');
                (data.items || []).forEach(function (it) {
                    var input = it.input || {};
                    $tbl.find('tbody').append('<tr><td>' + (it.row_index + 1) + '</td><td>'
                        + escHtml(it.status) + '</td><td>' + escHtml(input.title || input.prompt || '') + '</td><td>'
                        + (it.post_id ? '<a href="' + (it.output && it.output.edit_url || '#') + '">#' + it.post_id + '</a>' : '—')
                        + '</td><td>' + escHtml(it.error || '') + '</td></tr>');
                });
                $body.append($tbl);
                $('#wpcw-bulk-detail').show();
            });
        }

        $('#wpcw-bulk-form').on('submit', function (e) {
            e.preventDefault();
            var file = $('#wpcw-bulk-file')[0].files[0];
            if (!file) return;
            var name = $('#wpcw-bulk-name').val();
            var reader = new FileReader();
            reader.onload = function () {
                apiJson('bulk/jobs', { name: name, csv: reader.result }).done(function () {
                    notify('Job queued.'); $('#wpcw-bulk-form')[0].reset(); load();
                }).fail(function (xhr) { notify((xhr.responseJSON && xhr.responseJSON.message) || 'Upload failed.', 'error'); });
            };
            reader.readAsText(file);
        });
        $('#wpcw-bulk-refresh').on('click', load);
        $('#wpcw-bulk-run-now').on('click', function () { apiJson('bulk/run-now', {}).done(function () { notify('Worker kicked.'); setTimeout(load, 1500); }); });
        $('#wpcw-bulk-template').on('click', function (e) {
            e.preventDefault();
            window.location.href = cfg.restUrl + 'bulk/template-csv?_wpnonce=' + encodeURIComponent(cfg.nonce);
        });
        $('#wpcw-bulk-jobs').on('click', '[data-view]',   function () { viewJob($(this).data('view')); });
        $('#wpcw-bulk-jobs').on('click', '[data-cancel]', function () {
            apiJson('bulk/jobs/' + $(this).data('cancel') + '/cancel', {}).done(function () { load(); });
        });
        $('#wpcw-bulk-jobs').on('click', '[data-delete]', function () {
            if (!confirm('Delete this job and its history?')) return;
            api('bulk/jobs/' + $(this).data('delete'), { method: 'DELETE' }).done(function () { load(); });
        });

        load();
        setInterval(load, 15000);
    }

    // =================================================================
    // ACTIVITY LOG
    // =================================================================
    function initActivity() {
        var page_ = 1;

        function buildQuery() {
            var p = $.param({
                q:           $('#wpcw-act-q').val(),
                action:      $('#wpcw-act-action').val(),
                severity:    $('#wpcw-act-severity').val(),
                date_from:   $('#wpcw-act-from').val(),
                date_to:     $('#wpcw-act-to').val(),
                page:        page_,
                per_page:    50
            });
            return p;
        }

        function load() {
            api('activity?' + buildQuery()).done(function (data) {
                if (!$('#wpcw-act-action option').length || $('#wpcw-act-action option').length <= 1) {
                    var $sel = $('#wpcw-act-action');
                    (data.actions || []).forEach(function (a) {
                        $sel.append('<option value="' + escHtml(a) + '">' + escHtml(a) + '</option>');
                    });
                }
                var $tbody = $('#wpcw-act-table tbody').empty();
                (data.items || []).forEach(function (it) {
                    $tbody.append('<tr><td>' + escHtml(it.created_at) + '</td>'
                        + '<td>' + escHtml(it.user_name) + '</td>'
                        + '<td><code>' + escHtml(it.action) + '</code></td>'
                        + '<td>' + escHtml(it.object_type) + ' ' + (it.object_id ? '#' + it.object_id : '') + '</td>'
                        + '<td><span class="wpcw-act-sev wpcw-act-sev--' + it.severity + '">' + escHtml(it.severity) + '</span></td>'
                        + '<td>' + escHtml(it.message) + '</td>'
                        + '<td>' + escHtml(it.ip || '') + '</td></tr>');
                });
                renderPagination(data);
            });
        }

        function renderPagination(data) {
            var $p = $('#wpcw-act-pagination').empty();
            for (var i = 1; i <= Math.max(1, data.pages); i++) {
                var $b = $('<button>' + i + '</button>').toggleClass('is-current', i === data.page);
                $b.on('click', (function (n) { return function () { page_ = n; load(); }; })(i));
                $p.append($b);
                if (i >= 12) { $p.append('<span>…</span>'); break; }
            }
            $p.append(' <span class="description">' + data.total + ' total</span>');
        }

        $('#wpcw-act-filters').on('submit', function (e) { e.preventDefault(); page_ = 1; load(); });
        $('#wpcw-act-export').on('click', function (e) {
            e.preventDefault();
            window.location.href = cfg.restUrl + 'activity/export?' + buildQuery() + '&_wpnonce=' + encodeURIComponent(cfg.nonce);
        });

        load();
    }

    // =================================================================
    // TEAM
    // =================================================================
    function initTeam() {
        function load() {
            api('team').done(function (data) {
                var $tbody = $('#wpcw-team-table tbody').empty();
                var roles = data.roles || cfg.roles || {};
                (data.team || []).forEach(function (m) {
                    var $sel = $('<select></select>');
                    Object.keys(roles).forEach(function (slug) {
                        $sel.append('<option value="' + slug + '"' + (m.role === slug ? ' selected' : '') + '>' + escHtml(roles[slug]) + '</option>');
                    });
                    $sel.append('<option value="administrator"' + (m.role === 'administrator' ? ' selected' : '') + '>Administrator</option>');
                    $sel.on('change', (function (uid) { return function () {
                        apiJson('team/role', { user_id: uid, role: $(this).val() }).done(function () { notify('Role updated.'); }).fail(function (xhr) {
                            notify((xhr.responseJSON && xhr.responseJSON.message) || 'Failed.', 'error');
                        });
                    }; })(m.id));
                    var $tr = $('<tr></tr>')
                        .append('<td>' + escHtml(m.name) + '</td>')
                        .append('<td>' + escHtml(m.email) + '</td>')
                        .append($('<td></td>').append($sel))
                        .append('<td><a href="user-edit.php?user_id=' + m.id + '">Edit user</a></td>');
                    $tbody.append($tr);
                });

                renderMatrix(data);
            });
        }
        function renderMatrix(data) {
            var caps   = data.capabilities || cfg.caps || {};
            var matrix = data.matrix || {};
            var roles  = data.roles || cfg.roles || {};
            var $wrap = $('#wpcw-team-matrix').empty();
            var $tbl = $('<table></table>');
            var $thead = $('<thead><tr><th>Capability</th></tr></thead>');
            Object.keys(roles).forEach(function (slug) { $thead.find('tr').append('<th>' + escHtml(roles[slug]) + '</th>'); });
            $tbl.append($thead);
            var $tbody = $('<tbody></tbody>');
            Object.keys(caps).forEach(function (cap) {
                var $tr = $('<tr></tr>').append('<td>' + escHtml(caps[cap]) + '<br><code style="font-size:10px;">' + cap + '</code></td>');
                Object.keys(roles).forEach(function (slug) {
                    var has = matrix[slug] && matrix[slug][cap];
                    $tr.append('<td class="' + (has ? 'yes' : 'no') + '">' + (has ? '✓' : '·') + '</td>');
                });
                $tbody.append($tr);
            });
            $tbl.append($tbody);
            $wrap.append($tbl);
        }

        load();
    }
})(jQuery);
