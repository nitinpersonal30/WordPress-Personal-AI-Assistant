/**
 * WP Content Writer AI Pro — Floating Chat Widget
 * Appears on ALL WordPress admin pages
 * Full chat with AI: content generation, SEO, site changes, plugin recommendations
 */
(function ($) {
    'use strict';

    var C       = window.wpcwChat || {};
    var restUrl = C.restUrl  || '';
    var nonce   = C.nonce    || '';
    var model   = C.model    || 'llama-3.1-8b-instant';

    if (!restUrl || !nonce) return;

    var isOpen       = false;
    var isProcessing = false;
    var chatHistory  = [];
    var HISTORY_KEY  = 'wpcw_chat_history';

    // Load chat history from localStorage
    try {
        var saved = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
        if (Array.isArray(saved)) chatHistory = saved;
    } catch(e) {}

    // =========================================================================
    // BUILD THE DOM
    // =========================================================================
    var widgetHtml = '' +
        '<button id="wpcw-chat-bubble" title="AI Assistant">' +
            '<span id="wpcw-chat-badge"></span>' +
            '<svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.17L4 17.17V4h16v12z"/><path d="M7 9h2v2H7zm4 0h2v2h-2zm4 0h2v2h-2z"/></svg>' +
        '</button>' +
        '<div id="wpcw-chat-window">' +
            '<div class="wpcw-chat-header">' +
                '<div class="wpcw-chat-header-icon"><svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.17L4 17.17V4h16v12z"/><path d="M7 9h2v2H7zm4 0h2v2h-2zm4 0h2v2h-2z"/></svg></div>' +
                '<div class="wpcw-chat-header-text">' +
                    '<p class="wpcw-chat-header-title">AI Assistant</p>' +
                    '<p class="wpcw-chat-header-sub">Powered by ' + escHtml(model) + ' &bull; Kuch bhi pucho!</p>' +
                '</div>' +
                '<button class="wpcw-chat-close" id="wpcw-chat-close-btn">&times;</button>' +
            '</div>' +
            '<div class="wpcw-chat-actions">' +
                '<button class="wpcw-chat-action-btn" data-prompt="Ek blog post likho about "><span class="dashicons dashicons-edit"></span> Blog Post</button>' +
                '<button class="wpcw-chat-action-btn" data-prompt="Meri website analyze karo" data-action="site_analyze"><span class="dashicons dashicons-visibility"></span> Site Analyze</button>' +
                '<button class="wpcw-chat-action-btn" data-prompt="Sabhi posts ka SEO fix karo" data-action="bulk_seo"><span class="dashicons dashicons-chart-line"></span> Fix SEO</button>' +
                '<button class="wpcw-chat-action-btn" data-prompt="Website ka design improve karo with CSS"><span class="dashicons dashicons-art"></span> Design</button>' +
                '<button class="wpcw-chat-action-btn" data-prompt="Best WordPress plugins suggest karo for "><span class="dashicons dashicons-admin-plugins"></span> Plugins</button>' +
                '<button class="wpcw-chat-action-btn" data-prompt="Is text ko find & replace karo: "><span class="dashicons dashicons-search"></span> Find Replace</button>' +
            '</div>' +
            '<div class="wpcw-chat-messages" id="wpcw-chat-messages"></div>' +
            '<div class="wpcw-chat-input-area">' +
                '<textarea id="wpcw-chat-input" rows="1" placeholder="Kuch bhi pucho ya kaam bolo..."></textarea>' +
                '<button id="wpcw-chat-send" title="Send"><svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg></button>' +
            '</div>' +
        '</div>';

    $('body').append(widgetHtml);

    var $bubble   = $('#wpcw-chat-bubble');
    var $window   = $('#wpcw-chat-window');
    var $messages = $('#wpcw-chat-messages');
    var $input    = $('#wpcw-chat-input');
    var $sendBtn  = $('#wpcw-chat-send');
    var $badge    = $('#wpcw-chat-badge');

    // =========================================================================
    // OPEN / CLOSE
    // =========================================================================
    $bubble.on('click', function () {
        isOpen = !isOpen;
        $bubble.toggleClass('open', isOpen);
        $window.toggleClass('visible', isOpen);
        if (isOpen) {
            renderHistory();
            $input.focus();
            $badge.removeClass('active');
        }
    });

    $('#wpcw-chat-close-btn').on('click', function () {
        isOpen = false;
        $bubble.removeClass('open');
        $window.removeClass('visible');
    });

    // =========================================================================
    // QUICK ACTIONS — use data-action for forced intent
    // =========================================================================
    $(document).on('click', '.wpcw-chat-action-btn', function () {
        var prompt = $(this).data('prompt') || '';
        var forcedAction = $(this).data('action') || '';
        $input.val(prompt).focus();
        // If prompt doesn't end with space, auto-send
        if (prompt && prompt.charAt(prompt.length - 1) !== ' ') {
            sendMessage(prompt, forcedAction);
        }
    });

    // =========================================================================
    // SEND MESSAGE
    // =========================================================================
    $sendBtn.on('click', function () {
        var text = $.trim($input.val());
        if (text && !isProcessing) sendMessage(text, '');
    });

    $input.on('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            var text = $.trim($input.val());
            if (text && !isProcessing) sendMessage(text, '');
        }
    });

    // Auto-resize textarea
    $input.on('input', function () {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 100) + 'px';
    });

    function sendMessage(text, forcedAction) {
        $input.val('').css('height', 'auto');
        addMessage('user', text);
        isProcessing = true;
        $sendBtn.prop('disabled', true);

        // Check for pending confirmations first
        if (checkPendingConfirmation(text)) return;

        // If forced action from quick button, use it directly
        if (forcedAction) {
            executeAction(forcedAction, text);
            return;
        }

        // Use AI to classify intent, then execute
        classifyAndExecute(text);
    }

    // =========================================================================
    // AI-POWERED INTENT CLASSIFICATION
    // =========================================================================
    function classifyAndExecute(text) {
        addTyping();

        var classifyPrompt = 'You are an intent classifier. Classify the user message into EXACTLY ONE category. Reply with ONLY the category name, nothing else.\n\nCategories:\n- site_analyze: User wants to analyze, scan, check, view, or get info about their website/site\n- bulk_seo: User wants to fix, update, or improve SEO across posts\n- find_replace: User wants to find and replace text across the website\n- css_change: User wants to change design, CSS, colors, fonts, layout, styling\n- plugin_recommend: User wants plugin suggestions or recommendations\n- image_alt: User wants to fix or update image alt text\n- generate_content: User wants to write/generate a blog post, article, content, email, ad copy, etc.\n- general_chat: General question or conversation (default)\n\nUser message: ' + text + '\n\nCategory:';

        $.ajax({
            url: restUrl + 'generate',
            method: 'POST',
            beforeSend: setNonce,
            contentType: 'application/json',
            data: JSON.stringify({ prompt: classifyPrompt }),
            timeout: 30000,
            success: function (resp) {
                removeTyping();
                var category = (resp.content || '').trim().toLowerCase().replace(/[^a-z_]/g, '');

                // Map AI response to valid action
                var validActions = ['site_analyze', 'bulk_seo', 'find_replace', 'css_change', 'plugin_recommend', 'image_alt', 'generate_content', 'general_chat'];

                // Fuzzy match if AI returned partial
                var matched = 'general_chat';
                for (var i = 0; i < validActions.length; i++) {
                    if (category.indexOf(validActions[i]) !== -1 || validActions[i].indexOf(category) !== -1) {
                        matched = validActions[i];
                        break;
                    }
                }

                executeAction(matched, text);
            },
            error: function () {
                // Fallback: use simple keyword matching if AI classification fails
                removeTyping();
                var fallbackAction = fallbackDetect(text);
                executeAction(fallbackAction, text);
            },
        });
    }

    // Fallback keyword matching (only used if AI classification fails)
    function fallbackDetect(text) {
        var t = text.toLowerCase();

        if (/(website|site).*(analyze|analysis|scan|check|dekh|health|info|details|overview)/.test(t)) return 'site_analyze';
        if (/meri\s*(website|site)\s*(analyze|scan|check|dekh|batao|dikhao)/.test(t)) return 'site_analyze';
        if (/analyze\s*(karo|kar\s*do|karke|kijiye)/.test(t) && /(website|site|meri)/.test(t)) return 'site_analyze';

        if (/(seo).*(fix|update|improve|karo|kar)/.test(t)) return 'bulk_seo';
        if (/(fix|improve|update|sabhi|sab|bulk).*(seo)/.test(t)) return 'bulk_seo';

        if (/find.*replace|replace.*with|badal.*se|replace.*karo/.test(t)) return 'find_replace';

        if (/(css|style|design|color|font|background|layout|theme).*(change|karo|update|improve|bada|chhota|add)/.test(t)) return 'css_change';

        if (/(plugin).*(suggest|recommend|best|top|batao|chahiye|list)/.test(t)) return 'plugin_recommend';

        if (/(image|photo|img).*(alt|text)/.test(t) || /alt\s*text/.test(t)) return 'image_alt';

        if (/(blog|post|article|content|likho|likhiye|write|generate|email|ad\s*copy)/.test(t)) return 'generate_content';

        return 'general_chat';
    }

    // =========================================================================
    // EXECUTE ACTION
    // =========================================================================
    function executeAction(action, text) {
        switch (action) {
            case 'site_analyze':
                doSiteAnalyze(text);
                break;
            case 'bulk_seo':
                doBulkSeo();
                break;
            case 'find_replace':
                doFindReplace(text);
                break;
            case 'css_change':
                doCssChange(text);
                break;
            case 'plugin_recommend':
                doPluginRecommend(text);
                break;
            case 'image_alt':
                doImageAlt();
                break;
            case 'generate_content':
                doGenerateContent(text);
                break;
            default:
                doGeneralChat(text);
                break;
        }
    }

    // =========================================================================
    // ACTION HANDLERS
    // =========================================================================
    function doSiteAnalyze(text) {
        addTyping();
        $.ajax({
            url: restUrl + 'site/ai-analyze',
            method: 'POST',
            beforeSend: setNonce,
            contentType: 'application/json',
            data: JSON.stringify({ question: text }),
            timeout: 200000,
            success: function (resp) {
                removeTyping();
                addMessage('ai', resp.analysis || 'Website analysis complete. Koi specific data nahi mila.');
                done();
            },
            error: function (xhr) {
                var errMsg = 'Site analysis failed.';
                if (xhr.status === 0) errMsg += ' Groq API tak nahi pahuch paa rahe.';
                aiError(errMsg);
            },
        });
    }

    function doBulkSeo() {
        addTyping();
        $.ajax({
            url: restUrl + 'changes/bulk-seo',
            method: 'POST',
            beforeSend: setNonce,
            contentType: 'application/json',
            data: JSON.stringify({ options: { only_empty: true, dry_run: true } }),
            success: function (resp) {
                removeTyping();
                if (resp.total_updated === 0) {
                    addMessage('ai', 'Sabhi posts me pehle se SEO meta hai. Kuch update karne ki zaroorat nahi!');
                } else {
                    var msg = '**Dry Run Result:** ' + resp.total_updated + ' posts me SEO meta missing hai (total scanned: ' + resp.total_scanned + ').\n\n';
                    if (resp.updated) {
                        msg += 'Sample posts:\n';
                        resp.updated.slice(0, 5).forEach(function (u) {
                            msg += '- **' + u.title + '** → keyword: "' + u.keyword + '"\n';
                        });
                    }
                    msg += '\n**"Apply karo"** bolo to main ye changes actually apply kar dunga.';
                    addMessage('ai', msg);
                    localStorage.setItem('wpcw_pending_seo', 'true');
                }
                done();
            },
            error: function () { aiError('SEO update failed!'); },
        });
    }

    function doFindReplace(text) {
        addTyping();
        // Try to extract search and replace values
        var frMatch = text.match(/["\u201c](.+?)["\u201d].*?(?:ko|to|se|with|and|aur)\s*["\u201c](.+?)["\u201d]/) ||
                      text.match(/(?:replace|badal|change)\s+['\u2018\u2019""\u201c\u201d](.+?)['\u2018\u2019""\u201c\u201d].*?(?:with|se|to|ko)\s+['\u2018\u2019""\u201c\u201d](.+?)['\u2018\u2019""\u201c\u201d]/) ||
                      text.match(/['\u2018](.+?)['\u2019].*?['\u2018](.+?)['\u2019]/);

        if (frMatch) {
            var search = frMatch[1].trim(), replace = frMatch[2].trim();
            addMessage('ai', '**Find & Replace:** "' + search + '" → "' + replace + '"\nDry run check kar raha hoon...');
            $.ajax({
                url: restUrl + 'changes/find-replace',
                method: 'POST',
                beforeSend: setNonce,
                contentType: 'application/json',
                data: JSON.stringify({ search: search, replace: replace, options: { dry_run: true, fields: ['title', 'content', 'excerpt'] } }),
                success: function (resp) {
                    removeTyping();
                    if (resp.total_replacements === 0) {
                        addMessage('ai', '"' + search + '" kahi nahi mila. Koi match nahi hai.');
                    } else {
                        var msg = '**Dry Run:** ' + resp.total_replacements + ' replacements milenge ' + resp.posts_changed + ' posts me.\n\n';
                        if (resp.changed) {
                            resp.changed.slice(0, 5).forEach(function (c) {
                                msg += '- ' + c.title + ' (' + c.replacements + ' changes)\n';
                            });
                        }
                        msg += '\n**"Apply karo"** bolo to actually replace ho jayega.';
                        addMessage('ai', msg);
                        localStorage.setItem('wpcw_pending_fr', JSON.stringify({ search: search, replace: replace }));
                    }
                    done();
                },
                error: function () { aiError('Find & Replace failed!'); },
            });
        } else {
            removeTyping();
            addMessage('ai', 'Please is format me bolo:\n\n**"old text" ko "new text" se replace karo**\n\nYa:\n**Find "old text" and replace with "new text"**\n\nQuotes me search aur replace text dalna zaroori hai.');
            done();
        }
    }

    function doCssChange(text) {
        addTyping();
        var cssPrompt = 'You are a CSS expert for WordPress websites. The user wants to make a visual/design change to their WordPress website.\n\nIMPORTANT RULES:\n1. Generate ONLY valid CSS code\n2. Wrap your CSS in a ```css code block\n3. Before the CSS, briefly explain (1-2 lines) what the CSS will do\n4. After the CSS, tell the user to say "Apply karo" to apply it to their website\n5. Reply in the same language the user uses (Hindi/Hinglish/English)\n\nUser request: ' + text;

        callAiChat(cssPrompt, function (response) {
            addMessage('ai', response);
            // Extract CSS from response
            var cssMatch = response.match(/```css\s*([\s\S]*?)```/);
            if (cssMatch) {
                localStorage.setItem('wpcw_pending_css', cssMatch[1].trim());
            }
            done();
        });
    }

    function doPluginRecommend(text) {
        addTyping();
        var keyword = text.replace(/(plugin|plugins|suggest|recommend|best|top|batao|chahiye|for|ke\s*liye|karo|wordpress)/gi, '').trim() || 'general';
        $.ajax({
            url: restUrl + 'plugins/recommend',
            method: 'POST',
            beforeSend: setNonce,
            contentType: 'application/json',
            data: JSON.stringify({ need: keyword, limit: 8 }),
            success: function (resp) {
                removeTyping();
                var plugins = resp.recommendations || resp || [];
                if (plugins.length === 0) {
                    addMessage('ai', 'Is category me koi plugin nahi mila database me. Koi aur keyword try karo.');
                } else {
                    var msg = '**Top Plugins for "' + escHtml(keyword) + '":**\n\n';
                    plugins.forEach(function (p, i) {
                        msg += (i + 1) + '. **' + p.name + '** (' + p.type + ') — ' + p.description + '\n';
                    });
                    addMessage('ai', msg);
                }
                done();
            },
            error: function () { aiError('Plugin search failed!'); },
        });
    }

    function doImageAlt() {
        addTyping();
        $.ajax({
            url: restUrl + 'changes/image-alt',
            method: 'POST',
            beforeSend: setNonce,
            contentType: 'application/json',
            data: JSON.stringify({ options: { dry_run: true } }),
            success: function (resp) {
                removeTyping();
                var msg = '**Image Alt Text Check:** ' + resp.total_images + ' total images, ' + resp.without_alt + ' missing alt text.\n\n';
                if (resp.updated && resp.updated.length > 0) {
                    resp.updated.slice(0, 5).forEach(function (u) {
                        msg += '- ' + u.title + ' → "' + u.alt + '"\n';
                    });
                    msg += '\n**"Apply karo"** bolo to fix ho jayega.';
                    localStorage.setItem('wpcw_pending_alt', 'true');
                } else {
                    msg += 'Sabhi images me alt text pehle se hai!';
                }
                addMessage('ai', msg);
                done();
            },
            error: function () { aiError('Image alt check failed!'); },
        });
    }

    function doGenerateContent(text) {
        addTyping();
        var contentPrompt = 'You are an expert content writer. Write high-quality, detailed, well-structured content based on the user\'s request. Use markdown formatting (headings, bold, lists). Reply in the same language the user uses.\n\nUser request: ' + text;

        callAiChat(contentPrompt, function (response) {
            addMessage('ai', response);
            // Save to gen state so main writer page can pick it up
            try {
                localStorage.setItem('wpcw_gen_state', JSON.stringify({
                    status: 'completed',
                    text: response,
                    template: 'chat',
                    time: Date.now(),
                }));
            } catch(e) {}
            done();
        });
    }

    function doGeneralChat(text) {
        addTyping();
        var chatPrompt = 'You are an expert AI assistant for WordPress websites. You help with content writing, SEO (Rank Math, Yoast), web development (PHP, HTML, CSS, JavaScript, Python), WordPress plugins, Elementor, graphic design, and digital marketing.\n\nIMPORTANT RULES:\n1. Answer in the same language the user uses (Hindi, Hinglish, or English)\n2. Be specific and actionable\n3. Use markdown formatting for better readability\n4. If the user asks about website changes, explain clearly what you can do\n5. Do NOT generate CSS or code unless explicitly asked for it\n\n';

        // Add recent chat context
        var recent = chatHistory.slice(-6);
        recent.forEach(function (m) {
            chatPrompt += (m.role === 'user' ? 'User: ' : 'Assistant: ') + m.text + '\n';
        });
        chatPrompt += 'User: ' + text + '\n\nAssistant:';

        callAiChat(chatPrompt, function (response) {
            addMessage('ai', response);
            done();
        });
    }

    // =========================================================================
    // PENDING CONFIRMATION HANDLER
    // =========================================================================
    function checkPendingConfirmation(text) {
        var lowerText = text.toLowerCase();
        var isConfirm = /(^|\s)(haan|yes|ok|apply|sure|confirm|go\s*ahead|kar\s*do|laga\s*do|apply\s*karo|haa|ha\b)/.test(lowerText);
        if (!isConfirm) return false;

        var pendingFr  = localStorage.getItem('wpcw_pending_fr');
        var pendingSeo = localStorage.getItem('wpcw_pending_seo');
        var pendingCss = localStorage.getItem('wpcw_pending_css');
        var pendingAlt = localStorage.getItem('wpcw_pending_alt');

        if (pendingFr) {
            var fr = JSON.parse(pendingFr);
            addTyping();
            $.ajax({
                url: restUrl + 'changes/find-replace',
                method: 'POST',
                beforeSend: setNonce,
                contentType: 'application/json',
                data: JSON.stringify({ search: fr.search, replace: fr.replace, options: { dry_run: false, fields: ['title', 'content', 'excerpt'] } }),
                success: function (resp) {
                    removeTyping();
                    addMessage('ai', '**Done!** ' + resp.total_replacements + ' replacements applied in ' + resp.posts_changed + ' posts.');
                    localStorage.removeItem('wpcw_pending_fr');
                    done();
                },
                error: function () { aiError('Apply failed!'); },
            });
            return true;
        }

        if (pendingSeo) {
            addTyping();
            $.ajax({
                url: restUrl + 'changes/bulk-seo',
                method: 'POST',
                beforeSend: setNonce,
                contentType: 'application/json',
                data: JSON.stringify({ options: { only_empty: true, dry_run: false } }),
                success: function (resp) {
                    removeTyping();
                    addMessage('ai', '**Done!** ' + resp.total_updated + ' posts ka SEO meta update ho gaya.');
                    localStorage.removeItem('wpcw_pending_seo');
                    done();
                },
                error: function () { aiError('SEO apply failed!'); },
            });
            return true;
        }

        if (pendingCss) {
            addTyping();
            $.ajax({
                url: restUrl + 'changes/css',
                method: 'POST',
                beforeSend: setNonce,
                contentType: 'application/json',
                data: JSON.stringify({ css: pendingCss, mode: 'append' }),
                success: function (resp) {
                    removeTyping();
                    addMessage('ai', '**CSS apply ho gaya!** Website pe changes live hain. Page refresh karke dekho.');
                    localStorage.removeItem('wpcw_pending_css');
                    done();
                },
                error: function () { aiError('CSS apply failed!'); },
            });
            return true;
        }

        if (pendingAlt) {
            addTyping();
            $.ajax({
                url: restUrl + 'changes/image-alt',
                method: 'POST',
                beforeSend: setNonce,
                contentType: 'application/json',
                data: JSON.stringify({ options: { dry_run: false } }),
                success: function (resp) {
                    removeTyping();
                    addMessage('ai', '**Done!** ' + (resp.without_alt || 0) + ' images ka alt text fix ho gaya.');
                    localStorage.removeItem('wpcw_pending_alt');
                    done();
                },
                error: function () { aiError('Alt text apply failed!'); },
            });
            return true;
        }

        return false;
    }

    // =========================================================================
    // AI CALL HELPER
    // =========================================================================
    function callAiChat(prompt, callback) {
        $.ajax({
            url: restUrl + 'generate',
            method: 'POST',
            beforeSend: setNonce,
            contentType: 'application/json',
            data: JSON.stringify({ prompt: prompt }),
            timeout: 200000,
            success: function (resp) {
                removeTyping();
                callback(resp.content || 'Koi response nahi aaya. Groq API key check karo.');
            },
            error: function () {
                // Try streaming fallback
                fetch(restUrl + 'stream', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
                    body: JSON.stringify({ prompt: prompt }),
                }).then(function (response) {
                    if (!response.ok) throw new Error('Stream error');
                    var reader = response.body.getReader();
                    var decoder = new TextDecoder();
                    var buffer = '';
                    var fullText = '';

                    function pump() {
                        return reader.read().then(function (result) {
                            if (result.done) {
                                removeTyping();
                                callback(fullText || 'Koi response nahi aaya.');
                                return;
                            }
                            buffer += decoder.decode(result.value, { stream: true });
                            var lines = buffer.split('\n');
                            buffer = lines.pop();
                            lines.forEach(function (line) {
                                line = line.trim();
                                if (!line.startsWith('data: ')) return;
                                try {
                                    var obj = JSON.parse(line.slice(6));
                                    if (obj.token) fullText += obj.token;
                                } catch(e) {}
                            });
                            return pump();
                        });
                    }
                    return pump();
                }).catch(function () {
                    removeTyping();
                    callback('AI se connect nahi ho paa raha. Groq API key valid hai? Settings page me check karo.');
                });
            },
        });
    }

    // =========================================================================
    // MESSAGE RENDERING
    // =========================================================================
    function addMessage(role, text) {
        chatHistory.push({ role: role, text: text, time: Date.now() });
        saveChatHistory();
        renderSingleMessage(role, text, true);
    }

    function renderSingleMessage(role, text, scroll) {
        var avatar = role === 'user' ? '<span>You</span>' : '<span>AI</span>';
        var bubbleContent = '';

        if (role === 'ai' && typeof marked !== 'undefined' && marked.parse) {
            bubbleContent = marked.parse(text);
        } else {
            bubbleContent = escHtml(text);
        }

        var $msg = $('<div class="wpcw-msg ' + role + '">' +
            '<div class="wpcw-msg-avatar">' + avatar + '</div>' +
            '<div>' +
                '<div class="wpcw-msg-bubble">' + bubbleContent + '</div>' +
                (role === 'ai' ? '<div class="wpcw-msg-actions"><button class="wpcw-msg-action-btn wpcw-copy-msg" title="Copy">Copy</button></div>' : '') +
            '</div>' +
        '</div>');

        $messages.append($msg);
        if (scroll) scrollToBottom();
    }

    function renderHistory() {
        $messages.empty();

        if (chatHistory.length === 0) {
            $messages.html(
                '<div class="wpcw-chat-welcome">' +
                    '<div class="wpcw-chat-welcome-icon"><svg width="48" height="48" viewBox="0 0 24 24" fill="#6366f1"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.17L4 17.17V4h16v12z"/><path d="M7 9h2v2H7zm4 0h2v2h-2zm4 0h2v2h-2z"/></svg></div>' +
                    '<h4>AI Assistant Ready!</h4>' +
                    '<p>Kuch bhi pucho ya kaam bolo — Hindi, English ya Hinglish me.<br/>Blog likho, SEO fix karo, website analyze karo, design change karo!</p>' +
                '</div>'
            );
            return;
        }

        chatHistory.forEach(function (m) {
            renderSingleMessage(m.role, m.text, false);
        });
        scrollToBottom();
    }

    function addTyping() {
        var $typing = $('<div class="wpcw-msg ai wpcw-typing-msg">' +
            '<div class="wpcw-msg-avatar"><span>AI</span></div>' +
            '<div class="wpcw-msg-bubble"><div class="wpcw-typing"><div class="wpcw-typing-dot"></div><div class="wpcw-typing-dot"></div><div class="wpcw-typing-dot"></div></div></div>' +
        '</div>');
        $messages.append($typing);
        scrollToBottom();
    }

    function removeTyping() {
        $messages.find('.wpcw-typing-msg').remove();
    }

    // =========================================================================
    // COPY MESSAGE
    // =========================================================================
    $(document).on('click', '.wpcw-copy-msg', function () {
        var text = $(this).closest('.wpcw-msg').find('.wpcw-msg-bubble').text();
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text);
        } else {
            var ta = document.createElement('textarea');
            ta.value = text;
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
        }
        var $btn = $(this);
        $btn.text('Copied!');
        setTimeout(function () { $btn.text('Copy'); }, 1500);
    });

    // =========================================================================
    // CLEAR CHAT
    // =========================================================================
    $('.wpcw-chat-header').on('dblclick', function () {
        if (confirm('Chat history clear karna hai?')) {
            chatHistory = [];
            saveChatHistory();
            localStorage.removeItem('wpcw_pending_fr');
            localStorage.removeItem('wpcw_pending_seo');
            localStorage.removeItem('wpcw_pending_css');
            localStorage.removeItem('wpcw_pending_alt');
            renderHistory();
        }
    });

    // =========================================================================
    // HELPERS
    // =========================================================================
    function setNonce(xhr) { xhr.setRequestHeader('X-WP-Nonce', nonce); }

    function scrollToBottom() {
        var el = $messages[0];
        if (el) el.scrollTop = el.scrollHeight;
    }

    function done() {
        isProcessing = false;
        $sendBtn.prop('disabled', false);
        $input.focus();
    }

    function aiError(msg) {
        removeTyping();
        addMessage('ai', '**Error:** ' + msg);
        done();
    }

    function saveChatHistory() {
        try {
            var toSave = chatHistory.slice(-50);
            localStorage.setItem(HISTORY_KEY, JSON.stringify(toSave));
        } catch(e) {}
    }

    function escHtml(text) {
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(text));
        return div.innerHTML;
    }

    // Show badge when generating and chat is closed
    setInterval(function () {
        if (isOpen) return;
        try {
            var state = JSON.parse(localStorage.getItem('wpcw_gen_state') || 'null');
            if (state && (state.status === 'generating' || state.status === 'completed')) {
                $badge.addClass('active');
            } else {
                $badge.removeClass('active');
            }
        } catch(e) {}
    }, 2000);

})(jQuery);
