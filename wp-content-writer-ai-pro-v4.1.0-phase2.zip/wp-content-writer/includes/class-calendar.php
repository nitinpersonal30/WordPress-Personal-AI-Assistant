<?php
/**
 * Editorial / content calendar — Phase 2.5.
 *
 * Reads scheduled and recently-published posts from WP and exposes them
 * grouped by ISO date for the calendar UI. Drag-drop moves call
 * self::reschedule() which updates `post_date` / `post_date_gmt` (and
 * keeps the WP scheduler hook in sync via wp_update_post). Workflow
 * state badges are emitted alongside each item so the calendar can
 * colour-code drafts vs. in-review vs. approved.
 */

if (!defined('ABSPATH')) exit;

class WPCW_Calendar {

    public static function get_range($start, $end, $args = array()) {
        $start = self::normalise_date($start);
        $end   = self::normalise_date($end, true);
        if (!$start || !$end) return array('items' => array(), 'by_day' => array());

        $defaults = array(
            'post_type'   => array('post', 'page'),
            'post_status' => array('draft', 'pending', 'future', 'publish', 'private'),
            'author'      => 0,
        );
        $a = wp_parse_args($args, $defaults);

        $query_args = array(
            'post_type'      => (array) $a['post_type'],
            'post_status'    => (array) $a['post_status'],
            'posts_per_page' => 500,
            'orderby'        => 'date',
            'order'          => 'ASC',
            'date_query'     => array(array(
                'after'     => $start,
                'before'    => $end,
                'inclusive' => true,
            )),
        );
        if (!empty($a['author'])) $query_args['author'] = (int) $a['author'];

        $q = new WP_Query($query_args);

        $items  = array();
        $by_day = array();
        foreach ($q->posts as $p) {
            $row = self::format_item($p);
            $items[] = $row;
            $day     = $row['date'];
            if (!isset($by_day[$day])) $by_day[$day] = array();
            $by_day[$day][] = $row;
        }
        ksort($by_day);

        return array(
            'items'  => $items,
            'by_day' => $by_day,
            'range'  => array('start' => $start, 'end' => $end),
            'totals' => self::summarise($items),
        );
    }

    public static function format_item($post) {
        if (!$post instanceof WP_Post) $post = get_post($post);
        if (!$post) return array();
        $state = class_exists('WPCW_Workflow') ? WPCW_Workflow::get_state($post->ID) : 'draft';
        $author = get_user_by('id', (int) $post->post_author);
        return array(
            'id'           => (int) $post->ID,
            'title'        => $post->post_title ?: '(no title)',
            'post_type'    => $post->post_type,
            'post_status'  => $post->post_status,
            'workflow'     => $state,
            'date'         => mysql2date('Y-m-d', $post->post_date_gmt ?: $post->post_date, false),
            'datetime'     => mysql2date('c',     $post->post_date_gmt ?: $post->post_date, false),
            'author_id'    => (int) $post->post_author,
            'author_name'  => $author ? $author->display_name : '',
            'edit_url'     => get_edit_post_link($post->ID, 'raw'),
            'view_url'     => get_permalink($post->ID),
            'colour'       => self::state_colour($state, $post->post_status),
        );
    }

    public static function reschedule($post_id, $new_date) {
        $post_id = (int) $post_id;
        if (!$post_id) return new WP_Error('bad_id', 'Invalid post id.');
        $post = get_post($post_id);
        if (!$post) return new WP_Error('not_found', 'Post not found.');

        if (!current_user_can('wpcw_manage_calendar') && !current_user_can('edit_post', $post_id)) {
            return new WP_Error('forbidden', 'Cannot reschedule this post.');
        }

        $ts = self::parse_datetime($new_date);
        if (!$ts) return new WP_Error('bad_date', 'Invalid date.');

        $local = gmdate('Y-m-d H:i:s', $ts);
        $update = array('ID' => $post_id, 'post_date' => $local, 'post_date_gmt' => $local);

        // If moving a published post into the future, switch to scheduled.
        if ($ts > time() && in_array($post->post_status, array('publish'), true)) {
            $update['post_status'] = 'future';
        } elseif ($ts <= time() && 'future' === $post->post_status) {
            $update['post_status'] = 'publish';
        }

        $res = wp_update_post($update, true);
        if (is_wp_error($res)) return $res;

        if (class_exists('WPCW_Activity_Log')) {
            WPCW_Activity_Log::log('calendar.reschedule', array(
                'object_type' => 'post',
                'object_id'   => $post_id,
                'message'     => sprintf('Rescheduled "%s" → %s', $post->post_title, $local),
                'meta'        => array('to' => $local),
            ));
        }
        return self::format_item($post_id);
    }

    public static function quick_create($args) {
        $defaults = array(
            'title'      => '',
            'date'       => '',
            'post_type'  => 'post',
            'workflow'   => WPCW_Workflow::STATE_DRAFT,
            'author'     => get_current_user_id(),
            'content'    => '',
        );
        $a = wp_parse_args($args, $defaults);
        if ('' === trim($a['title'])) return new WP_Error('empty_title', 'Title required.');
        $ts = $a['date'] ? self::parse_datetime($a['date']) : time();
        if (!$ts) $ts = time();
        $post_status = $ts > time() ? 'future' : 'draft';
        $local = gmdate('Y-m-d H:i:s', $ts);

        $post_id = wp_insert_post(array(
            'post_title'    => sanitize_text_field($a['title']),
            'post_content'  => wp_kses_post($a['content']),
            'post_type'     => sanitize_key($a['post_type']),
            'post_status'   => $post_status,
            'post_author'   => (int) $a['author'],
            'post_date'     => $local,
            'post_date_gmt' => $local,
        ), true);
        if (is_wp_error($post_id)) return $post_id;

        if (class_exists('WPCW_Workflow')) {
            update_post_meta($post_id, WPCW_Workflow::META_STATE, sanitize_key($a['workflow']));
        }
        if (class_exists('WPCW_Activity_Log')) {
            WPCW_Activity_Log::log('calendar.created', array(
                'object_type' => 'post',
                'object_id'   => (int) $post_id,
                'message'     => sprintf('Calendar item "%s" created', $a['title']),
                'meta'        => array('date' => $local),
            ));
        }
        return self::format_item($post_id);
    }

    public static function summarise($items) {
        $totals = array(
            'total'    => count($items),
            'draft'    => 0,
            'review'   => 0,
            'approved' => 0,
            'scheduled'=> 0,
            'published'=> 0,
        );
        foreach ($items as $i) {
            if ('future' === $i['post_status'])  $totals['scheduled']++;
            if ('publish' === $i['post_status']) $totals['published']++;
            $w = $i['workflow'];
            if (isset($totals[$w])) $totals[$w]++;
        }
        return $totals;
    }

    public static function state_colour($workflow, $post_status) {
        $palette = array(
            'draft'     => '#94a3b8',
            'review'    => '#f59e0b',
            'approved'  => '#10b981',
            'rejected'  => '#ef4444',
            'published' => '#2563eb',
        );
        if ('future' === $post_status) return '#7c3aed';
        return $palette[$workflow] ?? '#94a3b8';
    }

    private static function normalise_date($input, $end = false) {
        if (!$input) return null;
        $ts = is_numeric($input) ? (int) $input : strtotime((string) $input);
        if (!$ts) return null;
        return $end ? gmdate('Y-m-d 23:59:59', $ts) : gmdate('Y-m-d 00:00:00', $ts);
    }

    private static function parse_datetime($input) {
        if (!$input) return 0;
        $ts = is_numeric($input) ? (int) $input : strtotime((string) $input);
        return $ts ?: 0;
    }
}
