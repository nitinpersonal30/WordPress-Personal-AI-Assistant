<?php
/**
 * Website Analyzer — WP Content Writer AI Pro
 * Scans the entire WordPress site: pages, posts, theme, plugins, settings, CSS, SEO, performance
 * and provides AI-powered analysis and recommendations
 */

if (!defined('ABSPATH')) exit;

class WPCW_Site_Analyzer {

    /**
     * Get complete site overview
     */
    public static function get_site_overview() {
        return array(
            'site_info'      => self::get_site_info(),
            'content_stats'  => self::get_content_stats(),
            'theme_info'     => self::get_theme_info(),
            'active_plugins' => self::get_active_plugins_info(),
            'menus'          => self::get_menus_info(),
            'widgets'        => self::get_widgets_info(),
            'custom_css'     => self::get_custom_css(),
            'seo_status'     => self::get_seo_status(),
            'performance'    => self::get_performance_info(),
            'media_stats'    => self::get_media_stats(),
            'users_info'     => self::get_users_info(),
            'recent_changes' => self::get_recent_changes(),
        );
    }

    /**
     * Get basic site information
     */
    public static function get_site_info() {
        global $wp_version;
        return array(
            'name'           => get_bloginfo('name'),
            'description'    => get_bloginfo('description'),
            'url'            => home_url(),
            'admin_url'      => admin_url(),
            'wp_version'     => $wp_version,
            'php_version'    => phpversion(),
            'mysql_version'  => self::get_db_version(),
            'language'       => get_locale(),
            'timezone'       => wp_timezone_string(),
            'permalink'      => get_option('permalink_structure') ?: 'Plain',
            'multisite'      => is_multisite(),
            'memory_limit'   => WP_MEMORY_LIMIT,
            'max_upload'     => size_format(wp_max_upload_size()),
            'debug_mode'     => defined('WP_DEBUG') && WP_DEBUG,
            'ssl'            => is_ssl(),
            'site_icon'      => has_site_icon(),
        );
    }

    /**
     * Get content statistics
     */
    public static function get_content_stats() {
        $post_types = get_post_types(array('public' => true), 'objects');
        $stats = array();

        foreach ($post_types as $pt) {
            $counts = wp_count_posts($pt->name);
            $stats[$pt->name] = array(
                'label'     => $pt->label,
                'published' => isset($counts->publish) ? (int) $counts->publish : 0,
                'draft'     => isset($counts->draft) ? (int) $counts->draft : 0,
                'pending'   => isset($counts->pending) ? (int) $counts->pending : 0,
                'trash'     => isset($counts->trash) ? (int) $counts->trash : 0,
                'total'     => isset($counts->publish) ? ((int)$counts->publish + (int)$counts->draft + (int)$counts->pending) : 0,
            );
        }

        // Categories and tags
        $categories = wp_count_terms('category');
        $tags       = wp_count_terms('post_tag');

        $stats['_taxonomy'] = array(
            'categories' => is_wp_error($categories) ? 0 : (int) $categories,
            'tags'       => is_wp_error($tags) ? 0 : (int) $tags,
        );

        // Comments
        $comments = wp_count_comments();
        $stats['_comments'] = array(
            'approved' => (int) $comments->approved,
            'pending'  => (int) $comments->moderated,
            'spam'     => (int) $comments->spam,
            'total'    => (int) $comments->total_comments,
        );

        return $stats;
    }

    /**
     * Get all pages with structure
     */
    public static function get_all_pages($limit = 100) {
        $pages = get_posts(array(
            'post_type'      => 'page',
            'post_status'    => array('publish', 'draft', 'pending'),
            'posts_per_page' => $limit,
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        ));

        $result = array();
        foreach ($pages as $page) {
            $result[] = array(
                'id'         => $page->ID,
                'title'      => $page->post_title,
                'url'        => get_permalink($page->ID),
                'status'     => $page->post_status,
                'template'   => get_page_template_slug($page->ID) ?: 'default',
                'parent'     => $page->post_parent,
                'modified'   => $page->post_modified,
                'word_count' => str_word_count(strip_tags($page->post_content)),
                'has_content'=> !empty(trim($page->post_content)),
                'excerpt'    => wp_trim_words(strip_tags($page->post_content), 30),
            );
        }
        return $result;
    }

    /**
     * Get all posts with meta
     */
    public static function get_all_posts($limit = 100, $offset = 0) {
        $posts = get_posts(array(
            'post_type'      => 'post',
            'post_status'    => array('publish', 'draft', 'pending'),
            'posts_per_page' => $limit,
            'offset'         => $offset,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ));

        $result = array();
        foreach ($posts as $post) {
            $cats = wp_get_post_categories($post->ID, array('fields' => 'names'));
            $tags = wp_get_post_tags($post->ID, array('fields' => 'names'));

            $seo_meta = array();
            if (WPCW_SEO::is_rankmath_active()) {
                $seo_meta = array(
                    'focus_keyword' => get_post_meta($post->ID, 'rank_math_focus_keyword', true),
                    'seo_score'     => get_post_meta($post->ID, 'rank_math_seo_score', true),
                    'seo_title'     => get_post_meta($post->ID, 'rank_math_title', true),
                    'seo_desc'      => get_post_meta($post->ID, 'rank_math_description', true),
                );
            } elseif (WPCW_SEO::is_yoast_active()) {
                $seo_meta = array(
                    'focus_keyword' => get_post_meta($post->ID, '_yoast_wpseo_focuskw', true),
                    'seo_title'     => get_post_meta($post->ID, '_yoast_wpseo_title', true),
                    'seo_desc'      => get_post_meta($post->ID, '_yoast_wpseo_metadesc', true),
                );
            }

            $result[] = array(
                'id'         => $post->ID,
                'title'      => $post->post_title,
                'url'        => get_permalink($post->ID),
                'status'     => $post->post_status,
                'date'       => $post->post_date,
                'modified'   => $post->post_modified,
                'categories' => $cats,
                'tags'       => $tags,
                'word_count' => str_word_count(strip_tags($post->post_content)),
                'has_featured_image' => has_post_thumbnail($post->ID),
                'seo'        => $seo_meta,
                'excerpt'    => wp_trim_words(strip_tags($post->post_content), 30),
            );
        }
        return $result;
    }

    /**
     * Get single page/post full content for analysis
     */
    public static function get_post_content($post_id) {
        $post = get_post($post_id);
        if (!$post) return null;

        return array(
            'id'         => $post->ID,
            'title'      => $post->post_title,
            'content'    => $post->post_content,
            'excerpt'    => $post->post_excerpt,
            'status'     => $post->post_status,
            'type'       => $post->post_type,
            'url'        => get_permalink($post->ID),
            'template'   => get_page_template_slug($post->ID),
            'word_count' => str_word_count(strip_tags($post->post_content)),
            'modified'   => $post->post_modified,
            'author'     => get_the_author_meta('display_name', $post->post_author),
            'css_classes' => get_post_meta($post->ID, '_elementor_css', true),
        );
    }

    /**
     * Get theme information
     */
    public static function get_theme_info() {
        $theme = wp_get_theme();
        $parent = $theme->parent();

        $info = array(
            'name'        => $theme->get('Name'),
            'version'     => $theme->get('Version'),
            'author'      => $theme->get('Author'),
            'description' => $theme->get('Description'),
            'is_child'    => $theme->parent() ? true : false,
            'template'    => $theme->get_template(),
            'stylesheet'  => $theme->get_stylesheet(),
        );

        if ($parent) {
            $info['parent_theme'] = array(
                'name'    => $parent->get('Name'),
                'version' => $parent->get('Version'),
            );
        }

        // Theme support
        $info['supports'] = array(
            'title_tag'        => current_theme_supports('title-tag'),
            'post_thumbnails'  => current_theme_supports('post-thumbnails'),
            'custom_logo'      => current_theme_supports('custom-logo'),
            'menus'            => current_theme_supports('menus'),
            'widgets'          => current_theme_supports('widgets'),
            'woocommerce'      => current_theme_supports('woocommerce'),
            'editor_styles'    => current_theme_supports('editor-styles'),
            'responsive_embeds'=> current_theme_supports('responsive-embeds'),
        );

        return $info;
    }

    /**
     * Get active plugins information
     */
    public static function get_active_plugins_info() {
        $active = get_option('active_plugins', array());
        $all    = get_plugins();
        $result = array();

        foreach ($active as $plugin_file) {
            if (isset($all[$plugin_file])) {
                $p = $all[$plugin_file];
                $result[] = array(
                    'name'        => $p['Name'],
                    'version'     => $p['Version'],
                    'author'      => $p['Author'],
                    'description' => wp_strip_all_tags($p['Description']),
                    'file'        => $plugin_file,
                );
            }
        }

        return $result;
    }

    /**
     * Get menus information
     */
    public static function get_menus_info() {
        $locations = get_nav_menu_locations();
        $menus     = wp_get_nav_menus();
        $result    = array();

        foreach ($menus as $menu) {
            $items = wp_get_nav_menu_items($menu->term_id);
            $menu_items = array();
            if ($items) {
                foreach ($items as $item) {
                    $menu_items[] = array(
                        'title'  => $item->title,
                        'url'    => $item->url,
                        'type'   => $item->type,
                        'parent' => (int) $item->menu_item_parent,
                    );
                }
            }

            $location_name = '';
            foreach ($locations as $loc => $menu_id) {
                if ($menu_id == $menu->term_id) {
                    $location_name = $loc;
                    break;
                }
            }

            $result[] = array(
                'name'     => $menu->name,
                'id'       => $menu->term_id,
                'location' => $location_name,
                'items'    => $menu_items,
                'count'    => count($menu_items),
            );
        }

        return $result;
    }

    /**
     * Get widgets information
     */
    public static function get_widgets_info() {
        $sidebars = wp_get_sidebars_widgets();
        $result   = array();

        foreach ($sidebars as $sidebar_id => $widgets) {
            if ('wp_inactive_widgets' === $sidebar_id || !is_array($widgets)) continue;
            $result[$sidebar_id] = array(
                'count'   => count($widgets),
                'widgets' => $widgets,
            );
        }

        return $result;
    }

    /**
     * Get custom CSS
     */
    public static function get_custom_css() {
        $custom_css = wp_get_custom_css();
        return array(
            'has_custom_css' => !empty(trim($custom_css)),
            'css'            => $custom_css,
            'length'         => strlen($custom_css),
        );
    }

    /**
     * Get SEO status overview
     */
    public static function get_seo_status() {
        $seo_plugin = WPCW_SEO::get_active_seo_plugin();

        // Count posts without SEO meta
        $posts_without_seo = 0;
        $posts_without_featured = 0;
        $total_published = 0;

        $all_posts = get_posts(array(
            'post_type'      => array('post', 'page'),
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ));

        $total_published = count($all_posts);

        foreach ($all_posts as $pid) {
            $has_seo = false;
            if ('rankmath' === $seo_plugin) {
                $has_seo = !empty(get_post_meta($pid, 'rank_math_focus_keyword', true));
            } elseif ('yoast' === $seo_plugin) {
                $has_seo = !empty(get_post_meta($pid, '_yoast_wpseo_focuskw', true));
            }
            if (!$has_seo) $posts_without_seo++;
            if (!has_post_thumbnail($pid)) $posts_without_featured++;
        }

        return array(
            'seo_plugin'            => $seo_plugin,
            'total_published'       => $total_published,
            'without_seo_meta'      => $posts_without_seo,
            'without_featured_image'=> $posts_without_featured,
            'sitemap_url'           => home_url('/sitemap_index.xml'),
            'robots_txt'            => home_url('/robots.txt'),
        );
    }

    /**
     * Get performance-related info
     */
    public static function get_performance_info() {
        return array(
            'php_memory_limit'    => ini_get('memory_limit'),
            'wp_memory_limit'     => WP_MEMORY_LIMIT,
            'max_execution_time'  => ini_get('max_execution_time'),
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'post_max_size'       => ini_get('post_max_size'),
            'opcache_enabled'     => function_exists('opcache_get_status'),
            'object_cache'        => wp_using_ext_object_cache(),
            'cron_jobs_count'     => count(_get_cron_array() ?: array()),
            'autoloaded_options'  => self::get_autoloaded_options_size(),
        );
    }

    /**
     * Get media library stats
     */
    public static function get_media_stats() {
        $counts = wp_count_attachments();
        $total  = 0;
        $types  = array();
        foreach ((array) $counts as $mime => $count) {
            if ('trash' === $mime) continue;
            $total += (int) $count;
            $types[$mime] = (int) $count;
        }

        return array(
            'total'     => $total,
            'by_type'   => $types,
            'upload_dir'=> wp_get_upload_dir()['basedir'],
        );
    }

    /**
     * Get users info
     */
    public static function get_users_info() {
        $user_count = count_users();
        return array(
            'total'    => $user_count['total_users'],
            'by_role'  => $user_count['avail_roles'],
        );
    }

    /**
     * Get recent changes
     */
    public static function get_recent_changes() {
        $recent = get_posts(array(
            'post_type'      => array('post', 'page'),
            'post_status'    => 'any',
            'posts_per_page' => 10,
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ));

        $result = array();
        foreach ($recent as $post) {
            $result[] = array(
                'id'       => $post->ID,
                'title'    => $post->post_title,
                'type'     => $post->post_type,
                'status'   => $post->post_status,
                'modified' => $post->post_modified,
                'author'   => get_the_author_meta('display_name', $post->post_author),
            );
        }
        return $result;
    }

    // ── Private helpers ──

    private static function get_db_version() {
        global $wpdb;
        return $wpdb->db_version();
    }

    private static function get_autoloaded_options_size() {
        global $wpdb;
        $size = $wpdb->get_var(
            "SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options} WHERE autoload = 'yes'"
        );
        return $size ? size_format((int) $size) : '0 B';
    }
}
