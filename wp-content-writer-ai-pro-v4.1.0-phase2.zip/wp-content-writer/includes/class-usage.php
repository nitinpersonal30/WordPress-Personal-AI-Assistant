<?php
/**
 * Usage tracking — records monthly consumption (words, posts, API calls,
 * tokens, cost) and exposes summaries for the analytics dashboard.
 *
 * Data is stored per-month in wp_options keyed `wpcw_usage_YYYYMM` so the
 * row never grows unbounded. Per-user breakdown is kept inside the same row.
 */

if (!defined('ABSPATH')) exit;

class WPCW_Usage {

    const OPTION_PREFIX  = 'wpcw_usage_';
    const HISTORY_OPTION = 'wpcw_usage_history';
    const RETENTION_MONTHS = 24;

    public static function current_period() {
        return gmdate('Ym');
    }

    public static function option_for_period($period) {
        return self::OPTION_PREFIX . sanitize_key($period);
    }

    private static function default_period_data() {
        return array(
            'period'    => self::current_period(),
            'words'     => 0,
            'posts'     => 0,
            'api_calls' => 0,
            'tokens_in' => 0,
            'tokens_out'=> 0,
            'cost_usd'  => 0.0,
            'errors'    => 0,
            'by_user'   => array(),
            'by_provider' => array(),
            'by_template' => array(),
            'days'      => array(),
        );
    }

    public static function get_period($period = null) {
        if (null === $period) $period = self::current_period();
        $data = get_option(self::option_for_period($period), array());
        if (!is_array($data)) $data = array();
        return wp_parse_args($data, self::default_period_data());
    }

    /**
     * Record a generation event. Increments counters and writes back.
     *
     * @param array $event {
     *   @type int    user_id     User who triggered the call.
     *   @type string provider    Provider key (groq, openai, anthropic…).
     *   @type string template    Template key, if any.
     *   @type int    words       Words produced.
     *   @type int    tokens_in   Prompt tokens.
     *   @type int    tokens_out  Completion tokens.
     *   @type float  cost_usd    Estimated cost in USD.
     *   @type bool   created_post Whether a WP post was created.
     *   @type bool   error       Whether the call failed.
     * }
     */
    public static function record($event) {
        $event = wp_parse_args($event, array(
            'user_id'      => get_current_user_id(),
            'provider'     => 'groq',
            'template'     => '',
            'words'        => 0,
            'tokens_in'    => 0,
            'tokens_out'   => 0,
            'cost_usd'     => 0.0,
            'created_post' => false,
            'error'        => false,
        ));

        $period = self::current_period();
        $option = self::option_for_period($period);
        $data = self::get_period($period);

        $data['period']     = $period;
        $data['api_calls'] += 1;
        if (!empty($event['error'])) {
            $data['errors'] += 1;
        } else {
            $data['words']      += (int) $event['words'];
            $data['tokens_in']  += (int) $event['tokens_in'];
            $data['tokens_out'] += (int) $event['tokens_out'];
            $data['cost_usd']   += (float) $event['cost_usd'];
            if (!empty($event['created_post'])) $data['posts'] += 1;
        }

        $uid = (int) $event['user_id'];
        if ($uid > 0) {
            if (!isset($data['by_user'][$uid])) $data['by_user'][$uid] = array('words' => 0, 'api_calls' => 0, 'posts' => 0);
            $data['by_user'][$uid]['words']     += (int) $event['words'];
            $data['by_user'][$uid]['api_calls'] += 1;
            if (!empty($event['created_post'])) $data['by_user'][$uid]['posts'] += 1;
        }

        $prov = sanitize_key($event['provider']);
        if ($prov) {
            if (!isset($data['by_provider'][$prov])) $data['by_provider'][$prov] = array('words' => 0, 'api_calls' => 0, 'cost_usd' => 0.0);
            $data['by_provider'][$prov]['words']     += (int) $event['words'];
            $data['by_provider'][$prov]['api_calls'] += 1;
            $data['by_provider'][$prov]['cost_usd']  += (float) $event['cost_usd'];
        }

        $tpl = sanitize_key($event['template']);
        if ($tpl) {
            if (!isset($data['by_template'][$tpl])) $data['by_template'][$tpl] = array('words' => 0, 'api_calls' => 0);
            $data['by_template'][$tpl]['words']     += (int) $event['words'];
            $data['by_template'][$tpl]['api_calls'] += 1;
        }

        $day = gmdate('Y-m-d');
        if (!isset($data['days'][$day])) $data['days'][$day] = array('words' => 0, 'api_calls' => 0, 'cost_usd' => 0.0);
        $data['days'][$day]['words']     += (int) $event['words'];
        $data['days'][$day]['api_calls'] += 1;
        $data['days'][$day]['cost_usd']  += (float) $event['cost_usd'];

        update_option($option, $data, false);
        self::record_period_in_history($period);
    }

    private static function record_period_in_history($period) {
        $history = get_option(self::HISTORY_OPTION, array());
        if (!is_array($history)) $history = array();
        if (!in_array($period, $history, true)) {
            $history[] = $period;
            sort($history);
            if (count($history) > self::RETENTION_MONTHS) {
                $drop = array_slice($history, 0, count($history) - self::RETENTION_MONTHS);
                foreach ($drop as $old) {
                    delete_option(self::option_for_period($old));
                }
                $history = array_slice($history, -self::RETENTION_MONTHS);
            }
            update_option(self::HISTORY_OPTION, $history, false);
        }
    }

    public static function get_history_periods() {
        $history = get_option(self::HISTORY_OPTION, array());
        return is_array($history) ? $history : array();
    }

    /**
     * Quota check for the current period. Returns array(
     *   'allowed' => bool,
     *   'reason'  => string,
     *   'usage'   => current usage,
     *   'limit'   => limit value (-1 = unlimited),
     * ) for the requested counter type.
     */
    public static function check_quota($type, $extra_amount = 0) {
        $quota = WPCW_License::get_quota();
        $limit = isset($quota[$type]) ? (int) $quota[$type] : -1;
        $data  = self::get_period();
        $usage = isset($data[$type]) ? (int) $data[$type] : 0;
        if ($limit < 0) {
            return array('allowed' => true, 'reason' => '', 'usage' => $usage, 'limit' => $limit);
        }
        if (($usage + $extra_amount) > $limit) {
            return array(
                'allowed' => false,
                'reason'  => sprintf('Monthly %s quota reached (%d / %d). Upgrade your plan or wait for next reset.', $type, $usage, $limit),
                'usage'   => $usage,
                'limit'   => $limit,
            );
        }
        return array('allowed' => true, 'reason' => '', 'usage' => $usage, 'limit' => $limit);
    }

    public static function summary() {
        $current = self::get_period();
        $quota   = WPCW_License::get_quota();
        $periods = self::get_history_periods();
        $months  = array();
        foreach (array_slice($periods, -12) as $p) {
            $row = self::get_period($p);
            $months[] = array(
                'period'    => $p,
                'label'     => self::format_period_label($p),
                'words'     => $row['words'],
                'posts'     => $row['posts'],
                'api_calls' => $row['api_calls'],
                'cost_usd'  => round($row['cost_usd'], 4),
                'errors'    => $row['errors'],
            );
        }
        $days = $current['days'];
        ksort($days);
        $daily = array();
        foreach ($days as $d => $row) {
            $daily[] = array_merge(array('day' => $d), $row);
        }

        $by_user = array();
        foreach ($current['by_user'] as $uid => $row) {
            $u = get_user_by('id', $uid);
            $by_user[] = array(
                'user_id'   => (int) $uid,
                'name'      => $u ? $u->display_name : ('User #' . $uid),
                'words'     => $row['words'],
                'api_calls' => $row['api_calls'],
                'posts'     => $row['posts'],
            );
        }
        usort($by_user, function ($a, $b) { return $b['words'] - $a['words']; });

        return array(
            'tier'        => WPCW_License::get_tier(),
            'plan'        => WPCW_License::get_plan_label(),
            'period'      => $current['period'],
            'period_label'=> self::format_period_label($current['period']),
            'quota'       => $quota,
            'usage'       => array(
                'words'     => $current['words'],
                'posts'     => $current['posts'],
                'api_calls' => $current['api_calls'],
                'tokens_in' => $current['tokens_in'],
                'tokens_out'=> $current['tokens_out'],
                'cost_usd'  => round($current['cost_usd'], 4),
                'errors'    => $current['errors'],
            ),
            'daily'       => $daily,
            'months'      => $months,
            'by_user'     => array_slice($by_user, 0, 25),
            'by_provider' => $current['by_provider'],
            'by_template' => $current['by_template'],
        );
    }

    public static function format_period_label($period) {
        if (strlen($period) === 6) {
            $year = substr($period, 0, 4);
            $month = substr($period, 4, 2);
            $ts = mktime(0, 0, 0, (int) $month, 1, (int) $year);
            return gmdate('M Y', $ts);
        }
        return $period;
    }

    public static function reset_current() {
        delete_option(self::option_for_period(self::current_period()));
    }
}
