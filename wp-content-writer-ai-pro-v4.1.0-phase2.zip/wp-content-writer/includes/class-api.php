<?php
/**
 * API Class — WP Content Writer AI Pro
 *
 * Multi-provider streaming + non-streaming chat completions, post creation
 * with SEO, plugin KB, site analyzer, site-wide changes, license / usage
 * / provider management endpoints.
 *
 * All AI calls flow through WPCW_Provider_Manager (Groq, OpenAI, Anthropic,
 * Gemini, OpenRouter) and are gated by per-tier feature flags + monthly
 * quotas + per-user rate limits.
 */

if (!defined('ABSPATH')) exit;

class WPCW_API {

    private $settings;
    /** @var WPCW_Provider_Manager */
    private $providers;

    public function __construct($settings, $providers = null) {
        $this->settings  = $settings;
        $this->providers = $providers instanceof WPCW_Provider_Manager ? $providers : new WPCW_Provider_Manager();
    }

    public function register_rest_routes() {

        // ── AI generation ──
        register_rest_route('wpcw/v1', '/stream', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_stream'),
            'permission_callback' => array($this, 'can_access'),
        ));
        register_rest_route('wpcw/v1', '/generate', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_generate'),
            'permission_callback' => array($this, 'can_access'),
        ));
        register_rest_route('wpcw/v1', '/status', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_status'),
            'permission_callback' => array($this, 'can_access'),
        ));

        // ── Post / SEO / KB ──
        register_rest_route('wpcw/v1', '/create-post', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_create_post'),
            'permission_callback' => array($this, 'can_access'),
        ));
        register_rest_route('wpcw/v1', '/seo-analyze', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_seo_analyze'),
            'permission_callback' => array($this, 'can_access'),
        ));
        register_rest_route('wpcw/v1', '/plugins/search', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_plugin_search'),
            'permission_callback' => array($this, 'can_access'),
        ));
        register_rest_route('wpcw/v1', '/plugins/categories', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_plugin_categories'),
            'permission_callback' => array($this, 'can_access'),
        ));
        register_rest_route('wpcw/v1', '/plugins/recommend', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_plugin_recommend'),
            'permission_callback' => array($this, 'can_access'),
        ));
        register_rest_route('wpcw/v1', '/history', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_history'),
            'permission_callback' => array($this, 'can_access'),
        ));
        register_rest_route('wpcw/v1', '/history/save', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_save_history'),
            'permission_callback' => array($this, 'can_access'),
        ));
        register_rest_route('wpcw/v1', '/stats', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_stats'),
            'permission_callback' => array($this, 'can_access'),
        ));

        // ── Site analyzer ──
        register_rest_route('wpcw/v1', '/site/overview', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_site_overview'),
            'permission_callback' => array($this, 'can_manage'),
        ));
        register_rest_route('wpcw/v1', '/site/pages', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_site_pages'),
            'permission_callback' => array($this, 'can_manage'),
        ));
        register_rest_route('wpcw/v1', '/site/posts', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_site_posts'),
            'permission_callback' => array($this, 'can_manage'),
        ));
        register_rest_route('wpcw/v1', '/site/content/(?P<id>\d+)', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_site_content'),
            'permission_callback' => array($this, 'can_manage'),
        ));
        register_rest_route('wpcw/v1', '/site/ai-analyze', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_site_ai_analyze'),
            'permission_callback' => array($this, 'can_manage'),
        ));

        // ── Site-wide changes ──
        register_rest_route('wpcw/v1', '/changes/find-replace', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_find_replace'),
            'permission_callback' => array($this, 'can_manage'),
        ));
        register_rest_route('wpcw/v1', '/changes/bulk-seo', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_bulk_seo'),
            'permission_callback' => array($this, 'can_manage'),
        ));
        register_rest_route('wpcw/v1', '/changes/css', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_update_css'),
            'permission_callback' => array($this, 'can_manage'),
        ));
        register_rest_route('wpcw/v1', '/changes/image-alt', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_image_alt'),
            'permission_callback' => array($this, 'can_manage'),
        ));
        register_rest_route('wpcw/v1', '/changes/ai-apply', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_ai_apply'),
            'permission_callback' => array($this, 'can_manage'),
        ));

        // ── License / Usage / Providers ──
        register_rest_route('wpcw/v1', '/license', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_license_get'),
            'permission_callback' => array($this, 'can_manage'),
        ));
        register_rest_route('wpcw/v1', '/license/activate', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_license_activate'),
            'permission_callback' => array($this, 'can_manage'),
        ));
        register_rest_route('wpcw/v1', '/license/deactivate', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_license_deactivate'),
            'permission_callback' => array($this, 'can_manage'),
        ));
        register_rest_route('wpcw/v1', '/usage', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_usage'),
            'permission_callback' => array($this, 'can_manage'),
        ));
        register_rest_route('wpcw/v1', '/providers', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_providers_get'),
            'permission_callback' => array($this, 'can_manage'),
        ));
        register_rest_route('wpcw/v1', '/providers', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_providers_save'),
            'permission_callback' => array($this, 'can_manage'),
        ));
        register_rest_route('wpcw/v1', '/providers/test', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_provider_test'),
            'permission_callback' => array($this, 'can_manage'),
        ));
        register_rest_route('wpcw/v1', '/onboarding/complete', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_onboarding_complete'),
            'permission_callback' => array($this, 'can_manage'),
        ));

        // ── Phase 2 — Team & Workflow ──
        register_rest_route('wpcw/v1', '/team', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_team_list'),
            'permission_callback' => array($this, 'can_team'),
        ));
        register_rest_route('wpcw/v1', '/team/role', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_team_set_role'),
            'permission_callback' => array($this, 'can_team'),
        ));
        register_rest_route('wpcw/v1', '/workflow/queue', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_workflow_queue'),
            'permission_callback' => array($this, 'can_view_queue'),
        ));
        register_rest_route('wpcw/v1', '/workflow/post/(?P<id>\d+)', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_workflow_get'),
            'permission_callback' => array($this, 'can_view_queue'),
        ));
        register_rest_route('wpcw/v1', '/workflow/transition', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_workflow_transition'),
            'permission_callback' => array($this, 'can_view_queue'),
        ));
        register_rest_route('wpcw/v1', '/workflow/comment', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_workflow_comment'),
            'permission_callback' => array($this, 'can_view_queue'),
        ));
        register_rest_route('wpcw/v1', '/workflow/assign', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_workflow_assign'),
            'permission_callback' => array($this, 'can_approve'),
        ));

        // Activity log.
        register_rest_route('wpcw/v1', '/activity', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_activity_list'),
            'permission_callback' => array($this, 'can_view_activity'),
        ));
        register_rest_route('wpcw/v1', '/activity/export', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_activity_export'),
            'permission_callback' => array($this, 'can_view_activity'),
        ));

        // Brand voice.
        register_rest_route('wpcw/v1', '/brand-voice', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_brand_list'),
            'permission_callback' => array($this, 'can_brand'),
        ));
        register_rest_route('wpcw/v1', '/brand-voice', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_brand_save'),
            'permission_callback' => array($this, 'can_brand'),
        ));
        register_rest_route('wpcw/v1', '/brand-voice/(?P<id>[a-z0-9_\-]+)', array(
            'methods'             => 'DELETE',
            'callback'            => array($this, 'handle_brand_delete'),
            'permission_callback' => array($this, 'can_brand'),
        ));
        register_rest_route('wpcw/v1', '/brand-voice/active', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_brand_set_active'),
            'permission_callback' => array($this, 'can_brand'),
        ));
        register_rest_route('wpcw/v1', '/brand-voice/analyze', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_brand_analyze'),
            'permission_callback' => array($this, 'can_brand'),
        ));

        // Calendar.
        register_rest_route('wpcw/v1', '/calendar', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_calendar_get'),
            'permission_callback' => array($this, 'can_view_calendar'),
        ));
        register_rest_route('wpcw/v1', '/calendar/move', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_calendar_move'),
            'permission_callback' => array($this, 'can_manage_calendar'),
        ));
        register_rest_route('wpcw/v1', '/calendar/quick-create', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_calendar_quick_create'),
            'permission_callback' => array($this, 'can_manage_calendar'),
        ));

        // Bulk.
        register_rest_route('wpcw/v1', '/bulk/jobs', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_bulk_list'),
            'permission_callback' => array($this, 'can_bulk'),
        ));
        register_rest_route('wpcw/v1', '/bulk/jobs', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_bulk_create'),
            'permission_callback' => array($this, 'can_bulk'),
        ));
        register_rest_route('wpcw/v1', '/bulk/jobs/(?P<id>\d+)', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_bulk_get'),
            'permission_callback' => array($this, 'can_bulk'),
        ));
        register_rest_route('wpcw/v1', '/bulk/jobs/(?P<id>\d+)/cancel', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_bulk_cancel'),
            'permission_callback' => array($this, 'can_bulk'),
        ));
        register_rest_route('wpcw/v1', '/bulk/jobs/(?P<id>\d+)', array(
            'methods'             => 'DELETE',
            'callback'            => array($this, 'handle_bulk_delete'),
            'permission_callback' => array($this, 'can_bulk'),
        ));
        register_rest_route('wpcw/v1', '/bulk/run-now', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'handle_bulk_run_now'),
            'permission_callback' => array($this, 'can_bulk'),
        ));
        register_rest_route('wpcw/v1', '/bulk/template-csv', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'handle_bulk_template_csv'),
            'permission_callback' => array($this, 'can_bulk'),
        ));
    }

    // ── Phase 2 permission helpers ────────────────────────────────────
    public function can_team()           { return current_user_can('wpcw_manage_team');     }
    public function can_view_queue()     { return current_user_can('wpcw_submit_review') || current_user_can('wpcw_approve'); }
    public function can_approve()        { return current_user_can('wpcw_approve');         }
    public function can_view_activity()  { return current_user_can('wpcw_view_activity');   }
    public function can_brand()          { return current_user_can('wpcw_manage_brand_voice'); }
    public function can_view_calendar()  { return current_user_can('wpcw_view_calendar');   }
    public function can_manage_calendar(){ return current_user_can('wpcw_manage_calendar'); }
    public function can_bulk()           { return current_user_can('wpcw_run_bulk');        }

    public function can_access() {
        return current_user_can('edit_posts');
    }

    public function can_manage() {
        return current_user_can('manage_options');
    }

    // =====================================================================
    // STREAMING (SSE)
    // =====================================================================

    public function handle_stream($request) {
        $limit = WPCW_Rate_Limiter::attempt('stream');
        if (empty($limit['allowed'])) {
            http_response_code(429);
            echo 'data: ' . wp_json_encode(array('error' => sprintf('Rate limit exceeded — try again in %ds.', $limit['retry_after']))) . "\n\n";
            return null;
        }
        $quota = WPCW_Usage::check_quota('api_calls');
        if (empty($quota['allowed'])) {
            http_response_code(402);
            echo 'data: ' . wp_json_encode(array('error' => $quota['reason'])) . "\n\n";
            return null;
        }

        $body   = json_decode($request->get_body(), true);
        $tpl_key = isset($body['template']) ? sanitize_key($body['template']) : '';
        $prompt  = isset($body['prompt']) ? sanitize_textarea_field($body['prompt']) : '';
        if ('' === $prompt) {
            $fields = isset($body['fields']) && is_array($body['fields']) ? $body['fields'] : array();
            $prompt = WPCW_Templates::build_prompt($tpl_key, $fields);
        }
        if ('' === $prompt) {
            http_response_code(400);
            echo "data: {\"error\":\"Prompt is empty\"}\n\n";
            return null;
        }

        $brand_voice_id = isset($body['brand_voice']) ? sanitize_key($body['brand_voice']) : '';
        $system = $this->get_system_context($brand_voice_id);

        while (ob_get_level()) ob_end_clean();
        nocache_headers();
        header('Content-Type: text/event-stream; charset=UTF-8');
        header('Cache-Control: no-cache');
        header('X-Accel-Buffering: no');

        $on_token = function ($token, $done) {
            $payload = array('token' => $token, 'done' => (bool) $done);
            echo 'data: ' . wp_json_encode($payload) . "\n\n";
            if (function_exists('flush')) @flush();
        };

        $messages = array(
            array('role' => 'system', 'content' => $system),
            array('role' => 'user',   'content' => $prompt),
        );

        $result = $this->providers->chat_stream($messages, array(
            'temperature' => 0.7,
            'top_p'       => 0.9,
            'max_tokens'  => 4096,
        ), $on_token);

        if (is_wp_error($result)) {
            echo 'data: ' . wp_json_encode(array('error' => $result->get_error_message())) . "\n\n";
            echo 'data: ' . wp_json_encode(array('token' => '', 'done' => true)) . "\n\n";
            if (function_exists('flush')) @flush();
            $this->record_usage($tpl_key, '', 0, 0, 0, 0.0, false, true);
            exit;
        }

        $content = isset($result['content']) ? $result['content'] : '';
        $words   = str_word_count(wp_strip_all_tags($content));
        $cost    = $this->estimate_cost($result);
        $this->record_usage(
            $tpl_key,
            isset($result['provider']) ? $result['provider'] : '',
            $words,
            isset($result['tokens_in']) ? (int) $result['tokens_in'] : 0,
            isset($result['tokens_out']) ? (int) $result['tokens_out'] : 0,
            (float) $cost,
            false,
            false
        );
        exit;
    }

    // =====================================================================
    // NON-STREAMING
    // =====================================================================

    public function handle_generate($request) {
        $limit = WPCW_Rate_Limiter::attempt('generate');
        if (empty($limit['allowed'])) {
            return new WP_Error('rate_limited', sprintf('Rate limit exceeded — try again in %ds.', $limit['retry_after']), array('status' => 429));
        }
        $quota = WPCW_Usage::check_quota('api_calls');
        if (empty($quota['allowed'])) {
            return new WP_Error('quota_exceeded', $quota['reason'], array('status' => 402));
        }

        $body    = json_decode($request->get_body(), true);
        $tpl_key = isset($body['template']) ? sanitize_key($body['template']) : '';
        $fields  = isset($body['fields']) && is_array($body['fields']) ? $body['fields'] : array();
        $prompt  = isset($body['prompt']) ? sanitize_textarea_field($body['prompt']) : '';
        if ('' === $prompt) $prompt = WPCW_Templates::build_prompt($tpl_key, $fields);
        if ('' === $prompt) return new WP_Error('empty', 'Prompt is empty.', array('status' => 400));
        $brand_voice_id = isset($body['brand_voice']) ? sanitize_key($body['brand_voice']) : '';

        $result = $this->provider_chat($prompt, array(), $brand_voice_id);
        if (is_wp_error($result)) {
            $this->record_usage($tpl_key, '', 0, 0, 0, 0.0, false, true);
            return new WP_Error('ai_error', $result->get_error_message(), array('status' => 500));
        }
        $content = isset($result['content']) ? $result['content'] : '';
        $words   = str_word_count(wp_strip_all_tags($content));
        $cost    = $this->estimate_cost($result);
        $this->record_usage(
            $tpl_key,
            isset($result['provider']) ? $result['provider'] : '',
            $words,
            isset($result['tokens_in']) ? (int) $result['tokens_in'] : 0,
            isset($result['tokens_out']) ? (int) $result['tokens_out'] : 0,
            (float) $cost,
            false,
            false
        );

        return rest_ensure_response(array(
            'content'  => $content,
            'model'    => isset($result['model']) ? $result['model'] : '',
            'provider' => isset($result['provider']) ? $result['provider'] : '',
        ));
    }

    // =====================================================================
    // CREATE POST WITH SEO
    // =====================================================================

    public function handle_create_post($request) {
        if (!WPCW_Rate_Limiter::attempt('create_post')['allowed']) {
            return new WP_Error('rate_limited', 'Rate limit exceeded.', array('status' => 429));
        }
        $quota = WPCW_Usage::check_quota('posts');
        if (empty($quota['allowed'])) {
            return new WP_Error('quota_exceeded', $quota['reason'], array('status' => 402));
        }

        $body    = json_decode($request->get_body(), true);
        $title   = isset($body['title'])   ? sanitize_text_field($body['title'])   : 'AI Generated Post';
        $content = isset($body['content']) ? wp_kses_post($body['content'])        : '';
        $status  = isset($body['status'])  ? sanitize_key($body['status'])         : 'draft';

        $focus_keyword   = isset($body['focus_keyword'])   ? sanitize_text_field($body['focus_keyword'])   : '';
        $seo_title       = isset($body['seo_title'])       ? sanitize_text_field($body['seo_title'])       : '';
        $seo_description = isset($body['seo_description']) ? sanitize_text_field($body['seo_description']) : '';

        $category   = isset($body['category'])  ? sanitize_text_field($body['category'])  : '';
        $tags       = isset($body['tags'])      ? sanitize_text_field($body['tags'])      : '';
        $post_type  = isset($body['post_type']) ? sanitize_key($body['post_type'])        : 'post';

        if ('' === $content) {
            return new WP_Error('empty_content', 'Content is empty.', array('status' => 400));
        }

        $formatted = $this->markdown_to_html($content);

        $post_data = array(
            'post_title'   => $title,
            'post_content' => $formatted,
            'post_status'  => $status,
            'post_author'  => get_current_user_id(),
            'post_type'    => $post_type,
        );

        if ($category && 'post' === $post_type) {
            $cat_id = term_exists($category, 'category');
            if (!$cat_id) $cat_id = wp_insert_term($category, 'category');
            if (!is_wp_error($cat_id)) {
                $post_data['post_category'] = array(is_array($cat_id) ? $cat_id['term_id'] : $cat_id);
            }
        }

        $post_id = wp_insert_post($post_data, true);
        if (is_wp_error($post_id)) {
            return new WP_Error('post_error', 'Post creation failed: ' . $post_id->get_error_message(), array('status' => 500));
        }

        if ($tags && 'post' === $post_type) {
            $tag_array = array_map('trim', explode(',', $tags));
            wp_set_post_tags($post_id, $tag_array);
        }

        if ($focus_keyword || $seo_title || $seo_description) {
            WPCW_SEO::set_seo_meta($post_id, array(
                'focus_keyword'   => $focus_keyword,
                'seo_title'       => $seo_title ? $seo_title : $title,
                'seo_description' => $seo_description,
            ));
        }

        $this->save_to_history($title, $content, 'post_created');
        WPCW_Usage::record(array(
            'user_id'      => get_current_user_id(),
            'provider'     => '',
            'words'        => str_word_count(wp_strip_all_tags($content)),
            'created_post' => true,
        ));

        return rest_ensure_response(array(
            'post_id'     => $post_id,
            'edit_url'    => get_edit_post_link($post_id, 'raw'),
            'view_url'    => get_permalink($post_id),
            'seo_applied' => ($focus_keyword || $seo_title || $seo_description),
            'seo_plugin'  => WPCW_SEO::get_active_seo_plugin(),
        ));
    }

    // =====================================================================
    // SEO ANALYSIS
    // =====================================================================

    public function handle_seo_analyze($request) {
        $body = json_decode($request->get_body(), true);
        $content     = isset($body['content'])     ? $body['content']     : '';
        $keyword     = isset($body['keyword'])     ? $body['keyword']     : '';
        $title       = isset($body['title'])       ? $body['title']       : '';
        $description = isset($body['description']) ? $body['description'] : '';
        $url         = isset($body['url'])         ? $body['url']         : '';

        if ('' === $content || '' === $keyword) {
            return new WP_Error('missing', 'Content and keyword are required.', array('status' => 400));
        }

        return rest_ensure_response(array(
            'analysis'  => WPCW_SEO::analyze_content($content, $keyword, $title, $description, $url),
            'checklist' => WPCW_SEO::get_rankmath_checklist(),
            'seo_plugin' => WPCW_SEO::get_active_seo_plugin(),
        ));
    }

    // =====================================================================
    // PLUGIN KB
    // =====================================================================

    public function handle_plugin_search($request) {
        $keyword = $request->get_param('q');
        if (!$keyword) return new WP_Error('missing', 'Search query is required.', array('status' => 400));
        $results = WPCW_Plugins_KB::search_plugins(sanitize_text_field($keyword));
        return rest_ensure_response(array(
            'results' => $results,
            'count'   => count($results),
            'total_plugins' => WPCW_Plugins_KB::get_total_count(),
        ));
    }

    public function handle_plugin_categories($request) {
        $categories = WPCW_Plugins_KB::get_categories();
        $counts = array();
        foreach (array_keys($categories) as $cat) {
            $counts[$cat] = count(WPCW_Plugins_KB::get_plugins_by_category($cat));
        }
        return rest_ensure_response(array(
            'categories' => $categories,
            'counts'     => $counts,
            'total'      => WPCW_Plugins_KB::get_total_count(),
        ));
    }

    public function handle_plugin_recommend($request) {
        $body = json_decode($request->get_body(), true);
        $need   = isset($body['need'])   ? sanitize_text_field($body['need'])   : '';
        $budget = isset($body['budget']) ? sanitize_key($body['budget'])        : 'no_limit';
        $limit  = isset($body['limit'])  ? absint($body['limit'])              : 5;
        if (!$need) return new WP_Error('missing', 'Need description is required.', array('status' => 400));
        return rest_ensure_response(array(
            'recommendations' => WPCW_Plugins_KB::get_recommendations($need, $budget, $limit),
            'count'           => 0,
        ));
    }

    // =====================================================================
    // HISTORY + STATS
    // =====================================================================

    public function handle_history($request) {
        $limit  = $request->get_param('limit')  ? absint($request->get_param('limit'))  : 20;
        $offset = $request->get_param('offset') ? absint($request->get_param('offset')) : 0;
        $history = get_option('wpcw_content_history', array());
        $history = array_reverse(is_array($history) ? $history : array());
        $total   = count($history);
        $items   = array_slice($history, $offset, $limit);
        return rest_ensure_response(array('items' => $items, 'total' => $total));
    }

    public function handle_save_history($request) {
        $body    = json_decode($request->get_body(), true);
        $title   = isset($body['title'])   ? sanitize_text_field($body['title'])      : '';
        $content = isset($body['content']) ? sanitize_textarea_field($body['content']): '';
        $type    = isset($body['type'])    ? sanitize_key($body['type'])              : 'generated';
        if (!$title || !$content) return new WP_Error('missing', 'Title and content are required.', array('status' => 400));
        $this->save_to_history($title, $content, $type);
        return rest_ensure_response(array('saved' => true));
    }

    public function handle_stats($request) {
        $history = get_option('wpcw_content_history', array());
        $history = is_array($history) ? $history : array();
        $total_generated = count($history);
        $total_words = 0; $types = array();
        foreach ($history as $item) {
            $total_words += str_word_count(isset($item['content']) ? $item['content'] : '');
            $type = isset($item['type']) ? $item['type'] : 'unknown';
            $types[$type] = (isset($types[$type]) ? $types[$type] : 0) + 1;
        }
        $usage = WPCW_Usage::summary();
        return rest_ensure_response(array(
            'total_generated'  => $total_generated,
            'total_words'      => $total_words,
            'types'            => $types,
            'total_templates'  => count(WPCW_Templates::get_all()),
            'total_plugins_kb' => WPCW_Plugins_KB::get_total_count(),
            'seo_plugin'       => WPCW_SEO::get_active_seo_plugin(),
            'ollama_online'    => $this->is_ollama_online(),
            'groq_online'      => $this->is_ollama_online(),
            'model'            => $this->settings->get_setting('model'),
            'plan'             => $usage['plan'],
            'tier'             => $usage['tier'],
            'usage_summary'    => $usage,
        ));
    }

    public function handle_status($request) {
        return rest_ensure_response(array(
            'online'     => $this->is_ollama_online(),
            'model'      => $this->settings->get_setting('model'),
            'curl'       => function_exists('curl_init'),
            'seo_plugin' => WPCW_SEO::get_active_seo_plugin(),
            'templates'  => count(WPCW_Templates::get_all()),
            'plugins_kb' => WPCW_Plugins_KB::get_total_count(),
            'plan'       => WPCW_License::get_plan_label(),
            'tier'       => WPCW_License::get_tier(),
            'provider'   => $this->active_provider_id(),
        ));
    }

    // =====================================================================
    // SITE ANALYZER
    // =====================================================================

    public function handle_site_overview($request) {
        return rest_ensure_response(WPCW_Site_Analyzer::get_site_overview());
    }

    public function handle_site_pages($request) {
        $limit = $request->get_param('limit') ? absint($request->get_param('limit')) : 100;
        $pages = WPCW_Site_Analyzer::get_all_pages($limit);
        return rest_ensure_response(array('pages' => $pages, 'total' => count($pages)));
    }

    public function handle_site_posts($request) {
        $limit  = $request->get_param('limit')  ? absint($request->get_param('limit'))  : 100;
        $offset = $request->get_param('offset') ? absint($request->get_param('offset')) : 0;
        $posts  = WPCW_Site_Analyzer::get_all_posts($limit, $offset);
        return rest_ensure_response(array('posts' => $posts, 'total' => count($posts)));
    }

    public function handle_site_content($request) {
        $post_id = (int) $request['id'];
        $content = WPCW_Site_Analyzer::get_post_content($post_id);
        if (!$content) return new WP_Error('not_found', 'Post not found.', array('status' => 404));
        return rest_ensure_response($content);
    }

    public function handle_site_ai_analyze($request) {
        $body     = json_decode($request->get_body(), true);
        $aspect   = isset($body['aspect'])   ? sanitize_text_field($body['aspect'])   : 'full';
        $question = isset($body['question']) ? sanitize_textarea_field($body['question']) : '';

        $site_info       = WPCW_Site_Analyzer::get_site_info();
        $content_stats   = WPCW_Site_Analyzer::get_content_stats();
        $theme_info      = WPCW_Site_Analyzer::get_theme_info();
        $active_plugins  = WPCW_Site_Analyzer::get_active_plugins_info();
        $seo_status      = WPCW_Site_Analyzer::get_seo_status();
        $custom_css      = WPCW_Site_Analyzer::get_custom_css();

        $context  = "WEBSITE ANALYSIS DATA:\n\n";
        $context .= 'Site: ' . $site_info['name'] . ' (' . $site_info['url'] . ")\n";
        $context .= 'Description: ' . $site_info['description'] . "\n";
        $context .= 'WordPress: ' . $site_info['wp_version'] . ' | PHP: ' . $site_info['php_version'] . "\n";
        $context .= 'Theme: ' . $theme_info['name'] . ' v' . $theme_info['version'] . "\n\n";
        $context .= "Content Stats:\n";
        foreach ($content_stats as $pt => $stats) {
            if (strpos($pt, '_') === 0) continue;
            $context .= '- ' . $stats['label'] . ': ' . $stats['total'] . ' total (' . $stats['published'] . " published)\n";
        }
        $context .= "\nActive Plugins (" . count($active_plugins) . "):\n";
        foreach (array_slice($active_plugins, 0, 20) as $p) {
            $context .= '- ' . $p['name'] . ' v' . $p['version'] . "\n";
        }
        $context .= "\nSEO: " . $seo_status['seo_plugin'] . ' | Posts without SEO: ' . $seo_status['without_seo_meta'] . '/' . $seo_status['total_published'] . "\n";
        $context .= 'Custom CSS: ' . ($custom_css['has_custom_css'] ? $custom_css['length'] . ' chars' : 'None') . "\n";

        $prompt = $context . "\n\n";
        if ($question) {
            $prompt .= 'USER QUESTION: ' . $question . "\n\nProvide a detailed, actionable answer based on the website data above.";
        } else {
            $prompt .= "Analyze this WordPress website and provide:\n1. Overall health score (out of 100)\n2. Top 5 issues found\n3. SEO recommendations\n4. Performance tips\n5. Plugin recommendations\n6. Content strategy suggestions\n\nBe specific and actionable.";
        }

        $result = $this->provider_chat($prompt, array('temperature' => 0.4));
        if (is_wp_error($result)) {
            return new WP_Error('ai_error', 'AI provider error: ' . $result->get_error_message(), array('status' => 500));
        }

        return rest_ensure_response(array(
            'analysis'   => isset($result['content']) ? $result['content'] : '',
            'site_data'  => array(
                'site_info'     => $site_info,
                'content_stats' => $content_stats,
                'seo_status'    => $seo_status,
                'theme'         => $theme_info['name'],
                'plugins_count' => count($active_plugins),
            ),
        ));
    }

    // =====================================================================
    // SITE-WIDE CHANGES
    // =====================================================================

    public function handle_find_replace($request) {
        $body = json_decode($request->get_body(), true);
        $search  = isset($body['search'])  ? $body['search']  : '';
        $replace = isset($body['replace']) ? $body['replace'] : '';
        $options = isset($body['options']) ? $body['options'] : array();
        if ('' === $search) return new WP_Error('empty', 'Search text is required.', array('status' => 400));
        $result = WPCW_Site_Changer::find_replace($search, $replace, $options);
        if (is_wp_error($result)) return $result;
        return rest_ensure_response($result);
    }

    public function handle_bulk_seo($request) {
        $body    = json_decode($request->get_body(), true);
        $options = isset($body['options']) ? $body['options'] : array();
        return rest_ensure_response(WPCW_Site_Changer::bulk_seo_update($options));
    }

    public function handle_update_css($request) {
        $body = json_decode($request->get_body(), true);
        $css  = isset($body['css'])  ? $body['css']                    : '';
        $mode = isset($body['mode']) ? sanitize_key($body['mode'])     : 'append';
        return rest_ensure_response(WPCW_Site_Changer::update_custom_css($css, $mode));
    }

    public function handle_image_alt($request) {
        $body    = json_decode($request->get_body(), true);
        $options = isset($body['options']) ? $body['options'] : array();
        return rest_ensure_response(WPCW_Site_Changer::bulk_image_alt($options));
    }

    public function handle_ai_apply($request) {
        if (!WPCW_Rate_Limiter::attempt('ai_apply')['allowed']) {
            return new WP_Error('rate_limited', 'Rate limit exceeded.', array('status' => 429));
        }
        $body        = json_decode($request->get_body(), true);
        $instruction = isset($body['instruction']) ? sanitize_textarea_field($body['instruction']) : '';
        if ('' === $instruction) {
            return new WP_Error('empty', 'Instruction is required.', array('status' => 400));
        }

        $site_info     = WPCW_Site_Analyzer::get_site_info();
        $content_stats = WPCW_Site_Analyzer::get_content_stats();
        $custom_css    = WPCW_Site_Analyzer::get_custom_css();
        $pages         = WPCW_Site_Analyzer::get_all_pages(50);
        $posts         = WPCW_Site_Analyzer::get_all_posts(50);

        $pages_summary = '';
        foreach ($pages as $p) $pages_summary .= '- [ID:' . $p['id'] . '] ' . $p['title'] . ' (' . $p['status'] . ")\n";
        $posts_summary = '';
        foreach ($posts as $p) $posts_summary .= '- [ID:' . $p['id'] . '] ' . $p['title'] . ' (' . $p['status'] . ")\n";

        $prompt  = "You are a WordPress site management AI. The user wants to make changes to their entire website.\n\n";
        $prompt .= 'SITE: ' . $site_info['name'] . ' (' . $site_info['url'] . ")\n\n";
        $prompt .= "PAGES:\n" . $pages_summary . "\n";
        $prompt .= "POSTS:\n" . $posts_summary . "\n";
        $prompt .= "CURRENT CSS:\n" . ($custom_css['has_custom_css'] ? substr($custom_css['css'], 0, 500) : 'None') . "\n\n";
        $prompt .= 'USER INSTRUCTION: ' . $instruction . "\n\n";
        $prompt .= "Respond with a JSON array of changes to apply. Each change should be an object with a 'type' field.\n";
        $prompt .= "Available types:\n";
        $prompt .= "- find_replace: {type:'find_replace', search:'old text', replace:'new text', options:{fields:['title','content','excerpt']}}\n";
        $prompt .= "- add_css: {type:'add_css', css:'.selector { property: value; }', mode:'append'}\n";
        $prompt .= "- update_post: {type:'update_post', post_id:123, data:{post_title:'new title', post_content:'new content'}}\n";
        $prompt .= "- update_seo: {type:'update_seo', post_id:123, meta:{focus_keyword:'keyword', seo_title:'title', seo_description:'desc'}}\n";
        $prompt .= "- bulk_seo: {type:'bulk_seo', options:{only_empty:true}}\n";
        $prompt .= "- image_alt: {type:'image_alt', options:{}}\n";
        $prompt .= "- site_identity: {type:'site_identity', data:{blogname:'new name', blogdescription:'new tagline'}}\n\n";
        $prompt .= "IMPORTANT: Return ONLY the JSON array, no explanation.";

        $result = $this->provider_chat($prompt, array('temperature' => 0.3, 'max_tokens' => 2048));
        if (is_wp_error($result)) {
            return new WP_Error('ai_error', 'AI provider error: ' . $result->get_error_message(), array('status' => 500));
        }
        $ai_response = isset($result['content']) ? $result['content'] : '';

        $changes = array();
        if (preg_match('/\[[\s\S]*\]/', $ai_response, $matches)) {
            $parsed = json_decode($matches[0], true);
            if (is_array($parsed)) $changes = $parsed;
        }

        if (empty($changes)) {
            return rest_ensure_response(array(
                'success'      => false,
                'message'      => 'AI could not generate structured changes. Here is the AI suggestion:',
                'ai_response'  => $ai_response,
                'instruction'  => $instruction,
            ));
        }

        return rest_ensure_response(array(
            'success'     => true,
            'instruction' => $instruction,
            'changes'     => $changes,
            'preview'     => true,
            'message'     => 'Review the changes below and click "Apply Changes" to execute them.',
        ));
    }

    // =====================================================================
    // LICENSE / USAGE / PROVIDERS
    // =====================================================================

    public function handle_license_get($request) {
        $data = WPCW_License::get_data();
        // Mask key for display.
        $key = $data['key'];
        if ($key) {
            $tail = substr($key, -4);
            $data['key_masked'] = str_repeat('•', max(4, strlen($key) - 4)) . $tail;
        } else {
            $data['key_masked'] = '';
        }
        unset($data['key']); // never expose plaintext over REST.
        $data['plan']     = WPCW_License::get_plan_label();
        $data['tier']     = WPCW_License::get_tier();
        $data['quota']    = WPCW_License::get_quota();
        $data['features'] = WPCW_License::feature_matrix()[WPCW_License::get_tier()];
        $data['matrix']   = WPCW_License::feature_matrix();
        return rest_ensure_response($data);
    }

    public function handle_license_activate($request) {
        $body = json_decode($request->get_body(), true);
        $key  = isset($body['license_key']) ? sanitize_text_field($body['license_key']) : '';
        $r    = WPCW_License::activate($key);
        return rest_ensure_response($r);
    }

    public function handle_license_deactivate($request) {
        return rest_ensure_response(WPCW_License::deactivate());
    }

    public function handle_usage($request) {
        return rest_ensure_response(WPCW_Usage::summary());
    }

    public function handle_providers_get($request) {
        $data = $this->providers->get_settings_data();
        // Mask api keys before sending to JS.
        foreach ($data['configs'] as $id => &$cfg) {
            if (!empty($cfg['api_key'])) {
                $tail = substr($cfg['api_key'], -4);
                $cfg['api_key_masked'] = str_repeat('•', max(4, strlen($cfg['api_key']) - 4)) . $tail;
                $cfg['api_key'] = ''; // do not expose plaintext.
            } else {
                $cfg['api_key_masked'] = '';
            }
        }
        unset($cfg);

        $providers = array();
        foreach ($this->providers->available_providers() as $id => $class) {
            $p = $this->providers->get($id);
            $providers[] = array(
                'id'           => $id,
                'label'        => $p ? $p->label() : ucfirst($id),
                'models'       => $p ? $p->models() : array(),
                'default_model'=> $p ? $p->default_model() : '',
            );
        }

        return rest_ensure_response(array(
            'data'      => $data,
            'providers' => $providers,
            'tier'      => WPCW_License::get_tier(),
            'multi_provider_enabled' => WPCW_License::is_feature_enabled('multi_provider'),
        ));
    }

    public function handle_providers_save($request) {
        if (!WPCW_License::is_feature_enabled('multi_provider')) {
            // Free tier may still update Groq config (the bundled default).
            $body = json_decode($request->get_body(), true);
            $current = $this->providers->get_settings_data();
            $allowed = array('groq');
            foreach ($body['configs'] as $id => $cfg) {
                if (!in_array($id, $allowed, true)) unset($body['configs'][$id]);
            }
            $body['active'] = 'groq';
            $body['fallback'] = array();
            $merged = wp_parse_args($body, $current);
            $this->providers->save_settings_data($merged);
            return rest_ensure_response(array('success' => true, 'tier' => 'free'));
        }

        $body = json_decode($request->get_body(), true);
        if (!is_array($body)) return new WP_Error('bad_request', 'Invalid payload.', array('status' => 400));
        $current = $this->providers->get_settings_data();
        $merged = wp_parse_args($body, $current);
        $this->providers->save_settings_data($merged);
        return rest_ensure_response(array('success' => true));
    }

    public function handle_provider_test($request) {
        $body = json_decode($request->get_body(), true);
        $id   = isset($body['provider']) ? sanitize_key($body['provider']) : '';
        $p = $this->providers->get($id);
        if (!$p) return new WP_Error('bad_provider', 'Unknown provider.', array('status' => 400));
        $r = $p->chat(array(array('role' => 'user', 'content' => 'Say "ok".')), array('max_tokens' => 5));
        if (is_wp_error($r)) {
            return rest_ensure_response(array('success' => false, 'message' => $r->get_error_message()));
        }
        return rest_ensure_response(array(
            'success' => true,
            'message' => 'Provider is reachable.',
            'sample'  => substr(isset($r['content']) ? $r['content'] : '', 0, 200),
            'model'   => isset($r['model']) ? $r['model'] : '',
        ));
    }

    public function handle_onboarding_complete($request) {
        WPCW_Onboarding::mark_complete();
        return rest_ensure_response(array('success' => true));
    }

    // =====================================================================
    // HELPERS
    // =====================================================================

    private function provider_chat($prompt, $options = array(), $brand_voice_id = '') {
        $messages = array(
            array('role' => 'system', 'content' => $this->get_system_context($brand_voice_id)),
            array('role' => 'user',   'content' => $prompt),
        );
        $opts = wp_parse_args($options, array(
            'temperature' => 0.7,
            'top_p'       => 0.9,
            'max_tokens'  => 4096,
        ));
        return $this->providers->chat($messages, $opts);
    }

    private function active_provider_id() {
        $p = $this->providers->get_active();
        return $p ? $p->id() : '';
    }

    private function estimate_cost($result) {
        if (!is_array($result)) return 0.0;
        $pid = isset($result['provider']) ? $result['provider'] : '';
        $p = $this->providers->get($pid);
        if (!$p) return 0.0;
        return $p->estimate_cost(
            isset($result['tokens_in']) ? (int) $result['tokens_in'] : 0,
            isset($result['tokens_out']) ? (int) $result['tokens_out'] : 0,
            isset($result['model']) ? $result['model'] : ''
        );
    }

    private function record_usage($template, $provider, $words, $tokens_in, $tokens_out, $cost, $created_post = false, $error = false) {
        WPCW_Usage::record(array(
            'user_id'      => get_current_user_id(),
            'provider'     => $provider,
            'template'     => $template,
            'words'        => (int) $words,
            'tokens_in'    => (int) $tokens_in,
            'tokens_out'   => (int) $tokens_out,
            'cost_usd'     => (float) $cost,
            'created_post' => (bool) $created_post,
            'error'        => (bool) $error,
        ));
    }

    private function get_system_context($brand_voice_id = '') {
        $base = 'You are an expert AI content writer assistant specialized in WordPress, SEO, Digital Marketing, Web Development (PHP, HTML, CSS, Python), Elementor, WooCommerce, and Rank Math SEO optimization. You know 500+ WordPress plugins deeply. Always provide high-quality, actionable, and well-structured content. Format your output with proper headings (## for H2, ### for H3), bullet points, and bold text where appropriate. Provide specific, detailed answers - not generic ones.';
        if (class_exists('WPCW_Brand_Voice')) {
            $voice = WPCW_Brand_Voice::system_prompt($brand_voice_id);
            if ($voice) $base .= "\n\n" . $voice;
        }
        return $base;
    }

    public function is_ollama_online() {
        $p = $this->providers->get_active();
        if (!$p) return false;
        if ('' === (string) $p->get_config('api_key')) return false;
        return $p->ping();
    }

    private function save_to_history($title, $content, $type = 'generated') {
        $history = get_option('wpcw_content_history', array());
        if (!is_array($history)) $history = array();
        $history[] = array(
            'title'   => $title,
            'content' => substr($content, 0, 500),
            'type'    => $type,
            'date'    => current_time('mysql'),
            'words'   => str_word_count($content),
            'user'    => get_current_user_id(),
        );
        if (count($history) > 200) {
            $history = array_slice($history, -200);
        }
        update_option('wpcw_content_history', $history);
    }

    public static function public_markdown_to_html($text) {
        $api = new self(null, null);
        return $api->markdown_to_html($text);
    }

    private function markdown_to_html($text) {
        $text = preg_replace('/^######\s+(.+)/m', '<h6>$1</h6>', $text);
        $text = preg_replace('/^#####\s+(.+)/m',  '<h5>$1</h5>', $text);
        $text = preg_replace('/^####\s+(.+)/m',   '<h4>$1</h4>', $text);
        $text = preg_replace('/^###\s+(.+)/m',    '<h3>$1</h3>', $text);
        $text = preg_replace('/^##\s+(.+)/m',     '<h2>$1</h2>', $text);
        $text = preg_replace('/^#\s+(.+)/m',      '<h1>$1</h1>', $text);
        $text = preg_replace('/\*\*\*(.+?)\*\*\*/s', '<strong><em>$1</em></strong>', $text);
        $text = preg_replace('/\*\*(.+?)\*\*/s', '<strong>$1</strong>', $text);
        $text = preg_replace('/\*(.+?)\*/s',     '<em>$1</em>', $text);
        $text = preg_replace('/^[\-\*]\s+(.+)/m', '<li>$1</li>', $text);
        $text = preg_replace('/(<li>.*<\/li>)/s', '<ul>$1</ul>', $text);
        $text = preg_replace('/^\d+\.\s+(.+)/m',  '<li>$1</li>', $text);
        return wpautop($text);
    }

    // =====================================================================
    // PHASE 2 — Team & Roles
    // =====================================================================

    public function handle_team_list() {
        return rest_ensure_response(array(
            'team'         => WPCW_Roles::list_team_members(),
            'roles'        => WPCW_Roles::role_labels(),
            'capabilities' => WPCW_Roles::cap_labels(),
            'matrix'       => WPCW_Roles::capability_matrix(),
        ));
    }

    public function handle_team_set_role($request) {
        $body    = json_decode($request->get_body(), true);
        $user_id = isset($body['user_id']) ? (int) $body['user_id'] : 0;
        $role    = isset($body['role'])    ? sanitize_key($body['role']) : '';
        $res = WPCW_Roles::set_user_role($user_id, $role);
        if (is_wp_error($res)) return $res;
        WPCW_Activity_Log::log('team.role_set', array(
            'object_type' => 'user',
            'object_id'   => $user_id,
            'message'     => sprintf('Role %s assigned by team manager', $role),
            'meta'        => array('role' => $role),
        ));
        return rest_ensure_response(array('success' => true, 'team' => WPCW_Roles::list_team_members()));
    }

    // =====================================================================
    // PHASE 2 — Approval Workflow
    // =====================================================================

    public function handle_workflow_queue($request) {
        $state    = sanitize_key($request->get_param('state') ?: WPCW_Workflow::STATE_REVIEW);
        $assignee = (int) $request->get_param('assignee');
        $page     = max(1, (int) $request->get_param('page'));
        $per_page = min(100, max(1, (int) ($request->get_param('per_page') ?: 30)));
        $data = WPCW_Workflow::queue(array(
            'state'    => $state,
            'assignee' => $assignee,
            'page'     => $page,
            'per_page' => $per_page,
        ));
        return rest_ensure_response(array_merge($data, array(
            'counts' => WPCW_Workflow::counts(),
            'states' => WPCW_Workflow::states(),
        )));
    }

    public function handle_workflow_get($request) {
        $id   = (int) $request->get_param('id');
        $full = WPCW_Workflow::get_full($id);
        if (!$full) return new WP_Error('not_found', 'Post not found.', array('status' => 404));
        return rest_ensure_response($full);
    }

    public function handle_workflow_transition($request) {
        $body    = json_decode($request->get_body(), true);
        $post_id = isset($body['post_id']) ? (int) $body['post_id'] : 0;
        $target  = isset($body['state'])   ? sanitize_key($body['state']) : '';
        $note    = isset($body['note'])    ? sanitize_textarea_field($body['note']) : '';
        if (!$post_id || !$target) return new WP_Error('bad_request', 'post_id and state required.', array('status' => 400));
        $res = WPCW_Workflow::transition($post_id, $target, $note);
        if (is_wp_error($res)) return $res;
        return rest_ensure_response(WPCW_Workflow::get_full($post_id));
    }

    public function handle_workflow_comment($request) {
        $body    = json_decode($request->get_body(), true);
        $post_id = isset($body['post_id']) ? (int) $body['post_id'] : 0;
        $note    = isset($body['body'])    ? sanitize_textarea_field($body['body']) : '';
        if (!$post_id) return new WP_Error('bad_request', 'post_id required.', array('status' => 400));
        $res = WPCW_Workflow::add_comment($post_id, $note);
        if (is_wp_error($res)) return $res;
        return rest_ensure_response(WPCW_Workflow::get_full($post_id));
    }

    public function handle_workflow_assign($request) {
        $body        = json_decode($request->get_body(), true);
        $post_id     = isset($body['post_id'])     ? (int) $body['post_id']     : 0;
        $reviewer_id = isset($body['reviewer_id']) ? (int) $body['reviewer_id'] : 0;
        if (!$post_id) return new WP_Error('bad_request', 'post_id required.', array('status' => 400));
        $res = WPCW_Workflow::assign_reviewer($post_id, $reviewer_id);
        if (is_wp_error($res)) return $res;
        return rest_ensure_response(WPCW_Workflow::get_full($post_id));
    }

    // =====================================================================
    // PHASE 2 — Activity Log
    // =====================================================================

    public function handle_activity_list($request) {
        $args = array(
            'user_id'     => (int) $request->get_param('user_id'),
            'action'      => sanitize_key((string) $request->get_param('action')),
            'object_type' => sanitize_key((string) $request->get_param('object_type')),
            'object_id'   => (int) $request->get_param('object_id'),
            'severity'    => sanitize_key((string) $request->get_param('severity')),
            'search'      => sanitize_text_field((string) $request->get_param('q')),
            'date_from'   => sanitize_text_field((string) $request->get_param('date_from')),
            'date_to'     => sanitize_text_field((string) $request->get_param('date_to')),
            'page'        => max(1, (int) $request->get_param('page')),
            'per_page'    => min(200, max(1, (int) ($request->get_param('per_page') ?: 50))),
        );
        $data = WPCW_Activity_Log::query($args);
        $data['actions'] = WPCW_Activity_Log::distinct_actions();
        return rest_ensure_response($data);
    }

    public function handle_activity_export($request) {
        $args = array(
            'user_id'     => (int) $request->get_param('user_id'),
            'action'      => sanitize_key((string) $request->get_param('action')),
            'object_type' => sanitize_key((string) $request->get_param('object_type')),
            'severity'    => sanitize_key((string) $request->get_param('severity')),
            'date_from'   => sanitize_text_field((string) $request->get_param('date_from')),
            'date_to'     => sanitize_text_field((string) $request->get_param('date_to')),
        );
        $csv = WPCW_Activity_Log::export_csv($args);
        nocache_headers();
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="wpcw-activity-' . gmdate('Ymd-His') . '.csv"');
        echo $csv;
        exit;
    }

    // =====================================================================
    // PHASE 2 — Brand Voice
    // =====================================================================

    public function handle_brand_list() {
        return rest_ensure_response(array(
            'voices' => array_values(WPCW_Brand_Voice::get_all()),
            'active' => WPCW_Brand_Voice::active_id(),
            'limit'  => WPCW_Brand_Voice::MAX_VOICES,
        ));
    }

    public function handle_brand_save($request) {
        $body = json_decode($request->get_body(), true);
        $id   = isset($body['id']) ? sanitize_key($body['id']) : '';
        $res  = WPCW_Brand_Voice::save($id, is_array($body) ? $body : array());
        if (is_wp_error($res)) return $res;
        return rest_ensure_response($res);
    }

    public function handle_brand_delete($request) {
        $id  = sanitize_key($request->get_param('id'));
        $res = WPCW_Brand_Voice::delete($id);
        if (is_wp_error($res)) return $res;
        return rest_ensure_response(array('success' => true));
    }

    public function handle_brand_set_active($request) {
        $body = json_decode($request->get_body(), true);
        $id   = isset($body['id']) ? sanitize_key($body['id']) : '';
        $res  = WPCW_Brand_Voice::set_active($id);
        if (is_wp_error($res)) return $res;
        return rest_ensure_response(array('success' => true, 'active' => WPCW_Brand_Voice::active_id()));
    }

    public function handle_brand_analyze($request) {
        $body   = json_decode($request->get_body(), true);
        $sample = isset($body['sample']) ? (string) $body['sample'] : '';
        if ('' === trim($sample)) return new WP_Error('empty', 'Sample text is required.', array('status' => 400));
        $prompt = WPCW_Brand_Voice::analysis_prompt($sample);
        $result = $this->provider_chat($prompt, array('temperature' => 0.4, 'max_tokens' => 800));
        if (is_wp_error($result)) return $result;
        return rest_ensure_response(array('guide' => isset($result['content']) ? $result['content'] : ''));
    }

    // =====================================================================
    // PHASE 2 — Calendar
    // =====================================================================

    public function handle_calendar_get($request) {
        $start = sanitize_text_field((string) $request->get_param('start'));
        $end   = sanitize_text_field((string) $request->get_param('end'));
        if (!$start) $start = gmdate('Y-m-01');
        if (!$end)   $end   = gmdate('Y-m-t', strtotime($start));
        $author = (int) $request->get_param('author');
        $data = WPCW_Calendar::get_range($start, $end, array('author' => $author));
        return rest_ensure_response($data);
    }

    public function handle_calendar_move($request) {
        $body    = json_decode($request->get_body(), true);
        $post_id = isset($body['post_id']) ? (int) $body['post_id'] : 0;
        $date    = isset($body['date'])    ? sanitize_text_field($body['date']) : '';
        $res = WPCW_Calendar::reschedule($post_id, $date);
        if (is_wp_error($res)) return $res;
        return rest_ensure_response($res);
    }

    public function handle_calendar_quick_create($request) {
        $body = json_decode($request->get_body(), true);
        $res  = WPCW_Calendar::quick_create(is_array($body) ? $body : array());
        if (is_wp_error($res)) return $res;
        return rest_ensure_response($res);
    }

    // =====================================================================
    // PHASE 2 — Bulk Generation
    // =====================================================================

    public function handle_bulk_list($request) {
        $jobs = WPCW_Bulk_Generation::list_jobs(array(
            'page'     => max(1, (int) $request->get_param('page')),
            'per_page' => min(100, max(1, (int) ($request->get_param('per_page') ?: 30))),
        ));
        return rest_ensure_response(array('jobs' => $jobs));
    }

    public function handle_bulk_create($request) {
        $body  = json_decode($request->get_body(), true);
        $name  = isset($body['name']) ? sanitize_text_field($body['name']) : '';
        $csv   = isset($body['csv'])  ? (string) $body['csv'] : '';
        $rows  = isset($body['rows']) && is_array($body['rows']) ? $body['rows'] : null;
        $opts  = isset($body['options']) && is_array($body['options']) ? $body['options'] : array();

        if (!$rows) {
            $rows = WPCW_Bulk_Generation::parse_csv($csv);
            if (is_wp_error($rows)) return $rows;
        }
        $res = WPCW_Bulk_Generation::create_job($name, $rows, $opts);
        if (is_wp_error($res)) return $res;
        return rest_ensure_response($res);
    }

    public function handle_bulk_get($request) {
        $id   = (int) $request->get_param('id');
        $job  = WPCW_Bulk_Generation::get_job($id);
        if (!$job) return new WP_Error('not_found', 'Job not found.', array('status' => 404));
        $items = WPCW_Bulk_Generation::get_items($id, max(1, (int) $request->get_param('page')), 50);
        return rest_ensure_response(array('job' => $job, 'items' => $items));
    }

    public function handle_bulk_cancel($request) {
        $id  = (int) $request->get_param('id');
        $res = WPCW_Bulk_Generation::cancel_job($id);
        if (is_wp_error($res)) return $res;
        return rest_ensure_response(array('success' => true));
    }

    public function handle_bulk_delete($request) {
        $id  = (int) $request->get_param('id');
        WPCW_Bulk_Generation::delete_job($id);
        return rest_ensure_response(array('success' => true));
    }

    public function handle_bulk_run_now() {
        WPCW_Bulk_Generation::process_tick();
        return rest_ensure_response(array('success' => true));
    }

    public function handle_bulk_template_csv() {
        nocache_headers();
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="wpcw-bulk-template.csv"');
        echo WPCW_Bulk_Generation::template_csv();
        exit;
    }
}
