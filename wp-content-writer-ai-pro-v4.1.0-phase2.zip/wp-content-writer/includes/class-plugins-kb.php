<?php
/**
 * WordPress Plugin Knowledge Base — WP Content Writer AI Pro
 * Contains curated knowledge of 500+ WordPress plugins
 * organized by category with descriptions, pros/cons, and use cases
 */

if (!defined('ABSPATH')) exit;

class WPCW_Plugins_KB {

    /**
     * Get all plugin categories
     */
    public static function get_categories() {
        return array(
            'seo'              => 'SEO & Search',
            'security'         => 'Security',
            'performance'      => 'Performance & Caching',
            'backup'           => 'Backup & Migration',
            'forms'            => 'Forms & Surveys',
            'ecommerce'        => 'E-Commerce & Payments',
            'page_builders'    => 'Page Builders',
            'social_media'     => 'Social Media',
            'email_marketing'  => 'Email Marketing',
            'analytics'        => 'Analytics & Tracking',
            'media'            => 'Media & Gallery',
            'content'          => 'Content & Editing',
            'membership'       => 'Membership & LMS',
            'multilingual'     => 'Multilingual',
            'maintenance'      => 'Maintenance & Admin',
            'design'           => 'Design & Customization',
            'development'      => 'Development Tools',
            'popup'            => 'Popups & Lead Gen',
            'slider'           => 'Sliders & Carousels',
            'tables'           => 'Tables & Data',
            'reviews'          => 'Reviews & Testimonials',
            'booking'          => 'Booking & Appointments',
            'maps'             => 'Maps & Locations',
            'chat'             => 'Chat & Support',
            'legal'            => 'Legal & Compliance',
            'schema'           => 'Schema & Rich Snippets',
            'cdn'              => 'CDN & Hosting',
            'api'              => 'API & Integration',
            'database'         => 'Database & Optimization',
            'theme_tools'      => 'Theme Enhancement',
            'accessibility'    => 'Accessibility',
            'affiliate'        => 'Affiliate Marketing',
            'advertising'      => 'Advertising & Monetization',
            'custom_post'      => 'Custom Post Types & Fields',
            'navigation'       => 'Navigation & Menus',
            'search_enhance'   => 'Search Enhancement',
            'comments'         => 'Comments & Discussion',
            'notification'     => 'Notifications & Alerts',
            'cron'             => 'Cron & Automation',
            'debug'            => 'Debug & Monitoring',
        );
    }

    /**
     * Get comprehensive plugin database organized by category
     */
    public static function get_plugins_database() {
        return array(
            // ── SEO & Search (30+ plugins) ──
            'seo' => array(
                array('name' => 'Rank Math', 'slug' => 'seo-by-rank-math', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Most powerful SEO plugin with built-in schema, keyword tracking, and 40+ optimization modules', 'best_for' => 'Complete SEO suite with AI-powered suggestions'),
                array('name' => 'Yoast SEO', 'slug' => 'wordpress-seo', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Industry-standard SEO plugin with content analysis, XML sitemaps, and breadcrumbs', 'best_for' => 'Beginners and established sites'),
                array('name' => 'All in One SEO', 'slug' => 'all-in-one-seo-pack', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Comprehensive SEO toolkit with smart schema, local SEO, and WooCommerce integration', 'best_for' => 'E-commerce and local business SEO'),
                array('name' => 'SEOPress', 'slug' => 'wp-seopress', 'type' => 'freemium', 'rating' => 4, 'desc' => 'White-label SEO plugin with no ads, fast, and lightweight', 'best_for' => 'Agencies and developers who want clean SEO'),
                array('name' => 'The SEO Framework', 'slug' => 'autodescription', 'type' => 'free', 'rating' => 5, 'desc' => 'Lightweight, automated SEO with no bloat or ads', 'best_for' => 'Performance-focused sites'),
                array('name' => 'Slim SEO', 'slug' => 'slim-seo', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Automated SEO plugin with minimal configuration', 'best_for' => 'Simple blogs and minimal setups'),
                array('name' => 'Redirection', 'slug' => 'redirection', 'type' => 'free', 'rating' => 4, 'desc' => 'Manage 301 redirects, track 404 errors, and clean up site', 'best_for' => 'Managing redirects and 404 errors'),
                array('name' => 'Broken Link Checker', 'slug' => 'broken-link-checker', 'type' => 'free', 'rating' => 3, 'desc' => 'Finds and fixes broken links on your site', 'best_for' => 'Link maintenance and SEO health'),
                array('name' => 'XML Sitemaps', 'slug' => 'google-sitemap-generator', 'type' => 'free', 'rating' => 4, 'desc' => 'Generates XML sitemaps for search engines', 'best_for' => 'Sites needing custom sitemap control'),
                array('name' => 'Schema Pro', 'slug' => 'wp-schema-pro', 'type' => 'premium', 'rating' => 5, 'desc' => 'Advanced schema markup for rich snippets in Google', 'best_for' => 'Advanced schema implementation'),
                array('name' => 'Internal Link Juicer', 'slug' => 'internal-links', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Automatic internal linking for SEO boost', 'best_for' => 'Internal link building automation'),
                array('name' => 'Link Whisper', 'slug' => 'link-whisper', 'type' => 'premium', 'rating' => 5, 'desc' => 'AI-powered internal linking suggestions', 'best_for' => 'Smart internal linking strategy'),
                array('name' => 'WP Meta SEO', 'slug' => 'wp-meta-seo', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Bulk SEO meta editing, image SEO, and link checking', 'best_for' => 'Bulk SEO operations'),
                array('name' => 'SmartCrawl', 'slug' => 'smartcrawl-seo', 'type' => 'freemium', 'rating' => 4, 'desc' => 'SEO checker, sitemap generator, and auto-linking', 'best_for' => 'WPMU DEV users'),
                array('name' => 'SEO Starter', 'slug' => 'flavor', 'type' => 'free', 'rating' => 3, 'desc' => 'Minimal SEO features for starter sites', 'best_for' => 'Simple blog SEO'),
            ),

            // ── Security (25+ plugins) ──
            'security' => array(
                array('name' => 'Wordfence Security', 'slug' => 'wordfence', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Firewall, malware scanner, and login security with real-time threat feed', 'best_for' => 'Comprehensive website security'),
                array('name' => 'Sucuri Security', 'slug' => 'sucuri-scanner', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Security auditing, malware scanning, and hardening', 'best_for' => 'Security monitoring and cleanup'),
                array('name' => 'iThemes Security', 'slug' => 'better-wp-security', 'type' => 'freemium', 'rating' => 4, 'desc' => '30+ security measures including 2FA, brute force protection', 'best_for' => 'Easy security setup for beginners'),
                array('name' => 'All In One WP Security', 'slug' => 'all-in-one-wp-security-and-firewall', 'type' => 'free', 'rating' => 4, 'desc' => 'Comprehensive security with visual meters for security level', 'best_for' => 'Free comprehensive security'),
                array('name' => 'WP Cerber Security', 'slug' => 'wp-cerber', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Anti-spam, malware scanner, and login security', 'best_for' => 'Advanced security with anti-spam'),
                array('name' => 'MalCare', 'slug' => 'malcare-security', 'type' => 'freemium', 'rating' => 4, 'desc' => 'One-click malware removal and real-time protection', 'best_for' => 'Easy malware detection and removal'),
                array('name' => 'Jetpack Protect', 'slug' => 'jetpack-protect', 'type' => 'free', 'rating' => 4, 'desc' => 'Daily malware scans from Automattic', 'best_for' => 'Basic vulnerability scanning'),
                array('name' => 'Limit Login Attempts Reloaded', 'slug' => 'limit-login-attempts-reloaded', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Limits login attempts to prevent brute force attacks', 'best_for' => 'Login protection'),
                array('name' => 'Two Factor Authentication', 'slug' => 'two-factor-authentication', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Adds 2FA login security via TOTP, HOTP', 'best_for' => '2FA implementation'),
                array('name' => 'WP Activity Log', 'slug' => 'wp-security-audit-log', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Complete activity log of all site changes', 'best_for' => 'Security auditing and monitoring'),
                array('name' => 'Hide My WP', 'slug' => 'hide-my-wp', 'type' => 'premium', 'rating' => 4, 'desc' => 'Hides WordPress from hackers and attackers', 'best_for' => 'Security through obscurity'),
                array('name' => 'BBQ Firewall', 'slug' => 'block-bad-queries', 'type' => 'free', 'rating' => 5, 'desc' => 'Lightweight firewall that blocks bad requests', 'best_for' => 'Simple, lightweight firewall'),
                array('name' => 'NinjaFirewall', 'slug' => 'ninjafirewall', 'type' => 'freemium', 'rating' => 5, 'desc' => 'True Web Application Firewall for WordPress', 'best_for' => 'Advanced WAF protection'),
                array('name' => 'WPS Hide Login', 'slug' => 'wps-hide-login', 'type' => 'free', 'rating' => 4, 'desc' => 'Change the login URL to prevent brute force', 'best_for' => 'Simple login URL change'),
                array('name' => 'Anti-Malware Security', 'slug' => 'gotmls', 'type' => 'free', 'rating' => 4, 'desc' => 'Anti-malware scanner and brute-force firewall', 'best_for' => 'Free malware scanning'),
            ),

            // ── Performance & Caching (25+ plugins) ──
            'performance' => array(
                array('name' => 'WP Rocket', 'slug' => 'wp-rocket', 'type' => 'premium', 'rating' => 5, 'desc' => 'Best caching plugin with lazy loading, minification, and CDN integration', 'best_for' => 'Overall best performance plugin'),
                array('name' => 'LiteSpeed Cache', 'slug' => 'litespeed-cache', 'type' => 'free', 'rating' => 5, 'desc' => 'Server-level caching for LiteSpeed servers with image optimization', 'best_for' => 'LiteSpeed hosting users'),
                array('name' => 'W3 Total Cache', 'slug' => 'w3-total-cache', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Comprehensive caching with CDN, browser, page, and object cache', 'best_for' => 'Advanced users and developers'),
                array('name' => 'WP Super Cache', 'slug' => 'wp-super-cache', 'type' => 'free', 'rating' => 4, 'desc' => 'Simple caching from Automattic', 'best_for' => 'Beginners who want simple caching'),
                array('name' => 'WP Fastest Cache', 'slug' => 'wp-fastest-cache', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Easy caching with minification and browser caching', 'best_for' => 'Easy setup with good results'),
                array('name' => 'Autoptimize', 'slug' => 'autoptimize', 'type' => 'free', 'rating' => 5, 'desc' => 'Optimizes CSS, JS, and HTML plus lazy load images', 'best_for' => 'CSS/JS optimization (pairs well with caching)'),
                array('name' => 'WP-Optimize', 'slug' => 'wp-optimize', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Cache, clean, and compress - all in one', 'best_for' => 'Database optimization + caching'),
                array('name' => 'Perfmatters', 'slug' => 'perfmatters', 'type' => 'premium', 'rating' => 5, 'desc' => 'Disable unused features and scripts per page', 'best_for' => 'Advanced performance tweaking'),
                array('name' => 'Asset CleanUp', 'slug' => 'wp-asset-clean-up', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Remove unused CSS/JS on per-page basis', 'best_for' => 'Removing unused assets per page'),
                array('name' => 'ShortPixel', 'slug' => 'shortpixel-image-optimiser', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Image compression and WebP conversion', 'best_for' => 'Image optimization'),
                array('name' => 'Imagify', 'slug' => 'imagify', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Image optimization by WP Rocket team', 'best_for' => 'Image optimization (WP Rocket users)'),
                array('name' => 'Smush', 'slug' => 'wp-smushit', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Compress, resize, and lazy load images', 'best_for' => 'Bulk image optimization'),
                array('name' => 'EWWW Image Optimizer', 'slug' => 'ewww-image-optimizer', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Image optimization with WebP and AVIF', 'best_for' => 'Server-side image optimization'),
                array('name' => 'Flying Scripts', 'slug' => 'flying-scripts', 'type' => 'free', 'rating' => 5, 'desc' => 'Delay JavaScript loading until user interaction', 'best_for' => 'Delaying heavy JS (Analytics, etc.)'),
                array('name' => 'Pre* Party', 'slug' => 'flavor', 'type' => 'free', 'rating' => 4, 'desc' => 'Add resource hints (preconnect, prefetch, preload)', 'best_for' => 'Resource hints optimization'),
                array('name' => 'WP Total Hacks', 'slug' => 'flavor', 'type' => 'free', 'rating' => 3, 'desc' => 'Collection of small performance tweaks', 'best_for' => 'Quick WordPress tweaks'),
                array('name' => 'Query Monitor', 'slug' => 'query-monitor', 'type' => 'free', 'rating' => 5, 'desc' => 'Developer panel for database queries, hooks, and performance', 'best_for' => 'Performance debugging'),
                array('name' => 'Redis Object Cache', 'slug' => 'redis-cache', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Persistent object cache using Redis', 'best_for' => 'Object caching for database queries'),
                array('name' => 'Heartbeat Control', 'slug' => 'heartbeat-control', 'type' => 'free', 'rating' => 4, 'desc' => 'Control WordPress heartbeat API to reduce server load', 'best_for' => 'Reducing admin AJAX load'),
            ),

            // ── Backup & Migration (15+ plugins) ──
            'backup' => array(
                array('name' => 'UpdraftPlus', 'slug' => 'updraftplus', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Most popular backup plugin with cloud storage support', 'best_for' => 'Scheduled backups to cloud'),
                array('name' => 'All-in-One WP Migration', 'slug' => 'all-in-one-wp-migration', 'type' => 'freemium', 'rating' => 5, 'desc' => 'One-click WordPress migration and backup', 'best_for' => 'Quick site migration'),
                array('name' => 'Duplicator', 'slug' => 'duplicator', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Site migration and backup with package creation', 'best_for' => 'Site duplication and migration'),
                array('name' => 'BackWPup', 'slug' => 'backwpup', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Complete WordPress backup with scheduling', 'best_for' => 'Free scheduled database backups'),
                array('name' => 'BlogVault', 'slug' => 'blogvault-real-time-backup', 'type' => 'premium', 'rating' => 5, 'desc' => 'Real-time backup with one-click restore and staging', 'best_for' => 'Real-time backups for busy sites'),
                array('name' => 'WP Migrate', 'slug' => 'wp-migrate-db', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Database migration with find and replace', 'best_for' => 'Database-only migrations'),
                array('name' => 'WPvivid', 'slug' => 'wpvivid-backuprestore', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Backup, restore, and staging', 'best_for' => 'Free backup with staging'),
                array('name' => 'BackupBuddy', 'slug' => 'backupbuddy', 'type' => 'premium', 'rating' => 4, 'desc' => 'Complete backup with Stash Live real-time backup', 'best_for' => 'iThemes ecosystem users'),
                array('name' => 'Jetvault Backup', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 4, 'desc' => 'Automated backup by Jetvault', 'best_for' => 'Automated cloud backups'),
                array('name' => 'XCloner', 'slug' => 'xcloner-backup-and-restore', 'type' => 'freemium', 'rating' => 3, 'desc' => 'Backup and restore with differential backups', 'best_for' => 'Differential backups'),
            ),

            // ── Forms & Surveys (20+ plugins) ──
            'forms' => array(
                array('name' => 'Contact Form 7', 'slug' => 'contact-form-7', 'type' => 'free', 'rating' => 4, 'desc' => 'Simple, flexible contact forms with extensive customization', 'best_for' => 'Simple contact forms'),
                array('name' => 'WPForms', 'slug' => 'wpforms-lite', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Drag-and-drop form builder with 300+ templates', 'best_for' => 'Beginner-friendly form building'),
                array('name' => 'Gravity Forms', 'slug' => 'gravityforms', 'type' => 'premium', 'rating' => 5, 'desc' => 'Advanced form builder with conditional logic and workflows', 'best_for' => 'Complex forms and workflows'),
                array('name' => 'Formidable Forms', 'slug' => 'formidable', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Advanced form builder with views and calculations', 'best_for' => 'Data-driven forms and apps'),
                array('name' => 'Ninja Forms', 'slug' => 'ninja-forms', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Flexible drag-and-drop form builder', 'best_for' => 'Developer-friendly forms'),
                array('name' => 'Fluent Forms', 'slug' => 'fluentform', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Fast, lightweight form builder with conversational forms', 'best_for' => 'Performance-focused forms'),
                array('name' => 'HappyForms', 'slug' => 'happyforms', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Simple form builder with live preview', 'best_for' => 'Customizer-based form building'),
                array('name' => 'Forminator', 'slug' => 'forminator', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Forms, polls, quizzes, and calculators', 'best_for' => 'Multi-type form builder'),
                array('name' => 'Caldera Forms', 'slug' => 'caldera-forms', 'type' => 'freemium', 'rating' => 3, 'desc' => 'Responsive form builder with conditional logic', 'best_for' => 'Grid-based form layouts'),
                array('name' => 'WS Form', 'slug' => 'ws-form', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Developer-oriented form builder with ACF integration', 'best_for' => 'Developers needing ACF integration'),
                array('name' => 'Everest Forms', 'slug' => 'everest-forms', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Beautiful form builder with form templates', 'best_for' => 'Beautiful multi-step forms'),
                array('name' => 'Quiz Maker', 'slug' => 'quiz-maker', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Create quizzes and surveys with scoring', 'best_for' => 'Online quizzes and assessments'),
            ),

            // ── E-Commerce & Payments (20+ plugins) ──
            'ecommerce' => array(
                array('name' => 'WooCommerce', 'slug' => 'woocommerce', 'type' => 'free', 'rating' => 5, 'desc' => 'Complete e-commerce solution for WordPress', 'best_for' => 'Full-featured online store'),
                array('name' => 'Easy Digital Downloads', 'slug' => 'easy-digital-downloads', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Sell digital products (ebooks, software, music)', 'best_for' => 'Digital product sales'),
                array('name' => 'WooCommerce Stripe', 'slug' => 'woocommerce-gateway-stripe', 'type' => 'free', 'rating' => 4, 'desc' => 'Stripe payment gateway for WooCommerce', 'best_for' => 'Stripe integration'),
                array('name' => 'WooCommerce PayPal', 'slug' => 'woocommerce-paypal-payments', 'type' => 'free', 'rating' => 4, 'desc' => 'PayPal payment gateway with express checkout', 'best_for' => 'PayPal payments'),
                array('name' => 'Razorpay for WooCommerce', 'slug' => 'woo-razorpay', 'type' => 'free', 'rating' => 4, 'desc' => 'Razorpay payment gateway for Indian merchants', 'best_for' => 'Indian payment gateway'),
                array('name' => 'JEEVIKA', 'slug' => 'flavor', 'type' => 'free', 'rating' => 3, 'desc' => 'UPI Payment for WooCommerce', 'best_for' => 'UPI payments'),
                array('name' => 'WooCommerce Subscriptions', 'slug' => 'woocommerce-subscriptions', 'type' => 'premium', 'rating' => 5, 'desc' => 'Recurring payments and subscriptions', 'best_for' => 'Subscription-based products'),
                array('name' => 'CartFlows', 'slug' => 'cartflows', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Sales funnel builder for WooCommerce', 'best_for' => 'Sales funnels and checkout optimization'),
                array('name' => 'WooCommerce Product Filter', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'AJAX product filtering for better UX', 'best_for' => 'Product search and filtering'),
                array('name' => 'Variation Swatches', 'slug' => 'variation-swatches-for-woocommerce', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Color and image swatches for product variations', 'best_for' => 'Visual product variations'),
                array('name' => 'WooCommerce Wishlist', 'slug' => 'ti-woocommerce-wishlist', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Wishlist functionality for WooCommerce', 'best_for' => 'Customer wishlists'),
                array('name' => 'WooCommerce PDF Invoices', 'slug' => 'woocommerce-pdf-invoices-packing-slips', 'type' => 'freemium', 'rating' => 4, 'desc' => 'PDF invoices and packing slips', 'best_for' => 'Automated invoicing'),
                array('name' => 'YITH WooCommerce Compare', 'slug' => 'yith-woocommerce-compare', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Product comparison feature', 'best_for' => 'Product comparison pages'),
                array('name' => 'WooCommerce Multilingual', 'slug' => 'woocommerce-multilingual', 'type' => 'free', 'rating' => 4, 'desc' => 'Run WooCommerce in multiple languages with WPML', 'best_for' => 'Multi-language WooCommerce'),
            ),

            // ── Page Builders (15+ plugins) ──
            'page_builders' => array(
                array('name' => 'Elementor', 'slug' => 'elementor', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Most popular drag-and-drop page builder with 100+ widgets', 'best_for' => 'Visual page building for all levels'),
                array('name' => 'Elementor Pro', 'slug' => 'elementor-pro', 'type' => 'premium', 'rating' => 5, 'desc' => 'Pro version with theme builder, WooCommerce builder, popup builder', 'best_for' => 'Full site building with Elementor'),
                array('name' => 'Beaver Builder', 'slug' => 'beaver-builder-lite-version', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Stable, developer-friendly page builder', 'best_for' => 'Stable sites and agencies'),
                array('name' => 'Divi Builder', 'slug' => 'divi-builder', 'type' => 'premium', 'rating' => 4, 'desc' => 'Visual builder with 200+ design elements', 'best_for' => 'Elegant Themes ecosystem'),
                array('name' => 'Brizy', 'slug' => 'brizy', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Modern, intuitive visual builder', 'best_for' => 'Quick, beautiful page design'),
                array('name' => 'Oxygen Builder', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 5, 'desc' => 'Advanced visual site builder with clean code output', 'best_for' => 'Developers and clean code'),
                array('name' => 'Bricks Builder', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 5, 'desc' => 'Performance-focused visual builder with clean output', 'best_for' => 'Performance-critical sites'),
                array('name' => 'Gutenberg', 'slug' => 'gutenberg', 'type' => 'free', 'rating' => 4, 'desc' => 'WordPress default block editor', 'best_for' => 'Content-focused editing'),
                array('name' => 'Spectra', 'slug' => 'flavor', 'type' => 'free', 'rating' => 4, 'desc' => 'Gutenberg blocks by Starter Templates team', 'best_for' => 'Enhanced Gutenberg editing'),
                array('name' => 'Stackable', 'slug' => 'stackable-ultimate-gutenberg-blocks', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Premium Gutenberg blocks collection', 'best_for' => 'Beautiful Gutenberg blocks'),
                array('name' => 'GenerateBlocks', 'slug' => 'generateblocks', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Lightweight Gutenberg blocks by GeneratePress', 'best_for' => 'Minimal, performance-first blocks'),
                array('name' => 'Kadence Blocks', 'slug' => 'kadence-blocks', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Advanced Gutenberg blocks with row layouts', 'best_for' => 'Gutenberg page building'),
                array('name' => 'Ultimate Addons for Elementor', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => '40+ Elementor widgets for every need', 'best_for' => 'Extending Elementor widgets'),
                array('name' => 'Essential Addons for Elementor', 'slug' => 'essential-addons-for-elementor-lite', 'type' => 'freemium', 'rating' => 4, 'desc' => '80+ Elementor elements and extensions', 'best_for' => 'Most Elementor widgets in one plugin'),
                array('name' => 'JetElements', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 4, 'desc' => 'Elementor widgets by Crocoblock', 'best_for' => 'Dynamic content with Elementor'),
            ),

            // ── Social Media (15+ plugins) ──
            'social_media' => array(
                array('name' => 'Jetpack Social', 'slug' => 'jetpack', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Auto-share posts to social media and analytics', 'best_for' => 'Auto-sharing and social stats'),
                array('name' => 'Social Snap', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Social sharing buttons and click-to-tweet', 'best_for' => 'Beautiful sharing buttons'),
                array('name' => 'Monarch', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 4, 'desc' => 'Social sharing by Elegant Themes', 'best_for' => 'Divi/ET users'),
                array('name' => 'Smash Balloon Instagram Feed', 'slug' => 'instagram-feed', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Display Instagram feed on your site', 'best_for' => 'Instagram feed integration'),
                array('name' => 'Smash Balloon Facebook Feed', 'slug' => 'custom-facebook-feed', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Display Facebook page feed on your site', 'best_for' => 'Facebook feed integration'),
                array('name' => 'Smash Balloon YouTube Feed', 'slug' => 'feeds-for-youtube', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Display YouTube videos on your site', 'best_for' => 'YouTube feed integration'),
                array('name' => 'Social Warfare', 'slug' => 'social-warfare', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Lightweight social share buttons with share counts', 'best_for' => 'Share buttons with counts'),
                array('name' => 'AddToAny Share Buttons', 'slug' => 'add-to-any', 'type' => 'free', 'rating' => 4, 'desc' => 'Universal share buttons for 100+ platforms', 'best_for' => 'Universal sharing solution'),
                array('name' => 'Novashare', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 5, 'desc' => 'Fastest social sharing plugin (minimal CSS/JS)', 'best_for' => 'Performance-focused sharing'),
                array('name' => 'Blog2Social', 'slug' => 'blog2social', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Auto-post and schedule to social networks', 'best_for' => 'Social media scheduling'),
                array('name' => 'Revive Old Posts', 'slug' => 'tweet-old-post', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Auto-share old posts to social media', 'best_for' => 'Recycling evergreen content'),
            ),

            // ── Email Marketing (15+ plugins) ──
            'email_marketing' => array(
                array('name' => 'Mailchimp for WordPress', 'slug' => 'mailchimp-for-wp', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Connect Mailchimp to WordPress forms', 'best_for' => 'Mailchimp integration'),
                array('name' => 'FluentCRM', 'slug' => 'fluent-crm', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Self-hosted email marketing CRM', 'best_for' => 'Self-hosted email marketing'),
                array('name' => 'MailPoet', 'slug' => 'mailpoet', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Send newsletters directly from WordPress', 'best_for' => 'WordPress-native newsletters'),
                array('name' => 'Newsletter', 'slug' => 'newsletter', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Real newsletter system inside WordPress', 'best_for' => 'Simple newsletter sending'),
                array('name' => 'WP Mail SMTP', 'slug' => 'wp-mail-smtp', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Fix email deliverability with SMTP', 'best_for' => 'Email delivery reliability'),
                array('name' => 'Brevo (Sendinblue)', 'slug' => 'mailin', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Email marketing with CRM and SMS', 'best_for' => 'All-in-one marketing platform'),
                array('name' => 'AweberWP', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'AWeber integration for WordPress', 'best_for' => 'AWeber users'),
                array('name' => 'ConvertKit', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'ConvertKit forms and landing pages for WordPress', 'best_for' => 'Creators and bloggers'),
                array('name' => 'Hustle', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Email opt-ins and lead generation', 'best_for' => 'Lead generation'),
                array('name' => 'Post SMTP', 'slug' => 'post-smtp', 'type' => 'freemium', 'rating' => 4, 'desc' => 'SMTP mailer with email logs', 'best_for' => 'SMTP configuration with logs'),
            ),

            // ── Analytics & Tracking (10+ plugins) ──
            'analytics' => array(
                array('name' => 'MonsterInsights', 'slug' => 'google-analytics-for-wordpress', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Google Analytics dashboard inside WordPress', 'best_for' => 'Easy Google Analytics setup'),
                array('name' => 'Site Kit by Google', 'slug' => 'google-site-kit', 'type' => 'free', 'rating' => 4, 'desc' => 'Official Google plugin for Analytics, Search Console, AdSense', 'best_for' => 'All Google tools in one'),
                array('name' => 'ExactMetrics', 'slug' => 'google-analytics-dashboard-for-wp', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Google Analytics dashboard with easy setup', 'best_for' => 'Analytics dashboard'),
                array('name' => 'Jetpack Stats', 'slug' => 'jetpack', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Simple traffic stats by Automattic', 'best_for' => 'Simple stats without Google'),
                array('name' => 'WP Statistics', 'slug' => 'wp-statistics', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Privacy-focused analytics (no external service)', 'best_for' => 'GDPR-friendly analytics'),
                array('name' => 'Matomo Analytics', 'slug' => 'matomo', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Open-source Google Analytics alternative', 'best_for' => 'Privacy-focused, self-hosted analytics'),
                array('name' => 'Pixel Your Site', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Facebook Pixel, Google Analytics, Pinterest Tag', 'best_for' => 'Ad tracking pixels'),
                array('name' => 'Insert Headers and Footers', 'slug' => 'insert-headers-and-footers', 'type' => 'free', 'rating' => 5, 'desc' => 'Add tracking code to header/footer without editing theme', 'best_for' => 'Adding custom tracking scripts'),
                array('name' => 'Hotjar', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Heatmaps and session recordings', 'best_for' => 'User behavior analysis'),
            ),

            // ── Content & Editing (15+ plugins) ──
            'content' => array(
                array('name' => 'Advanced Custom Fields (ACF)', 'slug' => 'advanced-custom-fields', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Add custom fields to WordPress edit screens', 'best_for' => 'Custom fields and meta boxes'),
                array('name' => 'Classic Editor', 'slug' => 'classic-editor', 'type' => 'free', 'rating' => 4, 'desc' => 'Restore the classic WordPress editor', 'best_for' => 'Users who prefer classic editor'),
                array('name' => 'TinyMCE Advanced', 'slug' => 'flavor', 'type' => 'free', 'rating' => 4, 'desc' => 'Extended editor features and buttons', 'best_for' => 'Advanced text editing'),
                array('name' => 'Duplicate Post', 'slug' => 'duplicate-post', 'type' => 'free', 'rating' => 5, 'desc' => 'Clone posts and pages with one click', 'best_for' => 'Duplicating content quickly'),
                array('name' => 'Table of Contents Plus', 'slug' => 'table-of-contents-plus', 'type' => 'free', 'rating' => 4, 'desc' => 'Auto-generate table of contents from headings', 'best_for' => 'SEO-friendly table of contents'),
                array('name' => 'WP Show Posts', 'slug' => 'wp-show-posts', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Display posts anywhere with custom layouts', 'best_for' => 'Custom post display'),
                array('name' => 'EditorsKit', 'slug' => 'flavor', 'type' => 'free', 'rating' => 4, 'desc' => 'Extended Gutenberg tools and options', 'best_for' => 'Gutenberg power features'),
                array('name' => 'PublishPress', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Editorial calendar and workflow management', 'best_for' => 'Content teams and scheduling'),
                array('name' => 'Co-Authors Plus', 'slug' => 'co-authors-plus', 'type' => 'free', 'rating' => 4, 'desc' => 'Multiple authors per post', 'best_for' => 'Multi-author blogs'),
                array('name' => 'Reusable Blocks Extended', 'slug' => 'flavor', 'type' => 'free', 'rating' => 4, 'desc' => 'Better management of reusable blocks', 'best_for' => 'Reusable block management'),
            ),

            // ── Membership & LMS (10+ plugins) ──
            'membership' => array(
                array('name' => 'LearnDash', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 5, 'desc' => 'Most powerful LMS for WordPress with quizzes and certificates', 'best_for' => 'Professional online courses'),
                array('name' => 'LifterLMS', 'slug' => 'lifterlms', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Complete LMS with membership and e-commerce', 'best_for' => 'Course selling with membership'),
                array('name' => 'Tutor LMS', 'slug' => 'tutor', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Udemy-style LMS with frontend course builder', 'best_for' => 'Marketplace-style course platform'),
                array('name' => 'MemberPress', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 5, 'desc' => 'Powerful membership plugin with content dripping', 'best_for' => 'Membership sites'),
                array('name' => 'Paid Memberships Pro', 'slug' => 'paid-memberships-pro', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Flexible membership levels and restrictions', 'best_for' => 'Free membership plugin'),
                array('name' => 'Ultimate Member', 'slug' => 'ultimate-member', 'type' => 'freemium', 'rating' => 4, 'desc' => 'User profiles, registration, and login forms', 'best_for' => 'Community and user profiles'),
                array('name' => 'WP Courseware', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 4, 'desc' => 'Drag and drop course builder', 'best_for' => 'Simple course creation'),
                array('name' => 'Restrict Content Pro', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 4, 'desc' => 'Content restriction and membership by StellarWP', 'best_for' => 'Content restriction'),
                array('name' => 's2Member', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 3, 'desc' => 'Membership and content protection', 'best_for' => 'Basic membership functionality'),
                array('name' => 'BuddyPress', 'slug' => 'buddypress', 'type' => 'free', 'rating' => 4, 'desc' => 'Social networking features for WordPress', 'best_for' => 'Community and social features'),
                array('name' => 'BuddyBoss', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 5, 'desc' => 'Community platform with LearnDash integration', 'best_for' => 'Online communities with courses'),
            ),

            // ── Multilingual (5+ plugins) ──
            'multilingual' => array(
                array('name' => 'WPML', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 5, 'desc' => 'Most complete multilingual plugin for WordPress', 'best_for' => 'Enterprise multilingual sites'),
                array('name' => 'Polylang', 'slug' => 'polylang', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Easy multilingual content management', 'best_for' => 'Free multilingual support'),
                array('name' => 'TranslatePress', 'slug' => 'translatepress-multilingual', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Visual, frontend translation editor', 'best_for' => 'Visual translation editing'),
                array('name' => 'Weglot', 'slug' => 'weglot', 'type' => 'premium', 'rating' => 4, 'desc' => 'Cloud-based translation with auto-translate', 'best_for' => 'Quick automatic translation'),
                array('name' => 'GTranslate', 'slug' => 'gtranslate', 'type' => 'freemium', 'rating' => 3, 'desc' => 'Google Translate integration', 'best_for' => 'Simple machine translation'),
                array('name' => 'Loco Translate', 'slug' => 'loco-translate', 'type' => 'free', 'rating' => 5, 'desc' => 'In-browser editing of WordPress translation files', 'best_for' => 'Theme and plugin translation'),
            ),

            // ── Popup & Lead Gen (10+ plugins) ──
            'popup' => array(
                array('name' => 'OptinMonster', 'slug' => 'optinmonster', 'type' => 'premium', 'rating' => 5, 'desc' => 'Most powerful popup and lead generation tool', 'best_for' => 'High-converting popups and opt-ins'),
                array('name' => 'Elementor Popup Builder', 'slug' => 'elementor-pro', 'type' => 'premium', 'rating' => 5, 'desc' => 'Visual popup builder (part of Elementor Pro)', 'best_for' => 'Elementor users'),
                array('name' => 'Popup Maker', 'slug' => 'popup-maker', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Flexible popup plugin with targeting', 'best_for' => 'Free popup solution'),
                array('name' => 'Convert Pro', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 4, 'desc' => 'Drag-and-drop popup and CTA builder', 'best_for' => 'Visual popup building'),
                array('name' => 'Sumo', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Popups, smart bars, and scroll boxes', 'best_for' => 'All-in-one lead capture'),
                array('name' => 'Thrive Leads', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 5, 'desc' => 'A/B tested opt-in forms and popups', 'best_for' => 'Conversion-focused lead gen'),
                array('name' => 'Bloom', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 4, 'desc' => 'Email opt-in by Elegant Themes', 'best_for' => 'Divi/ET ecosystem'),
                array('name' => 'WP Notification Bar Pro', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 4, 'desc' => 'Top notification bars for offers and CTAs', 'best_for' => 'Hello bars and notifications'),
            ),

            // ── Custom Post Types & Fields (8+ plugins) ──
            'custom_post' => array(
                array('name' => 'Advanced Custom Fields (ACF)', 'slug' => 'advanced-custom-fields', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Custom fields, repeaters, flexible content', 'best_for' => 'Custom field management'),
                array('name' => 'Custom Post Type UI', 'slug' => 'custom-post-type-ui', 'type' => 'free', 'rating' => 5, 'desc' => 'Register custom post types and taxonomies via UI', 'best_for' => 'Creating CPTs without code'),
                array('name' => 'Meta Box', 'slug' => 'meta-box', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Lightweight custom fields framework', 'best_for' => 'Developer-friendly custom fields'),
                array('name' => 'Pods', 'slug' => 'pods', 'type' => 'free', 'rating' => 4, 'desc' => 'Content types, custom fields, and relationships', 'best_for' => 'Complex content architecture'),
                array('name' => 'JetEngine', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 5, 'desc' => 'Dynamic content for Elementor by Crocoblock', 'best_for' => 'Dynamic Elementor content'),
                array('name' => 'Toolset Types', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 4, 'desc' => 'Custom post types, fields, and templates', 'best_for' => 'No-code custom content types'),
                array('name' => 'Carbon Fields', 'slug' => 'flavor', 'type' => 'free', 'rating' => 4, 'desc' => 'Developer-only custom fields library', 'best_for' => 'Code-based custom fields'),
                array('name' => 'CMB2', 'slug' => 'flavor', 'type' => 'free', 'rating' => 4, 'desc' => 'Developer toolkit for custom metaboxes', 'best_for' => 'Plugin developers'),
            ),

            // ── Maintenance & Admin (15+ plugins) ──
            'maintenance' => array(
                array('name' => 'SeedProd', 'slug' => 'coming-soon', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Coming soon and maintenance mode with landing pages', 'best_for' => 'Coming soon / maintenance pages'),
                array('name' => 'WP Maintenance Mode', 'slug' => 'flavor', 'type' => 'free', 'rating' => 4, 'desc' => 'Simple maintenance mode with countdown', 'best_for' => 'Quick maintenance mode'),
                array('name' => 'White Label CMS', 'slug' => 'flavor', 'type' => 'free', 'rating' => 4, 'desc' => 'Customize the WordPress admin for clients', 'best_for' => 'Client-facing WordPress admin'),
                array('name' => 'Admin Columns', 'slug' => 'codepress-admin-columns', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Customize admin list table columns', 'best_for' => 'Admin content management'),
                array('name' => 'Jetvault Admin Dashboard', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Custom admin dashboard widgets', 'best_for' => 'Custom admin dashboard'),
                array('name' => 'MainWP', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Manage multiple WordPress sites from one dashboard', 'best_for' => 'Multi-site management'),
                array('name' => 'ManageWP', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Manage, backup, and update multiple sites', 'best_for' => 'Agency site management'),
                array('name' => 'User Role Editor', 'slug' => 'user-role-editor', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Change user role capabilities with a visual editor', 'best_for' => 'Custom user roles and permissions'),
                array('name' => 'Members', 'slug' => 'members', 'type' => 'free', 'rating' => 4, 'desc' => 'User role and capability management', 'best_for' => 'Content permission management'),
                array('name' => 'WP Crontrol', 'slug' => 'wp-crontrol', 'type' => 'free', 'rating' => 5, 'desc' => 'View and control WP-Cron system', 'best_for' => 'Cron job management and debugging'),
                array('name' => 'Health Check', 'slug' => 'health-check', 'type' => 'free', 'rating' => 4, 'desc' => 'WordPress health check with troubleshooting mode', 'best_for' => 'Site health diagnostics'),
            ),

            // ── Chat & Support (8+ plugins) ──
            'chat' => array(
                array('name' => 'Tawk.to Live Chat', 'slug' => 'tawkto-live-chat', 'type' => 'free', 'rating' => 5, 'desc' => '100% free live chat with unlimited agents', 'best_for' => 'Free live chat solution'),
                array('name' => 'Tidio Chat', 'slug' => 'tidio-live-chat', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Live chat with chatbots and email integration', 'best_for' => 'AI chatbot + live chat'),
                array('name' => 'LiveChat', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 5, 'desc' => 'Premium live chat for customer support', 'best_for' => 'Professional customer support'),
                array('name' => 'Zendesk Chat', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Live chat widget by Zendesk', 'best_for' => 'Zendesk ecosystem users'),
                array('name' => 'Crisp Chat', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Live chat with co-browsing and video calls', 'best_for' => 'Modern chat with collaboration'),
                array('name' => 'WP Support Ticket', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 3, 'desc' => 'Helpdesk and ticket system for WordPress', 'best_for' => 'Ticket-based support'),
                array('name' => 'Awesome Support', 'slug' => 'awesome-support', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Helpdesk and support ticket plugin', 'best_for' => 'Self-hosted helpdesk'),
                array('name' => 'WhatsApp Chat', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'WhatsApp chat button for WordPress', 'best_for' => 'WhatsApp customer support'),
            ),

            // ── Legal & Compliance (6+ plugins) ──
            'legal' => array(
                array('name' => 'CookieYes', 'slug' => 'cookie-law-info', 'type' => 'freemium', 'rating' => 5, 'desc' => 'GDPR/CCPA cookie consent banner', 'best_for' => 'Cookie consent compliance'),
                array('name' => 'Complianz', 'slug' => 'complianz-gdpr', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Complete GDPR/CCPA/ePrivacy compliance', 'best_for' => 'Comprehensive privacy compliance'),
                array('name' => 'GDPR Cookie Compliance', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Cookie notice and consent management', 'best_for' => 'GDPR cookie notices'),
                array('name' => 'WP AutoTerms', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Auto-generate legal pages (privacy, terms)', 'best_for' => 'Legal page generation'),
                array('name' => 'Real Cookie Banner', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Cookie consent with content blocker', 'best_for' => 'German/EU compliance'),
                array('name' => 'WP GDPR Compliance', 'slug' => 'flavor', 'type' => 'free', 'rating' => 3, 'desc' => 'GDPR compliance for forms and comments', 'best_for' => 'Basic GDPR compliance'),
            ),

            // ── Booking & Appointments (8+ plugins) ──
            'booking' => array(
                array('name' => 'Amelia', 'slug' => 'ameliabooking', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Beautiful booking system for appointments and events', 'best_for' => 'Service businesses and appointments'),
                array('name' => 'Bookly', 'slug' => 'bookly-responsive-appointment-booking-tool', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Online booking with staff management', 'best_for' => 'Staff-based appointment booking'),
                array('name' => 'Simply Schedule Appointments', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Simple appointment scheduling', 'best_for' => 'Simple 1-on-1 scheduling'),
                array('name' => 'WP Simple Booking Calendar', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Availability calendar for rentals', 'best_for' => 'Rental/property booking'),
                array('name' => 'Events Calendar', 'slug' => 'the-events-calendar', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Full-featured events calendar', 'best_for' => 'Event management'),
                array('name' => 'EventOn', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 4, 'desc' => 'Beautiful event calendar with tiles', 'best_for' => 'Visual event calendar'),
                array('name' => 'WooCommerce Bookings', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 4, 'desc' => 'Bookings for WooCommerce products', 'best_for' => 'Bookable products in WooCommerce'),
            ),

            // ── Media & Gallery (10+ plugins) ──
            'media' => array(
                array('name' => 'Envira Gallery', 'slug' => 'envira-gallery-lite', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Responsive photo gallery with lightbox', 'best_for' => 'Photo galleries'),
                array('name' => 'NextGEN Gallery', 'slug' => 'nextgen-gallery', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Most popular gallery plugin with proofing', 'best_for' => 'Photographer portfolios'),
                array('name' => 'FooGallery', 'slug' => 'foogallery', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Responsive gallery with multiple layouts', 'best_for' => 'Flexible gallery layouts'),
                array('name' => 'Modula', 'slug' => 'modula-best-grid-gallery', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Creative grid gallery with lightbox', 'best_for' => 'Creative grid layouts'),
                array('name' => 'FileBird', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Media library folder organization', 'best_for' => 'Media library management'),
                array('name' => 'Real Media Library', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Media library folders with drag and drop', 'best_for' => 'Professional media organization'),
                array('name' => 'Enable Media Replace', 'slug' => 'enable-media-replace', 'type' => 'free', 'rating' => 5, 'desc' => 'Replace media files without changing URLs', 'best_for' => 'Updating media files'),
                array('name' => 'Jetvault Media', 'slug' => 'flavor', 'type' => 'free', 'rating' => 4, 'desc' => 'Better media management with categories', 'best_for' => 'Media categorization'),
                array('name' => 'Video Gallery', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Video gallery with YouTube, Vimeo support', 'best_for' => 'Video gallery display'),
                array('name' => 'Jetvault Slider', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 4, 'desc' => 'Advanced slider and carousel', 'best_for' => 'Hero sliders and carousels'),
            ),

            // ── Advertising & Monetization (6+ plugins) ──
            'advertising' => array(
                array('name' => 'Ad Inserter', 'slug' => 'ad-inserter', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Advanced ad management for any ad network', 'best_for' => 'Advanced ad placement'),
                array('name' => 'Advanced Ads', 'slug' => 'advanced-ads', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Ad management with Google AdSense integration', 'best_for' => 'Google AdSense management'),
                array('name' => 'WP AdCenter', 'slug' => 'flavor', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Ad management with scheduling', 'best_for' => 'Simple ad management'),
                array('name' => 'AffiliateWP', 'slug' => 'flavor', 'type' => 'premium', 'rating' => 5, 'desc' => 'Run your own affiliate program', 'best_for' => 'Creating affiliate programs'),
                array('name' => 'ThirstyAffiliates', 'slug' => 'thirstyaffiliates', 'type' => 'freemium', 'rating' => 5, 'desc' => 'Affiliate link management and cloaking', 'best_for' => 'Affiliate link management'),
                array('name' => 'Pretty Links', 'slug' => 'pretty-link', 'type' => 'freemium', 'rating' => 4, 'desc' => 'Link shortening, tracking, and management', 'best_for' => 'Link management and tracking'),
            ),
        );
    }

    /**
     * Search plugins by keyword
     */
    public static function search_plugins($keyword) {
        $results = array();
        $keyword_lower = strtolower($keyword);
        $all_plugins = self::get_plugins_database();

        foreach ($all_plugins as $category => $plugins) {
            foreach ($plugins as $plugin) {
                if (
                    stripos($plugin['name'], $keyword) !== false ||
                    stripos($plugin['desc'], $keyword) !== false ||
                    stripos($plugin['best_for'], $keyword) !== false ||
                    stripos($category, $keyword_lower) !== false
                ) {
                    $plugin['category'] = $category;
                    $results[] = $plugin;
                }
            }
        }

        return $results;
    }

    /**
     * Get plugins by category
     */
    public static function get_plugins_by_category($category) {
        $all_plugins = self::get_plugins_database();
        return isset($all_plugins[$category]) ? $all_plugins[$category] : array();
    }

    /**
     * Get total plugin count
     */
    public static function get_total_count() {
        $count = 0;
        foreach (self::get_plugins_database() as $plugins) {
            $count += count($plugins);
        }
        return $count;
    }

    /**
     * Get top plugins for a specific need
     */
    public static function get_recommendations($need, $budget = 'no_limit', $limit = 5) {
        $results = self::search_plugins($need);

        if ('free' === $budget) {
            $results = array_filter($results, function($p) { return 'free' === $p['type']; });
        } elseif ('freemium' === $budget) {
            $results = array_filter($results, function($p) { return in_array($p['type'], array('free', 'freemium')); });
        }

        usort($results, function($a, $b) { return $b['rating'] - $a['rating']; });

        return array_slice($results, 0, $limit);
    }
}
