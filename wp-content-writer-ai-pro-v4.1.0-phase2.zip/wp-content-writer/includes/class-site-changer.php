<?php
/**
 * Site-Wide Changes Engine — WP Content Writer AI Pro
 * Apply bulk changes across the entire WordPress site:
 * find/replace content, bulk SEO updates, global CSS, heading changes,
 * image alt text, menu edits, widget updates, and AI-powered rewrites
 */

if (!defined('ABSPATH')) exit;

class WPCW_Site_Changer {

    /**
     * Find & Replace across all posts/pages
     */
    public static function find_replace($search, $replace, $options = array()) {
        if ('' === $search) {
            return new WP_Error('empty_search', 'Search text cannot be empty.');
        }

        $post_types  = isset($options['post_types']) && is_array($options['post_types'])
            ? $options['post_types']
            : array('post', 'page');
        $post_status = isset($options['post_status']) && is_array($options['post_status'])
            ? $options['post_status']
            : array('publish', 'draft', 'pending');
        $fields      = isset($options['fields']) && is_array($options['fields'])
            ? $options['fields']
            : array('title', 'content', 'excerpt');
        $case_sensitive = !empty($options['case_sensitive']);
        $dry_run        = !empty($options['dry_run']);

        $posts = get_posts(array(
            'post_type'      => $post_types,
            'post_status'    => $post_status,
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ));

        $changed = array();
        $total_replacements = 0;

        foreach ($posts as $post_id) {
            $post  = get_post($post_id);
            $mods  = array();
            $count = 0;

            foreach ($fields as $field) {
                $col = 'title' === $field ? 'post_title' : ('content' === $field ? 'post_content' : 'post_excerpt');
                $original = $post->$col;
                if ($case_sensitive) {
                    $new_val = str_replace($search, $replace, $original, $c);
                } else {
                    $new_val = str_ireplace($search, $replace, $original, $c);
                }
                if ($c > 0) {
                    $mods[$col] = $new_val;
                    $count += $c;
                }
            }

            if (!empty($mods) && !$dry_run) {
                $mods['ID'] = $post_id;
                wp_update_post($mods);
            }

            if ($count > 0) {
                $changed[] = array(
                    'id'           => $post_id,
                    'title'        => $post->post_title,
                    'type'         => $post->post_type,
                    'replacements' => $count,
                    'url'          => get_permalink($post_id),
                );
                $total_replacements += $count;
            }
        }

        return array(
            'success'            => true,
            'dry_run'            => $dry_run,
            'search'             => $search,
            'replace'            => $replace,
            'total_posts_scanned'=> count($posts),
            'posts_changed'      => count($changed),
            'total_replacements' => $total_replacements,
            'changed'            => $changed,
        );
    }

    /**
     * Bulk update SEO meta for all posts missing it
     */
    public static function bulk_update_seo($options = array()) {
        $seo_plugin = WPCW_SEO::get_active_seo_plugin();
        if ('none' === $seo_plugin) {
            return new WP_Error('no_seo', 'No SEO plugin (Rank Math/Yoast) detected.');
        }

        $post_types  = isset($options['post_types']) ? $options['post_types'] : array('post', 'page');
        $only_empty  = isset($options['only_empty']) ? (bool) $options['only_empty'] : true;
        $dry_run     = !empty($options['dry_run']);

        $posts = get_posts(array(
            'post_type'      => $post_types,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
        ));

        $updated = array();

        foreach ($posts as $post) {
            $needs_update = false;
            $current_keyword = '';

            if ('rankmath' === $seo_plugin) {
                $current_keyword = get_post_meta($post->ID, 'rank_math_focus_keyword', true);
                $current_desc    = get_post_meta($post->ID, 'rank_math_description', true);
            } elseif ('yoast' === $seo_plugin) {
                $current_keyword = get_post_meta($post->ID, '_yoast_wpseo_focuskw', true);
                $current_desc    = get_post_meta($post->ID, '_yoast_wpseo_metadesc', true);
            }

            if ($only_empty && !empty($current_keyword)) continue;

            // Auto-generate SEO meta from content
            $title   = $post->post_title;
            $content = strip_tags($post->post_content);

            // Extract likely keyword from title
            $keyword = self::extract_keyword($title);

            // Generate meta description from content
            $description = wp_trim_words($content, 25, '...');
            if (strlen($description) > 160) {
                $description = substr($description, 0, 157) . '...';
            }

            $meta = array(
                'focus_keyword'   => $keyword,
                'seo_title'       => substr($title, 0, 60),
                'seo_description' => $description,
            );

            if (!$dry_run) {
                WPCW_SEO::set_seo_meta($post->ID, $meta);
            }

            $updated[] = array(
                'id'       => $post->ID,
                'title'    => $title,
                'keyword'  => $keyword,
                'desc'     => $description,
                'url'      => get_permalink($post->ID),
            );
        }

        return array(
            'success'       => true,
            'dry_run'       => $dry_run,
            'seo_plugin'    => $seo_plugin,
            'total_scanned' => count($posts),
            'total_updated' => count($updated),
            'updated'       => $updated,
        );
    }

    /**
     * Add/Update global custom CSS
     */
    public static function update_custom_css($css, $mode = 'append') {
        $current = wp_get_custom_css();

        if ('replace' === $mode) {
            $new_css = $css;
        } elseif ('prepend' === $mode) {
            $new_css = $css . "\n\n" . $current;
        } else {
            $new_css = $current . "\n\n/* === AI Writer Pro Added CSS === */\n" . $css;
        }

        $post_id = wp_get_custom_css_post() ? wp_get_custom_css_post()->ID : 0;

        if ($post_id) {
            wp_update_post(array(
                'ID'           => $post_id,
                'post_content' => $new_css,
            ));
        } else {
            wp_update_custom_css_post($new_css);
        }

        return array(
            'success'    => true,
            'mode'       => $mode,
            'css_length' => strlen($new_css),
            'preview'    => substr($new_css, -200),
        );
    }

    /**
     * Bulk update image alt text for images without alt
     */
    public static function bulk_update_image_alt($options = array()) {
        $dry_run = !empty($options['dry_run']);

        $images = get_posts(array(
            'post_type'      => 'attachment',
            'post_mime_type' => 'image',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ));

        $updated = array();
        foreach ($images as $img_id) {
            $alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);
            if (!empty($alt)) continue;

            $img = get_post($img_id);
            $filename = pathinfo(get_attached_file($img_id), PATHINFO_FILENAME);
            $generated_alt = ucwords(str_replace(array('-', '_'), ' ', $filename));

            if (!$dry_run) {
                update_post_meta($img_id, '_wp_attachment_image_alt', sanitize_text_field($generated_alt));
            }

            $updated[] = array(
                'id'      => $img_id,
                'title'   => $img->post_title,
                'alt'     => $generated_alt,
                'url'     => wp_get_attachment_url($img_id),
            );
        }

        return array(
            'success'        => true,
            'dry_run'        => $dry_run,
            'total_images'   => count($images),
            'without_alt'    => count($updated),
            'updated'        => array_slice($updated, 0, 50),
        );
    }

    /**
     * Bulk change post status
     */
    public static function bulk_change_status($from_status, $to_status, $post_type = 'post', $dry_run = false) {
        $posts = get_posts(array(
            'post_type'      => $post_type,
            'post_status'    => $from_status,
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ));

        if (!$dry_run) {
            foreach ($posts as $pid) {
                wp_update_post(array('ID' => $pid, 'post_status' => $to_status));
            }
        }

        return array(
            'success' => true,
            'dry_run' => $dry_run,
            'from'    => $from_status,
            'to'      => $to_status,
            'count'   => count($posts),
        );
    }

    /**
     * Bulk add/remove category or tag from posts
     */
    public static function bulk_taxonomy($action, $taxonomy, $term_name, $options = array()) {
        $post_type = isset($options['post_type']) ? $options['post_type'] : 'post';
        $dry_run   = !empty($options['dry_run']);

        // Get or create term
        $term = term_exists($term_name, $taxonomy);
        if (!$term && 'add' === $action) {
            $term = wp_insert_term($term_name, $taxonomy);
        }
        if (is_wp_error($term) || !$term) {
            return new WP_Error('term_error', 'Term not found or cannot be created.');
        }
        $term_id = is_array($term) ? (int) $term['term_id'] : (int) $term;

        $posts = get_posts(array(
            'post_type'      => $post_type,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ));

        $affected = 0;
        foreach ($posts as $pid) {
            if ('add' === $action) {
                if (!has_term($term_id, $taxonomy, $pid)) {
                    if (!$dry_run) wp_set_object_terms($pid, $term_id, $taxonomy, true);
                    $affected++;
                }
            } elseif ('remove' === $action) {
                if (has_term($term_id, $taxonomy, $pid)) {
                    if (!$dry_run) wp_remove_object_terms($pid, $term_id, $taxonomy);
                    $affected++;
                }
            }
        }

        return array(
            'success'  => true,
            'dry_run'  => $dry_run,
            'action'   => $action,
            'taxonomy' => $taxonomy,
            'term'     => $term_name,
            'total'    => count($posts),
            'affected' => $affected,
        );
    }

    /**
     * Update site identity (title, tagline, etc.)
     */
    public static function update_site_identity($data) {
        $changed = array();

        if (isset($data['blogname'])) {
            update_option('blogname', sanitize_text_field($data['blogname']));
            $changed[] = 'Site Title';
        }
        if (isset($data['blogdescription'])) {
            update_option('blogdescription', sanitize_text_field($data['blogdescription']));
            $changed[] = 'Tagline';
        }
        if (isset($data['permalink_structure'])) {
            update_option('permalink_structure', sanitize_text_field($data['permalink_structure']));
            flush_rewrite_rules();
            $changed[] = 'Permalink Structure';
        }
        if (isset($data['timezone_string'])) {
            update_option('timezone_string', sanitize_text_field($data['timezone_string']));
            $changed[] = 'Timezone';
        }

        return array(
            'success' => true,
            'changed' => $changed,
        );
    }

    /**
     * Apply AI-suggested changes — processes a structured list of changes
     */
    public static function apply_ai_changes($changes) {
        if (!is_array($changes) || empty($changes)) {
            return new WP_Error('empty', 'No changes to apply.');
        }

        $results = array();

        foreach ($changes as $change) {
            $type = isset($change['type']) ? $change['type'] : '';

            switch ($type) {
                case 'find_replace':
                    $r = self::find_replace(
                        isset($change['search']) ? $change['search'] : '',
                        isset($change['replace']) ? $change['replace'] : '',
                        isset($change['options']) ? $change['options'] : array()
                    );
                    $results[] = array('type' => $type, 'result' => $r);
                    break;

                case 'add_css':
                    $r = self::update_custom_css(
                        isset($change['css']) ? $change['css'] : '',
                        isset($change['mode']) ? $change['mode'] : 'append'
                    );
                    $results[] = array('type' => $type, 'result' => $r);
                    break;

                case 'update_post':
                    $post_id = isset($change['post_id']) ? (int) $change['post_id'] : 0;
                    $data    = isset($change['data']) ? $change['data'] : array();
                    if ($post_id && !empty($data)) {
                        $data['ID'] = $post_id;
                        $r = wp_update_post($data, true);
                        $results[] = array('type' => $type, 'post_id' => $post_id, 'success' => !is_wp_error($r));
                    }
                    break;

                case 'update_seo':
                    $post_id = isset($change['post_id']) ? (int) $change['post_id'] : 0;
                    $meta    = isset($change['meta']) ? $change['meta'] : array();
                    if ($post_id && !empty($meta)) {
                        WPCW_SEO::set_seo_meta($post_id, $meta);
                        $results[] = array('type' => $type, 'post_id' => $post_id, 'success' => true);
                    }
                    break;

                case 'bulk_seo':
                    $r = self::bulk_update_seo(isset($change['options']) ? $change['options'] : array());
                    $results[] = array('type' => $type, 'result' => $r);
                    break;

                case 'image_alt':
                    $r = self::bulk_update_image_alt(isset($change['options']) ? $change['options'] : array());
                    $results[] = array('type' => $type, 'result' => $r);
                    break;

                case 'site_identity':
                    $r = self::update_site_identity(isset($change['data']) ? $change['data'] : array());
                    $results[] = array('type' => $type, 'result' => $r);
                    break;

                default:
                    $results[] = array('type' => $type, 'error' => 'Unknown change type');
            }
        }

        return array(
            'success'       => true,
            'total_changes' => count($changes),
            'results'       => $results,
        );
    }

    // ── Private helpers ──

    private static function extract_keyword($title) {
        $stop_words = array('a','an','the','is','it','in','on','at','to','for','of','and','or','but','with','by','this','that','from','how','what','why','when','where','who','which','best','top','new','your','you','we','our','my','its');
        $words = preg_split('/\s+/', strtolower(trim($title)));
        $words = array_filter($words, function($w) use ($stop_words) {
            return strlen($w) > 2 && !in_array($w, $stop_words);
        });
        $keyword = implode(' ', array_slice(array_values($words), 0, 3));
        return $keyword ?: strtolower($title);
    }
}
