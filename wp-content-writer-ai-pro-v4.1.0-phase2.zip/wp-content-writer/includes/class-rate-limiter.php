<?php
/**
 * Per-user rate limiter — transient-based sliding window.
 *
 * Used to throttle expensive endpoints (streaming generation, AI apply)
 * so a single user cannot exhaust the workspace quota in seconds.
 */

if (!defined('ABSPATH')) exit;

class WPCW_Rate_Limiter {

    const TRANSIENT_PREFIX = 'wpcw_rl_';

    /**
     * Default limits per action. Filterable via the wpcw_rate_limits hook.
     */
    public static function limits() {
        $defaults = array(
            'stream'        => array('max' => 30, 'window' => 60),
            'generate'      => array('max' => 30, 'window' => 60),
            'create_post'   => array('max' => 20, 'window' => 60),
            'ai_apply'      => array('max' => 10, 'window' => 60),
            'image'         => array('max' => 15, 'window' => 60),
            'voice'         => array('max' => 10, 'window' => 60),
            'default'       => array('max' => 60, 'window' => 60),
        );
        $tier = class_exists('WPCW_License') ? WPCW_License::get_tier() : 'free';
        if ('pro' === $tier) {
            foreach ($defaults as &$row) { $row['max'] *= 3; }
        } elseif ('agency' === $tier) {
            foreach ($defaults as &$row) { $row['max'] *= 10; }
        }
        unset($row);
        return apply_filters('wpcw_rate_limits', $defaults, $tier);
    }

    public static function attempt($action, $user_id = 0) {
        if ($user_id <= 0) $user_id = get_current_user_id();
        if ($user_id <= 0) {
            // Anonymous — fall back to IP.
            $user_id = 'ip:' . self::client_ip();
        }
        $action = sanitize_key($action);
        $limits = self::limits();
        $cfg    = isset($limits[$action]) ? $limits[$action] : $limits['default'];
        $max    = (int) $cfg['max'];
        $window = max(1, (int) $cfg['window']);
        if ($max <= 0) return array('allowed' => true, 'remaining' => -1, 'retry_after' => 0);

        $key = self::TRANSIENT_PREFIX . $action . '_' . md5((string) $user_id);
        $bucket = get_transient($key);
        if (!is_array($bucket)) {
            $bucket = array('count' => 0, 'reset' => time() + $window);
        }
        if (time() > $bucket['reset']) {
            $bucket = array('count' => 0, 'reset' => time() + $window);
        }

        if ($bucket['count'] >= $max) {
            return array(
                'allowed'     => false,
                'remaining'   => 0,
                'retry_after' => max(1, $bucket['reset'] - time()),
                'limit'       => $max,
            );
        }
        $bucket['count']++;
        set_transient($key, $bucket, $window);

        return array(
            'allowed'     => true,
            'remaining'   => max(0, $max - $bucket['count']),
            'retry_after' => 0,
            'limit'       => $max,
        );
    }

    private static function client_ip() {
        foreach (array('HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR') as $h) {
            if (!empty($_SERVER[$h])) {
                $val = explode(',', (string) $_SERVER[$h]);
                $ip = trim($val[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
            }
        }
        return 'unknown';
    }
}
