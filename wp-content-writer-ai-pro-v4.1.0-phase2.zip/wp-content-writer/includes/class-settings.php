<?php
/**
 * Settings Class — WP Content Writer AI Pro
 *
 * Generic, non-secret settings only (default language/tone, request timeout,
 * legacy `ollama_url` / `model` aliases used by older code paths). All AI
 * provider keys live in WPCW_Provider_Manager and are encrypted at rest.
 */

if (!defined('ABSPATH')) exit;

class WPCW_Settings {

    const OPTION_NAME = 'wpcw_settings';

    /**
     * Backwards-compatibility constants — older code paths read these
     * directly. They are intentionally NOT used to inject any vendor
     * API key into the runtime; that data lives in WPCW_Provider_Manager.
     */
    const DEFAULT_GROQ_API_BASE = 'https://api.groq.com/openai/v1';
    const DEFAULT_GROQ_MODEL    = 'llama-3.1-8b-instant';

    public static function get_defaults() {
        return array(
            // Kept under the legacy `ollama_url` key for back-compat with
            // existing installs (this is the Groq API base, not Ollama).
            'ollama_url'       => self::DEFAULT_GROQ_API_BASE,
            'model'            => self::DEFAULT_GROQ_MODEL,
            'host_header'      => '',
            'origin_header'    => '',
            'request_timeout'  => 120,
            'default_language' => 'Hindi',
            'default_tone'     => 'professional',
        );
    }

    public static function get_option_name() {
        return self::OPTION_NAME;
    }

    public function get_settings() {
        $saved    = get_option(self::OPTION_NAME, array());
        $defaults = self::get_defaults();
        $merged   = wp_parse_args(is_array($saved) ? $saved : array(), $defaults);

        // Drop any legacy localhost Ollama URL by transparently swapping
        // back to the bundled Groq base so the provider manager can use it.
        if (empty($merged['ollama_url']) || false !== stripos($merged['ollama_url'], 'localhost') || false !== stripos($merged['ollama_url'], '11434')) {
            $merged['ollama_url'] = self::DEFAULT_GROQ_API_BASE;
        }
        if (!self::is_valid_groq_model($merged['model'])) {
            $merged['model'] = self::DEFAULT_GROQ_MODEL;
        }

        // Strip any plaintext API key that may still be in this option from
        // earlier versions — we never want to read it here.
        unset($merged['groq_api_key']);

        return $merged;
    }

    /**
     * Whitelist check: does the given string look like a real Groq model id?
     */
    public static function is_valid_groq_model($model) {
        $model = strtolower(trim((string) $model));
        if ('' === $model) return false;
        $patterns = array(
            '/^llama-\d+(\.\d+)?-/',
            '/^llama\d+-\d+b/',
            '/^mixtral-/',
            '/^gemma\d?-/',
            '/^deepseek-/',
            '/^qwen-?/',
            '/^kimi-/',
            '/^moonshot-/',
            '/^gpt-oss/',
            '/^whisper-/',
            '/^meta-llama/',
        );
        foreach ($patterns as $re) {
            if (preg_match($re, $model)) return true;
        }
        return false;
    }

    public function get_setting($key) {
        $settings = $this->get_settings();
        return isset($settings[$key]) ? (string) $settings[$key] : '';
    }

    public function update_settings($data) {
        $current = $this->get_settings();
        $merged  = wp_parse_args(is_array($data) ? $data : array(), $current);
        unset($merged['groq_api_key']); // Never persist plaintext keys here.
        update_option(self::OPTION_NAME, $merged);
        return $merged;
    }
}
