<?php
/**
 * Activity log / audit trail — Phase 2.3.
 *
 * Persists every meaningful event (generation, post create / edit /
 * delete, approval transitions, license / settings changes) to a
 * dedicated DB table so admins get a tamper-evident timeline they can
 * filter and export.
 *
 * The table is created on activation via self::install() and pruned
 * automatically to RETENTION_DAYS so the row count never grows
 * unbounded. WordPress hooks are wired in self::bootstrap() during
 * `plugins_loaded` so we capture native post / user events too.
 */

if (!defined('ABSPATH')) exit;

class WPCW_Activity_Log {

    const RETENTION_DAYS = 180;
    const TABLE          = 'wpcw_activity_log';

    public static function table_name() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    public static function install() {
        global $wpdb;
        $table   = self::table_name();
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            action VARCHAR(64) NOT NULL,
            object_type VARCHAR(32) NOT NULL DEFAULT '',
            object_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            severity VARCHAR(16) NOT NULL DEFAULT 'info',
            message TEXT NULL,
            meta LONGTEXT NULL,
            ip VARCHAR(64) NOT NULL DEFAULT '',
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY action (action),
            KEY object (object_type, object_id),
            KEY created_at (created_at)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    public static function uninstall() {
        global $wpdb;
        $table = self::table_name();
        $wpdb->query("DROP TABLE IF EXISTS {$table}");
    }

    public static function bootstrap() {
        // Native WP events.
        add_action('transition_post_status', array(__CLASS__, 'on_post_transition'), 10, 3);
        add_action('deleted_post',           array(__CLASS__, 'on_post_deleted'),   10, 1);
        add_action('user_register',          array(__CLASS__, 'on_user_register'),  10, 1);
        add_action('set_user_role',          array(__CLASS__, 'on_role_change'),    10, 3);
        add_action('wp_login',               array(__CLASS__, 'on_login'),          10, 2);

        // Daily prune.
        if (!wp_next_scheduled('wpcw_activity_log_prune')) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'wpcw_activity_log_prune');
        }
        add_action('wpcw_activity_log_prune', array(__CLASS__, 'prune'));
    }

    /**
     * Insert a new activity row. Returns the inserted ID or 0 on failure.
     *
     * @param string $action     Short verb, e.g. `ai.generate`, `post.publish`.
     * @param array  $args {
     *   @type int    user_id     Defaults to current user.
     *   @type string object_type e.g. `post`, `bulk_job`, `license`.
     *   @type int    object_id   Numeric id, 0 if N/A.
     *   @type string severity    info | warning | error.
     *   @type string message     Human-readable summary.
     *   @type array  meta        Arbitrary JSON-serialised metadata.
     * }
     */
    public static function log($action, $args = array()) {
        global $wpdb;
        $action = sanitize_key($action);
        if ('' === $action) return 0;

        $defaults = array(
            'user_id'     => get_current_user_id(),
            'object_type' => '',
            'object_id'   => 0,
            'severity'    => 'info',
            'message'     => '',
            'meta'        => array(),
        );
        $a = wp_parse_args($args, $defaults);
        $a['severity'] = in_array($a['severity'], array('info','warning','error','success'), true) ? $a['severity'] : 'info';

        $row = array(
            'user_id'     => (int) $a['user_id'],
            'action'      => substr($action, 0, 60),
            'object_type' => substr(sanitize_key($a['object_type']), 0, 30),
            'object_id'   => (int) $a['object_id'],
            'severity'    => $a['severity'],
            'message'     => substr((string) $a['message'], 0, 1000),
            'meta'        => wp_json_encode($a['meta'] ?: new stdClass()),
            'ip'          => self::client_ip(),
            'created_at'  => gmdate('Y-m-d H:i:s'),
        );
        $ok = $wpdb->insert(self::table_name(), $row, array(
            '%d','%s','%s','%d','%s','%s','%s','%s','%s'
        ));
        return $ok ? (int) $wpdb->insert_id : 0;
    }

    public static function query($args = array()) {
        global $wpdb;
        $defaults = array(
            'user_id'     => 0,
            'action'      => '',
            'object_type' => '',
            'object_id'   => 0,
            'severity'    => '',
            'search'      => '',
            'date_from'   => '',
            'date_to'     => '',
            'per_page'    => 50,
            'page'        => 1,
        );
        $a = wp_parse_args($args, $defaults);

        $where  = array('1=1');
        $params = array();
        if ($a['user_id'])     { $where[] = 'user_id = %d';     $params[] = (int) $a['user_id']; }
        if ($a['action'])      { $where[] = 'action = %s';      $params[] = sanitize_key($a['action']); }
        if ($a['object_type']) { $where[] = 'object_type = %s'; $params[] = sanitize_key($a['object_type']); }
        if ($a['object_id'])   { $where[] = 'object_id = %d';   $params[] = (int) $a['object_id']; }
        if ($a['severity'])    { $where[] = 'severity = %s';    $params[] = sanitize_key($a['severity']); }
        if ($a['search']) {
            $where[]  = '(message LIKE %s OR action LIKE %s)';
            $like     = '%' . $wpdb->esc_like($a['search']) . '%';
            $params[] = $like;
            $params[] = $like;
        }
        if ($a['date_from']) { $where[] = 'created_at >= %s'; $params[] = $a['date_from']; }
        if ($a['date_to'])   { $where[] = 'created_at <= %s'; $params[] = $a['date_to']; }

        $per_page = max(1, min(500, (int) $a['per_page']));
        $page     = max(1, (int) $a['page']);
        $offset   = ($page - 1) * $per_page;

        $where_sql = implode(' AND ', $where);
        $table     = self::table_name();

        $sql_count = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
        $sql_rows  = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY id DESC LIMIT %d OFFSET %d";

        $count_params = $params;
        $row_params   = array_merge($params, array($per_page, $offset));

        $total = (int) $wpdb->get_var($count_params ? $wpdb->prepare($sql_count, $count_params) : $sql_count);
        $rows  = $wpdb->get_results($wpdb->prepare($sql_rows, $row_params), ARRAY_A);

        $items = array();
        foreach ((array) $rows as $r) {
            $items[] = self::format_row($r);
        }
        return array(
            'items'    => $items,
            'total'    => $total,
            'page'     => $page,
            'per_page' => $per_page,
            'pages'    => $per_page > 0 ? (int) ceil($total / $per_page) : 0,
        );
    }

    public static function format_row($r) {
        $meta = json_decode((string) ($r['meta'] ?? '{}'), true);
        if (!is_array($meta)) $meta = array();
        $user = !empty($r['user_id']) ? get_user_by('id', (int) $r['user_id']) : null;
        return array(
            'id'          => (int) $r['id'],
            'user_id'     => (int) $r['user_id'],
            'user_name'   => $user ? $user->display_name : 'System',
            'action'      => $r['action'],
            'object_type' => $r['object_type'],
            'object_id'   => (int) $r['object_id'],
            'severity'    => $r['severity'],
            'message'     => $r['message'],
            'meta'        => $meta,
            'ip'          => $r['ip'],
            'created_at'  => $r['created_at'],
        );
    }

    public static function distinct_actions() {
        global $wpdb;
        $table = self::table_name();
        $rows = $wpdb->get_col("SELECT DISTINCT action FROM {$table} ORDER BY action ASC LIMIT 200");
        return array_filter((array) $rows);
    }

    public static function prune() {
        global $wpdb;
        $cutoff = gmdate('Y-m-d H:i:s', time() - (self::RETENTION_DAYS * DAY_IN_SECONDS));
        $table  = self::table_name();
        $wpdb->query($wpdb->prepare("DELETE FROM {$table} WHERE created_at < %s", $cutoff));
    }

    public static function export_csv($args = array()) {
        $args = array_merge($args, array('per_page' => 5000, 'page' => 1));
        $data = self::query($args);
        $fh = fopen('php://temp', 'w+');
        fputcsv($fh, array('id','created_at','user_id','user_name','action','object_type','object_id','severity','message','ip'));
        foreach ($data['items'] as $row) {
            fputcsv($fh, array(
                $row['id'],
                $row['created_at'],
                $row['user_id'],
                $row['user_name'],
                $row['action'],
                $row['object_type'],
                $row['object_id'],
                $row['severity'],
                $row['message'],
                $row['ip'],
            ));
        }
        rewind($fh);
        $csv = stream_get_contents($fh);
        fclose($fh);
        return $csv;
    }

    // ── WP event hooks ────────────────────────────────────────────────

    public static function on_post_transition($new, $old, $post) {
        if ($new === $old) return;
        if ('auto-draft' === $new || wp_is_post_revision($post->ID)) return;
        $action = 'post.' . sanitize_key($new);
        self::log($action, array(
            'object_type' => 'post',
            'object_id'   => (int) $post->ID,
            'message'     => sprintf('Post "%s" %s → %s', $post->post_title, $old, $new),
            'meta'        => array('from' => $old, 'to' => $new, 'post_type' => $post->post_type),
        ));
    }

    public static function on_post_deleted($post_id) {
        self::log('post.deleted', array(
            'object_type' => 'post',
            'object_id'   => (int) $post_id,
            'severity'    => 'warning',
            'message'     => sprintf('Post #%d deleted', (int) $post_id),
        ));
    }

    public static function on_user_register($user_id) {
        $u = get_user_by('id', $user_id);
        self::log('user.created', array(
            'object_type' => 'user',
            'object_id'   => (int) $user_id,
            'message'     => $u ? sprintf('New user %s (%s)', $u->user_login, $u->user_email) : 'New user',
        ));
    }

    public static function on_role_change($user_id, $role, $old_roles) {
        self::log('user.role_changed', array(
            'object_type' => 'user',
            'object_id'   => (int) $user_id,
            'message'     => sprintf('Role changed → %s', $role),
            'meta'        => array('role' => $role, 'previous' => $old_roles),
        ));
    }

    public static function on_login($user_login, $user) {
        self::log('user.login', array(
            'user_id'     => $user ? (int) $user->ID : 0,
            'object_type' => 'user',
            'object_id'   => $user ? (int) $user->ID : 0,
            'message'     => sprintf('Login: %s', $user_login),
        ));
    }

    private static function client_ip() {
        foreach (array('HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR') as $h) {
            if (!empty($_SERVER[$h])) {
                $val = explode(',', (string) $_SERVER[$h]);
                $ip  = trim($val[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
            }
        }
        return '';
    }
}
