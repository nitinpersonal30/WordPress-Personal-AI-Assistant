<?php
/**
 * License manager — activation, tier resolution, feature gating.
 *
 * The plugin ships three tiers:
 *   - free    : default, limited templates / quota
 *   - pro     : unlocks all templates, higher quota, multi-provider
 *   - agency  : multisite, white-label, reseller, unlimited workspaces
 *
 * License activation is performed against an external license server
 * (configurable via WPCW_LICENSE_API_URL). When no server is configured,
 * activation is treated as a local stub so dev installs keep working.
 */

if (!defined('ABSPATH')) exit;

class WPCW_License {

    const OPTION_KEY    = 'wpcw_license';
    const TIER_FREE     = 'free';
    const TIER_PRO      = 'pro';
    const TIER_AGENCY   = 'agency';

    /**
     * Capability map — tier → feature flag → bool.
     * Higher tiers inherit lower-tier features unless overridden.
     */
    public static function feature_matrix() {
        return array(
            self::TIER_FREE => array(
                'templates_basic'      => true,
                'templates_premium'    => false,
                'multi_provider'       => false,
                'rag_context'          => false,
                'image_generation'     => false,
                'voice_to_blog'        => false,
                'plagiarism_check'     => false,
                'serp_analysis'        => false,
                'team_workflow'        => false,
                'brand_voice'          => false,
                'content_calendar'     => false,
                'bulk_csv'             => false,
                'webhooks'             => false,
                'wp_cli'               => true,
                'gutenberg_block'      => true,
                'white_label'          => false,
                'multisite'            => false,
                'reseller'             => false,
                'public_api'           => false,
            ),
            self::TIER_PRO => array(
                'templates_basic'      => true,
                'templates_premium'    => true,
                'multi_provider'       => true,
                'rag_context'          => true,
                'image_generation'     => true,
                'voice_to_blog'        => true,
                'plagiarism_check'     => true,
                'serp_analysis'        => true,
                'team_workflow'        => true,
                'brand_voice'          => true,
                'content_calendar'     => true,
                'bulk_csv'             => true,
                'webhooks'             => true,
                'wp_cli'               => true,
                'gutenberg_block'      => true,
                'white_label'          => false,
                'multisite'            => false,
                'reseller'             => false,
                'public_api'           => true,
            ),
            self::TIER_AGENCY => array(
                'templates_basic'      => true,
                'templates_premium'    => true,
                'multi_provider'       => true,
                'rag_context'          => true,
                'image_generation'     => true,
                'voice_to_blog'        => true,
                'plagiarism_check'     => true,
                'serp_analysis'        => true,
                'team_workflow'        => true,
                'brand_voice'          => true,
                'content_calendar'     => true,
                'bulk_csv'             => true,
                'webhooks'             => true,
                'wp_cli'               => true,
                'gutenberg_block'      => true,
                'white_label'          => true,
                'multisite'            => true,
                'reseller'             => true,
                'public_api'           => true,
            ),
        );
    }

    /**
     * Monthly quota per tier.
     */
    public static function quotas() {
        return array(
            self::TIER_FREE   => array('words' => 5000,    'posts' => 5,    'api_calls' => 200),
            self::TIER_PRO    => array('words' => 200000,  'posts' => 200,  'api_calls' => 10000),
            self::TIER_AGENCY => array('words' => -1,      'posts' => -1,   'api_calls' => -1),
        );
    }

    public static function get_data() {
        $defaults = array(
            'key'         => '',
            'tier'        => self::TIER_FREE,
            'status'      => 'inactive',
            'activated_at'=> 0,
            'expires_at'  => 0,
            'domain'      => '',
            'plan_label'  => 'Free',
            'last_check'  => 0,
        );
        $stored = get_option(self::OPTION_KEY, array());
        if (!is_array($stored)) $stored = array();
        if (!empty($stored['key'])) {
            $stored['key'] = WPCW_Encryption::decrypt($stored['key']);
        }
        return wp_parse_args($stored, $defaults);
    }

    public static function save_data($data) {
        if (!is_array($data)) return;
        if (isset($data['key']) && $data['key']) {
            $data['key'] = WPCW_Encryption::encrypt((string) $data['key']);
        }
        update_option(self::OPTION_KEY, $data, false);
    }

    public static function get_tier() {
        $data = self::get_data();
        if ('active' !== $data['status']) return self::TIER_FREE;
        if ($data['expires_at'] > 0 && $data['expires_at'] < time()) return self::TIER_FREE;
        $tier = isset($data['tier']) ? $data['tier'] : self::TIER_FREE;
        $matrix = self::feature_matrix();
        return isset($matrix[$tier]) ? $tier : self::TIER_FREE;
    }

    public static function get_plan_label() {
        $data = self::get_data();
        $labels = array(
            self::TIER_FREE   => 'Free',
            self::TIER_PRO    => 'Pro',
            self::TIER_AGENCY => 'Agency',
        );
        $tier = self::get_tier();
        return isset($labels[$tier]) ? $labels[$tier] : 'Free';
    }

    public static function is_feature_enabled($feature) {
        $matrix = self::feature_matrix();
        $tier = self::get_tier();
        return !empty($matrix[$tier][$feature]);
    }

    public static function get_quota() {
        $quotas = self::quotas();
        $tier = self::get_tier();
        return isset($quotas[$tier]) ? $quotas[$tier] : $quotas[self::TIER_FREE];
    }

    /**
     * Activate a license against the configured license server. Returns
     * an array with 'success' (bool) and 'message' (string).
     *
     * If no license server is configured (WPCW_LICENSE_API_URL is empty),
     * activation succeeds locally with a tier inferred from the key prefix
     * so developers can test the full plugin without running a backend.
     */
    public static function activate($license_key) {
        $license_key = trim((string) $license_key);
        if ('' === $license_key) {
            return array('success' => false, 'message' => 'License key required.');
        }

        $domain  = self::current_domain();
        $api_url = self::get_api_url();

        if ('' === $api_url) {
            // Local stub mode — keys starting "PRO-" or "AGENCY-" map to
            // the matching tier; everything else is treated as Pro for dev.
            $tier = self::TIER_PRO;
            if (0 === stripos($license_key, 'AGENCY-')) {
                $tier = self::TIER_AGENCY;
            } elseif (0 === stripos($license_key, 'FREE-')) {
                $tier = self::TIER_FREE;
            }
            self::save_data(array(
                'key'          => $license_key,
                'tier'         => $tier,
                'status'       => 'active',
                'activated_at' => time(),
                'expires_at'   => time() + YEAR_IN_SECONDS,
                'domain'       => $domain,
                'plan_label'   => ucfirst($tier),
                'last_check'   => time(),
            ));
            return array('success' => true, 'message' => 'License activated (local stub mode).');
        }

        $response = wp_remote_post(trailingslashit($api_url) . 'activate', array(
            'timeout' => 20,
            'headers' => array('Content-Type' => 'application/json', 'Accept' => 'application/json'),
            'body'    => wp_json_encode(array(
                'license_key' => $license_key,
                'domain'      => $domain,
                'plugin'      => 'wp-content-writer-ai-pro',
                'version'     => defined('WP_CONTENT_WRITER_VERSION') ? WP_CONTENT_WRITER_VERSION : '',
            )),
        ));

        if (is_wp_error($response)) {
            return array('success' => false, 'message' => 'Could not reach license server: ' . $response->get_error_message());
        }
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($body) || empty($body['success'])) {
            $msg = isset($body['message']) ? $body['message'] : 'License activation failed.';
            return array('success' => false, 'message' => $msg);
        }

        $tier = isset($body['tier']) ? sanitize_key($body['tier']) : self::TIER_PRO;
        if (!isset(self::feature_matrix()[$tier])) $tier = self::TIER_PRO;

        self::save_data(array(
            'key'          => $license_key,
            'tier'         => $tier,
            'status'       => 'active',
            'activated_at' => time(),
            'expires_at'   => isset($body['expires_at']) ? (int) $body['expires_at'] : (time() + YEAR_IN_SECONDS),
            'domain'       => $domain,
            'plan_label'   => isset($body['plan_label']) ? sanitize_text_field($body['plan_label']) : ucfirst($tier),
            'last_check'   => time(),
        ));

        return array('success' => true, 'message' => 'License activated successfully.');
    }

    public static function deactivate() {
        $data = self::get_data();
        $api_url = self::get_api_url();
        if ('' !== $api_url && !empty($data['key'])) {
            wp_remote_post(trailingslashit($api_url) . 'deactivate', array(
                'timeout' => 15,
                'headers' => array('Content-Type' => 'application/json'),
                'body'    => wp_json_encode(array(
                    'license_key' => $data['key'],
                    'domain'      => self::current_domain(),
                )),
            ));
        }
        self::save_data(array(
            'key'        => '',
            'tier'       => self::TIER_FREE,
            'status'     => 'inactive',
            'activated_at' => 0,
            'expires_at' => 0,
            'domain'     => '',
            'plan_label' => 'Free',
            'last_check' => time(),
        ));
        return array('success' => true, 'message' => 'License deactivated.');
    }

    public static function current_domain() {
        $url = home_url();
        $parts = wp_parse_url($url);
        return isset($parts['host']) ? strtolower($parts['host']) : '';
    }

    public static function get_api_url() {
        if (defined('WPCW_LICENSE_API_URL') && WPCW_LICENSE_API_URL) {
            return rtrim(WPCW_LICENSE_API_URL, '/');
        }
        return '';
    }
}
