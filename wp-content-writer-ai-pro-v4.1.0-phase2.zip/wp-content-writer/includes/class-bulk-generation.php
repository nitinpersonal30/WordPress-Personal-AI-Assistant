<?php
/**
 * Bulk content generation — Phase 2.6.
 *
 * Workflow:
 *   1. User uploads CSV (columns: title, prompt, template, language,
 *      tone, post_type, status, brand_voice, focus_keyword, tags,
 *      category). One row = one post to generate.
 *   2. Rows are persisted to wp_wpcw_bulk_jobs / wp_wpcw_bulk_items.
 *   3. WP-Cron event `wpcw_bulk_tick` runs every 5 minutes and processes
 *      up to BATCH_SIZE pending items per tick, calling the existing
 *      provider manager and inserting WP posts when content is ready.
 *
 * The class is fully license-gated — only Pro / Agency tiers and users
 * with `wpcw_run_bulk` can enqueue jobs.
 */

if (!defined('ABSPATH')) exit;

class WPCW_Bulk_Generation {

    const TABLE_JOBS  = 'wpcw_bulk_jobs';
    const TABLE_ITEMS = 'wpcw_bulk_items';
    const BATCH_SIZE  = 5;
    const HOOK_TICK   = 'wpcw_bulk_tick';

    public static function jobs_table() { global $wpdb; return $wpdb->prefix . self::TABLE_JOBS; }
    public static function items_table() { global $wpdb; return $wpdb->prefix . self::TABLE_ITEMS; }

    public static function install() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $jobs    = self::jobs_table();
        $items   = self::items_table();

        $sql_jobs = "CREATE TABLE {$jobs} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            name VARCHAR(190) NOT NULL DEFAULT '',
            status VARCHAR(20) NOT NULL DEFAULT 'queued',
            total_items INT UNSIGNED NOT NULL DEFAULT 0,
            done_items INT UNSIGNED NOT NULL DEFAULT 0,
            failed_items INT UNSIGNED NOT NULL DEFAULT 0,
            options LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY status (status)
        ) {$charset};";

        $sql_items = "CREATE TABLE {$items} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            job_id BIGINT(20) UNSIGNED NOT NULL,
            row_index INT UNSIGNED NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            input LONGTEXT NULL,
            output LONGTEXT NULL,
            post_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            error TEXT NULL,
            attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY job_id (job_id),
            KEY status (status)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql_jobs);
        dbDelta($sql_items);
    }

    public static function uninstall() {
        global $wpdb;
        $wpdb->query('DROP TABLE IF EXISTS ' . self::items_table());
        $wpdb->query('DROP TABLE IF EXISTS ' . self::jobs_table());
        $ts = wp_next_scheduled(self::HOOK_TICK);
        if ($ts) wp_unschedule_event($ts, self::HOOK_TICK);
    }

    public static function bootstrap() {
        if (!wp_next_scheduled(self::HOOK_TICK)) {
            wp_schedule_event(time() + 60, 'wpcw_five_min', self::HOOK_TICK);
        }
        add_filter('cron_schedules', array(__CLASS__, 'register_schedule'));
        add_action(self::HOOK_TICK, array(__CLASS__, 'process_tick'));
    }

    public static function register_schedule($schedules) {
        if (!isset($schedules['wpcw_five_min'])) {
            $schedules['wpcw_five_min'] = array(
                'interval' => 300,
                'display'  => 'Every 5 minutes (WPCW)',
            );
        }
        return $schedules;
    }

    /**
     * Parse a CSV string and return an array of normalised rows.
     */
    public static function parse_csv($csv) {
        $csv = trim((string) $csv);
        if ('' === $csv) return new WP_Error('empty', 'CSV is empty.');
        $fh = fopen('php://temp', 'r+');
        fwrite($fh, $csv);
        rewind($fh);

        $header = fgetcsv($fh);
        if (!$header) { fclose($fh); return new WP_Error('bad_csv', 'CSV header missing.'); }
        $header = array_map(function ($h) { return strtolower(trim((string) $h)); }, $header);

        $rows = array();
        while (($row = fgetcsv($fh)) !== false) {
            if (count($row) === 1 && trim((string) $row[0]) === '') continue;
            $assoc = array();
            foreach ($header as $i => $col) {
                $assoc[$col] = isset($row[$i]) ? trim((string) $row[$i]) : '';
            }
            $rows[] = $assoc;
        }
        fclose($fh);

        if (!$rows) return new WP_Error('no_rows', 'CSV has no data rows.');
        if (count($rows) > 500) return new WP_Error('too_many', 'Maximum 500 rows per upload.');

        return $rows;
    }

    public static function create_job($name, $rows, $options = array()) {
        global $wpdb;
        if (!current_user_can('wpcw_run_bulk')) {
            return new WP_Error('forbidden', 'Missing wpcw_run_bulk capability.');
        }
        if (!class_exists('WPCW_License') || !WPCW_License::is_feature_enabled('bulk_csv')) {
            return new WP_Error('feature_locked', 'Bulk generation requires Pro tier or higher.');
        }
        $name = sanitize_text_field($name) ?: ('Bulk job ' . gmdate('Y-m-d H:i'));
        if (!is_array($rows) || !$rows) return new WP_Error('no_rows', 'No rows.');

        $now = gmdate('Y-m-d H:i:s');
        $wpdb->insert(self::jobs_table(), array(
            'user_id'     => get_current_user_id(),
            'name'        => $name,
            'status'      => 'queued',
            'total_items' => count($rows),
            'done_items'  => 0,
            'failed_items'=> 0,
            'options'     => wp_json_encode($options ?: new stdClass()),
            'created_at'  => $now,
            'updated_at'  => $now,
        ));
        $job_id = (int) $wpdb->insert_id;
        if (!$job_id) return new WP_Error('insert_failed', 'Could not create job.');

        foreach ($rows as $i => $row) {
            $wpdb->insert(self::items_table(), array(
                'job_id'    => $job_id,
                'row_index' => (int) $i,
                'status'    => 'pending',
                'input'     => wp_json_encode($row),
                'updated_at'=> $now,
            ));
        }

        if (class_exists('WPCW_Activity_Log')) {
            WPCW_Activity_Log::log('bulk.job_created', array(
                'object_type' => 'bulk_job',
                'object_id'   => $job_id,
                'message'     => sprintf('Bulk job "%s" queued (%d items)', $name, count($rows)),
            ));
        }

        // Kick the worker immediately.
        if (!wp_next_scheduled(self::HOOK_TICK)) {
            wp_schedule_single_event(time() + 5, self::HOOK_TICK);
        }
        return self::get_job($job_id);
    }

    public static function get_job($job_id) {
        global $wpdb;
        $job_id = (int) $job_id;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::jobs_table() . " WHERE id = %d", $job_id), ARRAY_A);
        if (!$row) return null;
        $row['options'] = json_decode((string) $row['options'], true);
        return $row;
    }

    public static function list_jobs($args = array()) {
        global $wpdb;
        $defaults = array('user_id' => 0, 'page' => 1, 'per_page' => 30);
        $a = wp_parse_args($args, $defaults);
        $where  = array('1=1');
        $params = array();
        if ($a['user_id']) { $where[] = 'user_id = %d'; $params[] = (int) $a['user_id']; }
        $sql = 'SELECT * FROM ' . self::jobs_table() . ' WHERE ' . implode(' AND ', $where) . ' ORDER BY id DESC LIMIT %d OFFSET %d';
        $per_page = max(1, (int) $a['per_page']);
        $page     = max(1, (int) $a['page']);
        $params[] = $per_page;
        $params[] = ($page - 1) * $per_page;
        $rows = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        foreach ($rows as &$r) {
            $r['options'] = json_decode((string) $r['options'], true);
        }
        return $rows;
    }

    public static function get_items($job_id, $page = 1, $per_page = 50) {
        global $wpdb;
        $job_id = (int) $job_id;
        $per_page = max(1, (int) $per_page);
        $page = max(1, (int) $page);
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT * FROM ' . self::items_table() . ' WHERE job_id = %d ORDER BY row_index ASC LIMIT %d OFFSET %d',
            $job_id, $per_page, ($page - 1) * $per_page
        ), ARRAY_A);
        foreach ($rows as &$r) {
            $r['input']  = json_decode((string) $r['input'], true);
            $r['output'] = $r['output'] ? json_decode((string) $r['output'], true) : null;
        }
        return $rows;
    }

    public static function cancel_job($job_id) {
        global $wpdb;
        $job_id = (int) $job_id;
        $job = self::get_job($job_id);
        if (!$job) return new WP_Error('not_found', 'Job not found.');
        $wpdb->update(self::jobs_table(), array('status' => 'cancelled', 'updated_at' => gmdate('Y-m-d H:i:s')), array('id' => $job_id));
        $wpdb->query($wpdb->prepare('UPDATE ' . self::items_table() . " SET status = 'cancelled' WHERE job_id = %d AND status = 'pending'", $job_id));
        if (class_exists('WPCW_Activity_Log')) {
            WPCW_Activity_Log::log('bulk.job_cancelled', array(
                'object_type' => 'bulk_job',
                'object_id'   => $job_id,
                'message'     => sprintf('Bulk job #%d cancelled', $job_id),
                'severity'    => 'warning',
            ));
        }
        return true;
    }

    public static function delete_job($job_id) {
        global $wpdb;
        $job_id = (int) $job_id;
        $wpdb->query($wpdb->prepare('DELETE FROM ' . self::items_table() . ' WHERE job_id = %d', $job_id));
        $wpdb->query($wpdb->prepare('DELETE FROM ' . self::jobs_table()  . ' WHERE id = %d', $job_id));
        return true;
    }

    /**
     * Worker tick — picks up to BATCH_SIZE pending items and processes
     * them. Re-schedules itself if more work remains.
     */
    public static function process_tick() {
        global $wpdb;
        $items_table = self::items_table();
        $jobs_table  = self::jobs_table();

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT i.* FROM {$items_table} i
               INNER JOIN {$jobs_table} j ON j.id = i.job_id
              WHERE i.status = 'pending' AND j.status IN ('queued','processing')
              ORDER BY i.id ASC
              LIMIT %d",
            self::BATCH_SIZE
        ), ARRAY_A);

        if (!$rows) return;

        $providers = class_exists('WPCW_Provider_Manager') ? new WPCW_Provider_Manager() : null;

        foreach ($rows as $row) {
            $job = self::get_job((int) $row['job_id']);
            if (!$job || in_array($job['status'], array('cancelled', 'completed'), true)) continue;

            $wpdb->update($items_table, array('status' => 'processing', 'attempts' => (int) $row['attempts'] + 1, 'updated_at' => gmdate('Y-m-d H:i:s')), array('id' => $row['id']));
            $wpdb->update($jobs_table,  array('status' => 'processing', 'updated_at' => gmdate('Y-m-d H:i:s')), array('id' => $row['job_id']));

            $input = json_decode((string) $row['input'], true);
            if (!is_array($input)) $input = array();

            $result = self::generate_one($input, $providers, $job);

            if (is_wp_error($result)) {
                $wpdb->update($items_table, array(
                    'status'     => 'failed',
                    'error'      => $result->get_error_message(),
                    'updated_at' => gmdate('Y-m-d H:i:s'),
                ), array('id' => $row['id']));
                $wpdb->query($wpdb->prepare("UPDATE {$jobs_table} SET failed_items = failed_items + 1, updated_at = %s WHERE id = %d", gmdate('Y-m-d H:i:s'), $row['job_id']));
                if (class_exists('WPCW_Activity_Log')) {
                    WPCW_Activity_Log::log('bulk.item_failed', array(
                        'object_type' => 'bulk_item',
                        'object_id'   => (int) $row['id'],
                        'severity'    => 'error',
                        'message'     => 'Bulk item failed: ' . $result->get_error_message(),
                    ));
                }
            } else {
                $wpdb->update($items_table, array(
                    'status'     => 'completed',
                    'output'     => wp_json_encode($result),
                    'post_id'    => isset($result['post_id']) ? (int) $result['post_id'] : 0,
                    'updated_at' => gmdate('Y-m-d H:i:s'),
                ), array('id' => $row['id']));
                $wpdb->query($wpdb->prepare("UPDATE {$jobs_table} SET done_items = done_items + 1, updated_at = %s WHERE id = %d", gmdate('Y-m-d H:i:s'), $row['job_id']));
            }

            // Mark job complete when no pending items remain.
            $remaining = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$items_table} WHERE job_id = %d AND status IN ('pending','processing')", $row['job_id']));
            if (0 === $remaining) {
                $wpdb->update($jobs_table, array('status' => 'completed', 'updated_at' => gmdate('Y-m-d H:i:s')), array('id' => $row['job_id']));
                if (class_exists('WPCW_Activity_Log')) {
                    WPCW_Activity_Log::log('bulk.job_completed', array(
                        'object_type' => 'bulk_job',
                        'object_id'   => (int) $row['job_id'],
                        'message'     => sprintf('Bulk job #%d completed', (int) $row['job_id']),
                    ));
                }
            }
        }

        // If more items remain across all jobs, schedule another tick soon.
        $more = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$items_table} WHERE status = 'pending'");
        if ($more > 0) {
            wp_schedule_single_event(time() + 30, self::HOOK_TICK);
        }
    }

    private static function generate_one($input, $providers, $job) {
        if (!$providers) return new WP_Error('no_provider', 'Provider manager unavailable.');

        $title    = sanitize_text_field($input['title']  ?? '');
        $prompt   = (string) ($input['prompt'] ?? '');
        $template = sanitize_key($input['template'] ?? '');
        $language = sanitize_text_field($input['language'] ?? '');
        $tone     = sanitize_key($input['tone'] ?? '');
        $voice    = sanitize_key($input['brand_voice'] ?? '');
        $status   = sanitize_key($input['status'] ?? 'draft');
        $post_type= sanitize_key($input['post_type'] ?? 'post');
        $tags     = sanitize_text_field($input['tags'] ?? '');
        $category = sanitize_text_field($input['category'] ?? '');
        $focus    = sanitize_text_field($input['focus_keyword'] ?? '');

        if ('' === $prompt && $template && class_exists('WPCW_Templates')) {
            $fields = $input;
            // Prefer human-readable fields for the template builder.
            $prompt = WPCW_Templates::build_prompt($template, $fields);
        }
        if ('' === $prompt && $title) $prompt = 'Write a high-quality blog post titled: ' . $title;
        if ('' === $prompt) return new WP_Error('empty_prompt', 'Row missing prompt and title.');

        $system = 'You are a professional SEO content writer.';
        if ($language) $system .= ' Write in ' . $language . '.';
        if ($tone)     $system .= ' Tone: ' . $tone . '.';
        if (class_exists('WPCW_Brand_Voice')) {
            $voice_prompt = WPCW_Brand_Voice::system_prompt($voice);
            if ($voice_prompt) $system .= "\n" . $voice_prompt;
        }

        $messages = array(
            array('role' => 'system', 'content' => $system),
            array('role' => 'user',   'content' => $prompt),
        );
        $result = $providers->chat($messages, array(
            'temperature' => 0.7,
            'top_p'       => 0.9,
            'max_tokens'  => 4096,
        ));
        if (is_wp_error($result)) return $result;
        $content = isset($result['content']) ? $result['content'] : '';
        if ('' === $content) return new WP_Error('empty_output', 'AI returned empty content.');

        $post_status = in_array($status, array('draft','pending','future','publish'), true) ? $status : 'draft';
        $post_id = wp_insert_post(array(
            'post_title'   => $title ?: wp_trim_words($content, 12, '…'),
            'post_content' => self::markdown_to_html($content),
            'post_status'  => $post_status,
            'post_type'    => $post_type ?: 'post',
            'post_author'  => (int) $job['user_id'],
        ), true);
        if (is_wp_error($post_id)) return $post_id;

        if ($category && 'post' === $post_type) {
            $cat_id = term_exists($category, 'category');
            if (!$cat_id) $cat_id = wp_insert_term($category, 'category');
            if (!is_wp_error($cat_id)) {
                wp_set_post_categories($post_id, array(is_array($cat_id) ? $cat_id['term_id'] : $cat_id));
            }
        }
        if ($tags && 'post' === $post_type) {
            wp_set_post_tags($post_id, array_map('trim', explode(',', $tags)));
        }
        if ($focus && class_exists('WPCW_SEO')) {
            WPCW_SEO::set_seo_meta($post_id, array(
                'focus_keyword'   => $focus,
                'seo_title'       => $title,
                'seo_description' => '',
            ));
        }

        if (class_exists('WPCW_Workflow')) {
            update_post_meta($post_id, WPCW_Workflow::META_STATE, WPCW_Workflow::STATE_DRAFT);
        }

        $words = str_word_count(wp_strip_all_tags($content));
        if (class_exists('WPCW_Usage')) {
            WPCW_Usage::record(array(
                'user_id'      => (int) $job['user_id'],
                'provider'     => $result['provider'] ?? '',
                'template'     => $template,
                'words'        => $words,
                'tokens_in'    => $result['tokens_in']  ?? 0,
                'tokens_out'   => $result['tokens_out'] ?? 0,
                'cost_usd'     => $result['cost_usd']   ?? 0.0,
                'created_post' => true,
            ));
        }

        return array(
            'post_id'  => (int) $post_id,
            'edit_url' => get_edit_post_link($post_id, 'raw'),
            'words'    => $words,
            'provider' => $result['provider'] ?? '',
        );
    }

    private static function markdown_to_html($md) {
        if (class_exists('WPCW_API') && method_exists('WPCW_API', 'public_markdown_to_html')) {
            return WPCW_API::public_markdown_to_html($md);
        }
        // Conservative fallback — keep raw text in a <pre> when no
        // markdown helper is available.
        return wpautop(wp_kses_post($md));
    }

    /**
     * Sample CSV header / row to download as a starter file.
     */
    public static function template_csv() {
        $headers = array('title','prompt','template','language','tone','post_type','status','brand_voice','focus_keyword','tags','category');
        $sample  = array(
            '"10 Tips for Faster WordPress"',
            '"Write a 1200-word SEO blog post about speeding up WordPress."',
            '"blog_post"',
            '"English"',
            '"professional"',
            '"post"',
            '"draft"',
            '""',
            '"wordpress speed"',
            '"wordpress, performance"',
            '"WordPress"',
        );
        return implode(',', $headers) . "\n" . implode(',', $sample) . "\n";
    }
}
