<?php
/**
 * Roles & permissions — Phase 2.1 (Agency tier).
 *
 * Adds five team roles on top of WordPress core:
 *   - wpcw_owner   : full control of the workspace, billing, team mgmt.
 *   - wpcw_admin   : manage settings / providers / team, no billing.
 *   - wpcw_editor  : approve / publish content + brand voice / calendar.
 *   - wpcw_writer  : generate / save drafts and submit for review.
 *   - wpcw_viewer  : read-only access to dashboards and history.
 *
 * Capabilities are exposed under the `wpcw_*` namespace and consumed
 * by the REST permission callbacks plus the admin menu builder. Core
 * WP roles (administrator / editor / author) keep working transparently
 * because we map their core caps to equivalent wpcw_* caps.
 *
 * The class is feature-gated: when the active license tier is below
 * Pro, only owner/admin caps map to `manage_options` so a Free site
 * still behaves like a single-seat install.
 */

if (!defined('ABSPATH')) exit;

class WPCW_Roles {

    const ROLE_OWNER  = 'wpcw_owner';
    const ROLE_ADMIN  = 'wpcw_admin';
    const ROLE_EDITOR = 'wpcw_editor';
    const ROLE_WRITER = 'wpcw_writer';
    const ROLE_VIEWER = 'wpcw_viewer';

    const OPTION_VERSION = 'wpcw_roles_version';
    const ROLES_VERSION  = 2;

    /**
     * Granular capability keys used across the plugin. Keep this list
     * in sync with the labels returned by self::cap_labels().
     */
    public static function all_caps() {
        return array(
            'wpcw_generate',          // run AI generation endpoints
            'wpcw_save_draft',        // create / edit own drafts
            'wpcw_submit_review',     // submit a draft for approval
            'wpcw_approve',           // approve / reject in review queue
            'wpcw_publish',           // publish approved content
            'wpcw_view_calendar',     // see editorial calendar
            'wpcw_manage_calendar',   // schedule / move calendar items
            'wpcw_manage_brand_voice',// CRUD brand voice profiles
            'wpcw_run_bulk',          // upload CSV / start bulk jobs
            'wpcw_view_analytics',    // usage analytics dashboard
            'wpcw_view_activity',     // audit trail page
            'wpcw_manage_team',       // invite / role-change team members
            'wpcw_manage_providers',  // edit AI provider keys
            'wpcw_manage_license',    // activate / deactivate license
            'wpcw_manage_settings',   // global plugin settings
        );
    }

    public static function cap_labels() {
        return array(
            'wpcw_generate'          => 'Generate content with AI',
            'wpcw_save_draft'        => 'Save own drafts',
            'wpcw_submit_review'     => 'Submit drafts for review',
            'wpcw_approve'           => 'Approve / reject submissions',
            'wpcw_publish'           => 'Publish approved content',
            'wpcw_view_calendar'     => 'View editorial calendar',
            'wpcw_manage_calendar'   => 'Schedule / move calendar items',
            'wpcw_manage_brand_voice'=> 'Manage brand voice profiles',
            'wpcw_run_bulk'          => 'Run bulk generation jobs',
            'wpcw_view_analytics'    => 'View usage analytics',
            'wpcw_view_activity'     => 'View activity log',
            'wpcw_manage_team'       => 'Manage team members',
            'wpcw_manage_providers'  => 'Manage AI providers',
            'wpcw_manage_license'    => 'Manage license',
            'wpcw_manage_settings'   => 'Manage plugin settings',
        );
    }

    /**
     * Capability matrix per built-in role. Core roles inherit via
     * map_meta_cap so admins always have everything.
     */
    public static function capability_matrix() {
        $all = array_fill_keys(self::all_caps(), true);
        return array(
            self::ROLE_OWNER  => $all,
            self::ROLE_ADMIN  => array_merge($all, array()),
            self::ROLE_EDITOR => array(
                'wpcw_generate'           => true,
                'wpcw_save_draft'         => true,
                'wpcw_submit_review'      => true,
                'wpcw_approve'            => true,
                'wpcw_publish'            => true,
                'wpcw_view_calendar'      => true,
                'wpcw_manage_calendar'    => true,
                'wpcw_manage_brand_voice' => true,
                'wpcw_run_bulk'           => true,
                'wpcw_view_analytics'     => true,
                'wpcw_view_activity'      => true,
            ),
            self::ROLE_WRITER => array(
                'wpcw_generate'      => true,
                'wpcw_save_draft'    => true,
                'wpcw_submit_review' => true,
                'wpcw_view_calendar' => true,
            ),
            self::ROLE_VIEWER => array(
                'wpcw_view_calendar'  => true,
                'wpcw_view_analytics' => true,
                'wpcw_view_activity'  => true,
            ),
        );
    }

    public static function role_labels() {
        return array(
            self::ROLE_OWNER  => 'WPCW Owner',
            self::ROLE_ADMIN  => 'WPCW Admin',
            self::ROLE_EDITOR => 'WPCW Editor',
            self::ROLE_WRITER => 'WPCW Writer',
            self::ROLE_VIEWER => 'WPCW Viewer',
        );
    }

    /**
     * Install / refresh roles. Idempotent — safe to call on every
     * activation and on version bumps.
     */
    public static function install() {
        $matrix = self::capability_matrix();
        foreach (self::role_labels() as $slug => $label) {
            $caps = isset($matrix[$slug]) ? $matrix[$slug] : array();
            // Add a base read cap so the dashboard is usable.
            $caps['read'] = true;
            if (in_array($slug, array(self::ROLE_OWNER, self::ROLE_ADMIN, self::ROLE_EDITOR, self::ROLE_WRITER), true)) {
                $caps['edit_posts']   = true;
                $caps['delete_posts'] = true;
            }
            if (in_array($slug, array(self::ROLE_OWNER, self::ROLE_ADMIN, self::ROLE_EDITOR), true)) {
                $caps['publish_posts']         = true;
                $caps['edit_published_posts']  = true;
                $caps['edit_others_posts']     = true;
                $caps['delete_others_posts']   = true;
            }
            $existing = get_role($slug);
            if ($existing) {
                foreach ($caps as $cap => $grant) $existing->add_cap($cap, $grant);
            } else {
                add_role($slug, $label, $caps);
            }
        }

        // Make sure the WP administrator role has the wpcw_* caps so the
        // site owner is never locked out after install.
        $admin = get_role('administrator');
        if ($admin) {
            foreach (self::all_caps() as $cap) {
                if (!$admin->has_cap($cap)) $admin->add_cap($cap);
            }
        }

        update_option(self::OPTION_VERSION, self::ROLES_VERSION, false);
    }

    /**
     * Remove the wpcw_* roles and capabilities. Called from the
     * uninstall hook.
     */
    public static function uninstall() {
        foreach (array_keys(self::role_labels()) as $slug) {
            if (get_role($slug)) remove_role($slug);
        }
        $admin = get_role('administrator');
        if ($admin) {
            foreach (self::all_caps() as $cap) {
                if ($admin->has_cap($cap)) $admin->remove_cap($cap);
            }
        }
        delete_option(self::OPTION_VERSION);
    }

    /**
     * Re-run install when the schema version moves. Triggered from
     * `plugins_loaded`.
     */
    public static function maybe_upgrade() {
        $current = (int) get_option(self::OPTION_VERSION, 0);
        if ($current < self::ROLES_VERSION) {
            self::install();
        }
    }

    /**
     * Map a meta cap so legacy `manage_options` requests resolve to a
     * granular wpcw_* cap when checked through current_user_can().
     */
    public static function map_meta_cap($caps, $cap, $user_id, $args) {
        $aliases = array(
            'wpcw_manage_settings'   => 'manage_options',
            'wpcw_manage_providers'  => 'manage_options',
            'wpcw_manage_license'    => 'manage_options',
            'wpcw_manage_team'       => 'manage_options',
            'wpcw_view_analytics'    => 'edit_posts',
            'wpcw_view_activity'     => 'edit_posts',
            'wpcw_view_calendar'     => 'edit_posts',
            'wpcw_manage_calendar'   => 'edit_others_posts',
            'wpcw_manage_brand_voice'=> 'edit_others_posts',
            'wpcw_run_bulk'          => 'edit_others_posts',
            'wpcw_approve'           => 'edit_others_posts',
            'wpcw_publish'           => 'publish_posts',
            'wpcw_submit_review'     => 'edit_posts',
            'wpcw_save_draft'        => 'edit_posts',
            'wpcw_generate'          => 'edit_posts',
        );
        if (isset($aliases[$cap])) {
            // If the user already explicitly has the wpcw cap (granted
            // through one of our roles), keep it; otherwise fall back
            // to the WP-core equivalent so plain administrators / editors
            // still work without being assigned wpcw roles.
            $user = $user_id ? get_userdata($user_id) : wp_get_current_user();
            if ($user && !empty($user->allcaps[$cap])) return $caps;
            return array($aliases[$cap]);
        }
        return $caps;
    }

    /**
     * Convenience helper used by REST permission callbacks and the
     * admin menu builder.
     */
    public static function user_can($cap, $user_id = 0) {
        if (!$cap) return false;
        if ($user_id <= 0) return current_user_can($cap);
        return user_can($user_id, $cap);
    }

    /**
     * Returns a flat list of users with at least one wpcw_* capability,
     * for the team management screen.
     */
    public static function list_team_members() {
        $roles  = array_keys(self::role_labels());
        $roles[] = 'administrator';
        $users  = get_users(array(
            'role__in' => $roles,
            'number'   => 200,
            'orderby'  => 'display_name',
        ));
        $rows = array();
        foreach ($users as $u) {
            $primary = '';
            foreach ($roles as $r) {
                if (in_array($r, (array) $u->roles, true)) { $primary = $r; break; }
            }
            $rows[] = array(
                'id'         => (int) $u->ID,
                'name'       => $u->display_name,
                'email'      => $u->user_email,
                'role'       => $primary,
                'role_label' => $primary === 'administrator' ? 'Administrator' : (self::role_labels()[$primary] ?? $primary),
            );
        }
        return $rows;
    }

    public static function set_user_role($user_id, $role) {
        $user_id = (int) $user_id;
        $role    = sanitize_key($role);
        if ($user_id <= 0) return new WP_Error('bad_user', 'Invalid user.');
        $allowed = array_keys(self::role_labels());
        $allowed[] = 'administrator';
        if (!in_array($role, $allowed, true)) {
            return new WP_Error('bad_role', 'Invalid role.');
        }
        $user = get_userdata($user_id);
        if (!$user) return new WP_Error('not_found', 'User not found.');
        $user->set_role($role);
        return true;
    }
}
