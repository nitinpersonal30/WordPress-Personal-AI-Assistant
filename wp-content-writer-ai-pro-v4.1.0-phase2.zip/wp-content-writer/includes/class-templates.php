<?php
/**
 * Content Templates — WP Content Writer AI Pro
 * Jasper/Copy.ai style — 50+ templates for SEO, Digital Marketing, WordPress,
 * Web Development, Graphic Design, Elementor, Rank Math, and more.
 * Powered by local llama3
 */

if (!defined('ABSPATH')) exit;

class WPCW_Templates {

    public static function get_all() {
        return array(

            // =====================================================================
            // BLOG CONTENT
            // =====================================================================
            'blog_post' => array(
                'label'       => 'Blog Post (Complete)',
                'group'       => 'Blog Content',
                'icon'        => 'edit',
                'description' => 'Full SEO-optimized blog post with headings, intro, body, and CTA',
                'fields'      => array(
                    array('name' => 'topic',    'label' => 'Blog Topic *',      'type' => 'text',   'placeholder' => 'e.g. WordPress SEO tips 2025'),
                    array('name' => 'keywords', 'label' => 'Target Keywords *', 'type' => 'text',   'placeholder' => 'e.g. WordPress SEO, on-page SEO'),
                    array('name' => 'words',    'label' => 'Word Count',        'type' => 'select', 'options' => array('500','800','1000','1500','2000','3000')),
                    array('name' => 'tone',     'label' => 'Tone',              'type' => 'tone'),
                    array('name' => 'language', 'label' => 'Language',          'type' => 'language'),
                ),
                'prompt' => 'You are an expert SEO content writer. Write a {words}-word comprehensive SEO blog post in {language}.
Topic: {topic}
Primary Keywords: {keywords}
Tone: {tone}

STRUCTURE REQUIREMENTS:
1. SEO-optimized H1 title (include primary keyword, use power words, under 60 chars)
2. Meta description (155 chars, include keyword, add CTA)
3. Introduction (hook + pain point + promise, 100 words)
4. 5-7 H2 sections with 2-3 H3 subsections each
5. Include bullet points, numbered lists, and bold key phrases
6. Internal linking suggestions in [brackets]
7. Conclusion with strong CTA
8. 5 FAQ questions with answers (for schema markup)

SEO RULES:
- Keyword density: 1-2%
- Use LSI keywords naturally
- Short paragraphs (2-3 sentences)
- Transition words between sections
- Include statistics/data points where relevant',
            ),

            'blog_intro' => array(
                'label'       => 'Blog Introduction',
                'group'       => 'Blog Content',
                'icon'        => 'megaphone',
                'description' => 'Attention-grabbing blog post introduction',
                'fields'      => array(
                    array('name' => 'topic',    'label' => 'Blog Topic *',    'type' => 'text', 'placeholder' => 'e.g. How to start freelancing'),
                    array('name' => 'audience', 'label' => 'Target Audience', 'type' => 'text', 'placeholder' => 'e.g. beginners, students'),
                    array('name' => 'tone',     'label' => 'Tone',            'type' => 'tone'),
                    array('name' => 'language', 'label' => 'Language',        'type' => 'language'),
                ),
                'prompt' => 'Write 3 different blog introductions (100-150 words each) in {language} for: "{topic}"
Audience: {audience}. Tone: {tone}.

Version 1: Start with a surprising statistic or fact
Version 2: Start with a relatable story or scenario
Version 3: Start with a bold statement or question

Each must: Hook reader in first line, identify pain point, promise what they will learn, naturally include the topic keyword.',
            ),

            'blog_outline' => array(
                'label'       => 'Blog Outline',
                'group'       => 'Blog Content',
                'icon'        => 'list-view',
                'description' => 'Detailed blog post structure with SEO optimization',
                'fields'      => array(
                    array('name' => 'topic',    'label' => 'Blog Topic *',  'type' => 'text', 'placeholder' => 'e.g. Email marketing for beginners'),
                    array('name' => 'keywords', 'label' => 'Keywords *',    'type' => 'text', 'placeholder' => 'e.g. email marketing, newsletter'),
                    array('name' => 'language', 'label' => 'Language',      'type' => 'language'),
                ),
                'prompt' => 'Create a comprehensive SEO blog post outline in {language}.
Topic: {topic}
Keywords: {keywords}

Output format:
- H1 title (keyword-optimized, under 60 chars)
- Meta description (155 chars)
- 7-8 H2 sections with 2-3 H3 subsections each
- Brief description of what to cover in each section
- Suggested word count per section
- 5-7 FAQ questions
- Internal link suggestions
- CTA ideas
- Suggested featured image description',
            ),

            'blog_conclusion' => array(
                'label'       => 'Blog Conclusion',
                'group'       => 'Blog Content',
                'icon'        => 'flag',
                'description' => 'Powerful blog conclusion with CTA',
                'fields'      => array(
                    array('name' => 'topic',    'label' => 'Blog Topic *',  'type' => 'text', 'placeholder' => 'e.g. WordPress speed optimization'),
                    array('name' => 'points',   'label' => 'Key Points Covered', 'type' => 'textarea', 'placeholder' => 'List main points from your article...'),
                    array('name' => 'cta',      'label' => 'Call to Action','type' => 'text', 'placeholder' => 'e.g. Download free guide, Subscribe'),
                    array('name' => 'language', 'label' => 'Language',      'type' => 'language'),
                ),
                'prompt' => 'Write a powerful blog conclusion in {language} for topic: "{topic}"
Key points covered: {points}
CTA: {cta}
200 words max. Summarize key takeaways, inspire action, include CTA, end with thought-provoking question.',
            ),

            'listicle' => array(
                'label'       => 'Listicle Article',
                'group'       => 'Blog Content',
                'icon'        => 'editor-ol',
                'description' => 'Numbered list article (Top 10, Best 15, etc.)',
                'fields'      => array(
                    array('name' => 'topic',    'label' => 'Listicle Topic *', 'type' => 'text', 'placeholder' => 'e.g. Best WordPress Plugins 2025'),
                    array('name' => 'count',    'label' => 'Number of Items',  'type' => 'select', 'options' => array('5','7','10','15','20','25')),
                    array('name' => 'keywords', 'label' => 'Target Keywords',  'type' => 'text', 'placeholder' => 'e.g. WordPress plugins, best plugins'),
                    array('name' => 'tone',     'label' => 'Tone',             'type' => 'tone'),
                    array('name' => 'language', 'label' => 'Language',         'type' => 'language'),
                ),
                'prompt' => 'Write a listicle article in {language}: "{topic}" with {count} items.
Keywords: {keywords}. Tone: {tone}.

For each item include:
1. Item name as H2
2. Brief description (50-80 words)
3. Key features (3-4 bullet points)
4. Pros and cons
5. Best for / Use case
6. Price/availability if applicable

Add SEO intro (100 words) and conclusion with comparison table suggestion.',
            ),

            'how_to_guide' => array(
                'label'       => 'How-To Guide',
                'group'       => 'Blog Content',
                'icon'        => 'book',
                'description' => 'Step-by-step tutorial or how-to guide',
                'fields'      => array(
                    array('name' => 'topic',    'label' => 'Guide Topic *',   'type' => 'text', 'placeholder' => 'e.g. How to install WordPress on cPanel'),
                    array('name' => 'audience', 'label' => 'Skill Level',     'type' => 'select', 'options' => array('Beginner','Intermediate','Advanced')),
                    array('name' => 'keywords', 'label' => 'Target Keywords', 'type' => 'text', 'placeholder' => 'e.g. install WordPress, cPanel WordPress'),
                    array('name' => 'language', 'label' => 'Language',        'type' => 'language'),
                ),
                'prompt' => 'Write a comprehensive how-to guide in {language} for {audience} level.
Topic: {topic}
Keywords: {keywords}

Include:
1. SEO title with "How to" format
2. Meta description
3. What you will need (prerequisites)
4. Step-by-step instructions (numbered, detailed)
5. Screenshots/image suggestions in [brackets]
6. Pro tips in each step
7. Common mistakes to avoid
8. Troubleshooting section
9. FAQ (5 questions)
10. Next steps / related guides',
            ),

            'comparison_post' => array(
                'label'       => 'Comparison Article',
                'group'       => 'Blog Content',
                'icon'        => 'columns',
                'description' => 'A vs B comparison article',
                'fields'      => array(
                    array('name' => 'item_a',   'label' => 'Item A *',         'type' => 'text', 'placeholder' => 'e.g. Elementor'),
                    array('name' => 'item_b',   'label' => 'Item B *',         'type' => 'text', 'placeholder' => 'e.g. Beaver Builder'),
                    array('name' => 'keywords', 'label' => 'Target Keywords',  'type' => 'text', 'placeholder' => 'e.g. Elementor vs Beaver Builder'),
                    array('name' => 'language', 'label' => 'Language',         'type' => 'language'),
                ),
                'prompt' => 'Write a detailed comparison article in {language}: {item_a} vs {item_b}
Keywords: {keywords}

Include:
1. SEO title: "{item_a} vs {item_b}: Which is Better in 2025?"
2. Quick comparison table (features, pricing, ease of use, performance, support)
3. Overview of each (200 words each)
4. Feature-by-feature comparison (6-8 features)
5. Pricing comparison
6. Pros and cons of each
7. Who should use which
8. Final verdict with recommendation
9. FAQ section',
            ),

            // =====================================================================
            // SEO & RANK MATH
            // =====================================================================
            'meta_description' => array(
                'label'       => 'Meta Description',
                'group'       => 'SEO & Rank Math',
                'icon'        => 'search',
                'description' => 'SEO-optimized meta descriptions for Rank Math',
                'fields'      => array(
                    array('name' => 'page_title', 'label' => 'Page Title *',    'type' => 'text', 'placeholder' => 'e.g. 10 Best WordPress Plugins 2025'),
                    array('name' => 'keyword',    'label' => 'Focus Keyword *', 'type' => 'text', 'placeholder' => 'e.g. WordPress plugins'),
                    array('name' => 'language',   'label' => 'Language',        'type' => 'language'),
                ),
                'prompt' => 'Write 5 SEO meta descriptions in {language} for page: "{page_title}"
Focus keyword: {keyword}

Rules for Rank Math 100% score:
- Exactly 150-155 characters each
- Include focus keyword in first 50 characters
- Include a CTA or benefit
- Use active voice
- Add urgency or curiosity element
- Include year (2025) if relevant

Label: Option 1-5. Show character count for each.',
            ),

            'seo_title' => array(
                'label'       => 'SEO Title Tags',
                'group'       => 'SEO & Rank Math',
                'icon'        => 'tag',
                'description' => 'Click-worthy SEO title tags optimized for Rank Math',
                'fields'      => array(
                    array('name' => 'topic',    'label' => 'Page Topic *',    'type' => 'text', 'placeholder' => 'e.g. Best laptops for students India'),
                    array('name' => 'keyword',  'label' => 'Focus Keyword *', 'type' => 'text', 'placeholder' => 'e.g. best laptops students'),
                    array('name' => 'language', 'label' => 'Language',        'type' => 'language'),
                ),
                'prompt' => 'Write 10 SEO title tags in {language} for: "{topic}"
Keyword: {keyword}.

Rank Math optimization rules:
- 50-60 characters each (show char count)
- Focus keyword at the beginning
- Use power words (Ultimate, Best, Complete, Easy, Free, etc.)
- Include current year where relevant
- Use numbers where possible
- Mix formats: How-to, Listicle, Question, Statement
Number 1-10.',
            ),

            'rankmath_full_seo' => array(
                'label'       => 'Rank Math Full SEO Package',
                'group'       => 'SEO & Rank Math',
                'icon'        => 'chart-line',
                'description' => 'Complete Rank Math 100% score SEO package for any post',
                'fields'      => array(
                    array('name' => 'topic',    'label' => 'Post Topic *',     'type' => 'text', 'placeholder' => 'e.g. How to Speed Up WordPress'),
                    array('name' => 'keyword',  'label' => 'Focus Keyword *',  'type' => 'text', 'placeholder' => 'e.g. speed up WordPress'),
                    array('name' => 'language', 'label' => 'Language',         'type' => 'language'),
                ),
                'prompt' => 'You are an expert Rank Math SEO consultant. Create a COMPLETE SEO package in {language} for achieving 100/100 Rank Math score.

Topic: {topic}
Focus Keyword: {keyword}

Generate ALL of the following:

1. SEO TITLE (50-60 chars, keyword at start)
2. META DESCRIPTION (150-155 chars, keyword in first 50 chars, CTA)
3. URL SLUG (short, keyword-focused, hyphenated)
4. FOCUS KEYWORD placement plan:
   - In title
   - In first paragraph (first 10%)
   - In at least one H2
   - In meta description
   - In URL
   - In image alt text
   - In last paragraph
5. CONTENT OUTLINE with keyword placement markers
6. 5 INTERNAL LINK suggestions with anchor text
7. 3 EXTERNAL LINK suggestions (authority sites)
8. IMAGE ALT TEXT suggestions (3, include keyword)
9. SCHEMA MARKUP type recommendation
10. SOCIAL MEDIA PREVIEW (OG title + description)

RANK MATH CHECKLIST:
- Focus keyword in SEO title
- Focus keyword in meta description
- Focus keyword in URL
- Focus keyword in first 10% of content
- Focus keyword in subheading (H2/H3)
- Keyword density 1-1.5%
- Content length > 600 words
- Internal links >= 1
- External links >= 1
- Image with alt text containing keyword',
            ),

            'faq_section' => array(
                'label'       => 'FAQ Section (Schema Ready)',
                'group'       => 'SEO & Rank Math',
                'icon'        => 'editor-help',
                'description' => 'FAQ section with schema markup for rich snippets',
                'fields'      => array(
                    array('name' => 'topic',    'label' => 'Topic / Product *', 'type' => 'text', 'placeholder' => 'e.g. WordPress hosting'),
                    array('name' => 'count',    'label' => 'Number of FAQs',    'type' => 'select', 'options' => array('5','7','10','15')),
                    array('name' => 'keyword',  'label' => 'Focus Keyword',     'type' => 'text', 'placeholder' => 'e.g. WordPress hosting'),
                    array('name' => 'language', 'label' => 'Language',          'type' => 'language'),
                ),
                'prompt' => 'Write {count} FAQ questions with detailed answers in {language} about: "{topic}"
Focus Keyword: {keyword}

Rules:
- Use natural, conversational questions (how people actually search)
- Include focus keyword in at least 3 questions
- Answers: 50-100 words each
- Include "People Also Ask" style questions
- Format: Q: ... A: ...
- Also provide the FAQ Schema JSON-LD markup code for Rank Math',
            ),

            'keyword_research' => array(
                'label'       => 'Keyword Research',
                'group'       => 'SEO & Rank Math',
                'icon'        => 'visibility',
                'description' => 'Find related keywords, LSI terms, and long-tail variations',
                'fields'      => array(
                    array('name' => 'seed_keyword', 'label' => 'Seed Keyword *', 'type' => 'text', 'placeholder' => 'e.g. WordPress themes'),
                    array('name' => 'niche',        'label' => 'Niche/Industry',  'type' => 'text', 'placeholder' => 'e.g. Web development, Blogging'),
                    array('name' => 'language',     'label' => 'Language',        'type' => 'language'),
                ),
                'prompt' => 'You are an SEO keyword research expert. For the seed keyword "{seed_keyword}" in the {niche} niche, provide in {language}:

1. PRIMARY KEYWORDS (5) - High search volume
2. LONG-TAIL KEYWORDS (15) - Low competition, specific intent
3. LSI KEYWORDS (10) - Semantically related terms
4. QUESTION KEYWORDS (10) - "How to", "What is", "Why", etc.
5. BUYER INTENT KEYWORDS (5) - "Best", "Review", "Buy", "Price"
6. INFORMATIONAL KEYWORDS (5) - "Guide", "Tutorial", "Learn"
7. LOCAL KEYWORDS (5) - If applicable
8. TRENDING KEYWORDS (5) - Current trends

For each keyword suggest:
- Estimated difficulty (Low/Medium/High)
- Content type recommendation (Blog, Landing page, Product page)
- Search intent (Informational, Commercial, Transactional, Navigational)',
            ),

            'schema_markup' => array(
                'label'       => 'Schema Markup Generator',
                'group'       => 'SEO & Rank Math',
                'icon'        => 'editor-code',
                'description' => 'Generate JSON-LD schema markup for any page type',
                'fields'      => array(
                    array('name' => 'page_type', 'label' => 'Page Type *',     'type' => 'select', 'options' => array('Article','BlogPosting','Product','FAQPage','HowTo','LocalBusiness','Recipe','Event','Course','Review','Person','Organization','BreadcrumbList','VideoObject')),
                    array('name' => 'details',   'label' => 'Page Details *',  'type' => 'textarea', 'placeholder' => 'Provide details about your page...'),
                    array('name' => 'url',        'label' => 'Page URL',       'type' => 'text', 'placeholder' => 'e.g. https://example.com/page'),
                ),
                'prompt' => 'Generate complete JSON-LD schema markup for a {page_type} page.

Details: {details}
URL: {url}

Provide:
1. Complete JSON-LD code (ready to paste in Rank Math custom schema)
2. All required properties filled
3. All recommended properties included
4. Explanation of each field
5. How to add this in Rank Math (step-by-step)',
            ),

            'seo_audit' => array(
                'label'       => 'SEO Audit Checklist',
                'group'       => 'SEO & Rank Math',
                'icon'        => 'yes-alt',
                'description' => 'Complete SEO audit for any URL/page',
                'fields'      => array(
                    array('name' => 'url',     'label' => 'Page URL or Topic *', 'type' => 'text', 'placeholder' => 'e.g. https://example.com or your page topic'),
                    array('name' => 'keyword', 'label' => 'Target Keyword',      'type' => 'text', 'placeholder' => 'e.g. WordPress SEO'),
                    array('name' => 'language','label' => 'Language',             'type' => 'language'),
                ),
                'prompt' => 'Create a comprehensive SEO audit checklist in {language} for: {url}
Target keyword: {keyword}

Cover these areas with specific actionable recommendations:

ON-PAGE SEO:
- Title tag optimization
- Meta description
- Header tags (H1-H6) structure
- Keyword placement and density
- Content quality and length
- Image optimization (alt text, compression, WebP)
- Internal linking
- External linking
- URL structure

TECHNICAL SEO:
- Page speed recommendations
- Mobile responsiveness
- Core Web Vitals
- XML Sitemap
- Robots.txt
- Canonical tags
- SSL/HTTPS
- Structured data

RANK MATH SPECIFIC:
- Rank Math score optimization tips
- Focus keyword settings
- Schema markup recommendations
- Breadcrumb setup
- Redirection suggestions

Rate each item: Good / Needs Improvement / Critical',
            ),

            // =====================================================================
            // DIGITAL MARKETING
            // =====================================================================
            'content_calendar' => array(
                'label'       => 'Content Calendar (30 Days)',
                'group'       => 'Digital Marketing',
                'icon'        => 'calendar-alt',
                'description' => '30-day content calendar with topics and posting schedule',
                'fields'      => array(
                    array('name' => 'niche',     'label' => 'Niche / Industry *', 'type' => 'text', 'placeholder' => 'e.g. WordPress development, Digital marketing'),
                    array('name' => 'platforms', 'label' => 'Platforms',          'type' => 'text', 'placeholder' => 'e.g. Blog, Instagram, YouTube, LinkedIn'),
                    array('name' => 'goals',     'label' => 'Goals',              'type' => 'text', 'placeholder' => 'e.g. Traffic, Leads, Brand awareness'),
                    array('name' => 'language',  'label' => 'Language',           'type' => 'language'),
                ),
                'prompt' => 'Create a 30-day content calendar in {language} for {niche}.
Platforms: {platforms}
Goals: {goals}

For each day provide:
- Day & Date (Day 1, Day 2...)
- Platform (Blog/Social/YouTube/Email)
- Content type (Article, Reel, Story, Post, Video)
- Topic/Title
- Target keyword
- Content brief (2-3 lines)
- Best posting time
- Hashtags (for social media posts)

Include mix of:
- Educational content (40%)
- Engagement content (25%)
- Promotional content (20%)
- User-generated / Community (15%)

Also include weekly themes and monthly goals.',
            ),

            'social_caption' => array(
                'label'       => 'Social Media Caption',
                'group'       => 'Digital Marketing',
                'icon'        => 'share',
                'description' => 'Engaging captions with hashtags for any platform',
                'fields'      => array(
                    array('name' => 'topic',    'label' => 'Topic / Product *', 'type' => 'text', 'placeholder' => 'e.g. New WordPress course launch'),
                    array('name' => 'platform', 'label' => 'Platform',          'type' => 'select', 'options' => array('Instagram','Facebook','Twitter/X','LinkedIn','YouTube','Pinterest','TikTok','Threads')),
                    array('name' => 'tone',     'label' => 'Tone',              'type' => 'tone'),
                    array('name' => 'language', 'label' => 'Language',          'type' => 'language'),
                ),
                'prompt' => 'Write 5 {platform} captions in {language} for: "{topic}"
Tone: {tone}.

Each caption must include:
1. Attention-grabbing hook (first line)
2. Body text (engaging, value-driven)
3. Clear CTA
4. 5-10 relevant hashtags (mix of popular and niche)
5. Emoji usage appropriate for {platform}

Follow {platform}-specific best practices:
- Character limits
- Optimal hashtag count
- Content style
Label each: Caption 1-5',
            ),

            'linkedin_post' => array(
                'label'       => 'LinkedIn Post',
                'group'       => 'Digital Marketing',
                'icon'        => 'businessman',
                'description' => 'Viral professional LinkedIn posts',
                'fields'      => array(
                    array('name' => 'topic',    'label' => 'Topic / Story *', 'type' => 'text', 'placeholder' => 'e.g. Lesson from 5 years of freelancing'),
                    array('name' => 'language', 'label' => 'Language',        'type' => 'language'),
                ),
                'prompt' => 'Write 3 viral LinkedIn posts in {language} about: "{topic}"

LinkedIn viral formula for each:
1. Bold first line (no "I" — start with insight or question)
2. Line break after first line
3. Short paragraphs (1-2 sentences each)
4. Personal story or data point
5. Key insight or lesson
6. Actionable takeaway
7. End with engaging question
8. 3-5 relevant hashtags
9. Target 150-200 words

Label: Version 1, 2, 3',
            ),

            'email_subject' => array(
                'label'       => 'Email Subject Lines',
                'group'       => 'Digital Marketing',
                'icon'        => 'email',
                'description' => 'High open-rate email subject lines',
                'fields'      => array(
                    array('name' => 'product',  'label' => 'Product / Offer *', 'type' => 'text', 'placeholder' => 'e.g. 30% off WordPress course'),
                    array('name' => 'audience', 'label' => 'Audience',          'type' => 'text', 'placeholder' => 'e.g. bloggers, developers'),
                    array('name' => 'language', 'label' => 'Language',          'type' => 'language'),
                ),
                'prompt' => 'Write 15 email subject lines in {language} for: "{product}"
Audience: {audience}. Under 60 chars each.

Categories:
- Curiosity (3): Make them wonder
- Urgency (3): Time-sensitive language
- Benefit (3): What they get
- Question (3): Engage with question
- Personal (3): Feel 1-on-1

Number 1-15 with category label.',
            ),

            'email_body' => array(
                'label'       => 'Email Body',
                'group'       => 'Digital Marketing',
                'icon'        => 'email-alt',
                'description' => 'Complete marketing email with proven framework',
                'fields'      => array(
                    array('name' => 'product',  'label' => 'Product / Goal *',  'type' => 'text', 'placeholder' => 'e.g. Sell WordPress course, 50% off'),
                    array('name' => 'audience', 'label' => 'Audience *',        'type' => 'text', 'placeholder' => 'e.g. existing subscribers'),
                    array('name' => 'tone',     'label' => 'Tone',              'type' => 'tone'),
                    array('name' => 'language', 'label' => 'Language',          'type' => 'language'),
                ),
                'prompt' => 'Write a complete marketing email in {language} for: "{product}"
Audience: {audience}. Tone: {tone}.

Include ALL:
1. Subject line (3 options)
2. Preview text
3. Greeting
4. Opening hook (pain point or story)
5. Problem agitation
6. Solution introduction
7. Benefits (3 bullet points)
8. Social proof / testimonial
9. Offer details
10. CTA button text (3 options)
11. PS line (urgency)
12. Signature

Use AIDA framework (Attention, Interest, Desire, Action).',
            ),

            'email_sequence' => array(
                'label'       => 'Email Sequence (5 Emails)',
                'group'       => 'Digital Marketing',
                'icon'        => 'admin-page',
                'description' => 'Complete 5-email nurture/sales sequence',
                'fields'      => array(
                    array('name' => 'product',  'label' => 'Product / Service *', 'type' => 'text', 'placeholder' => 'e.g. WordPress Development Course'),
                    array('name' => 'audience', 'label' => 'Target Audience *',   'type' => 'text', 'placeholder' => 'e.g. beginner developers'),
                    array('name' => 'goal',     'label' => 'Sequence Goal',       'type' => 'select', 'options' => array('Welcome + Nurture','Product Launch','Abandoned Cart','Re-engagement','Webinar Funnel')),
                    array('name' => 'language', 'label' => 'Language',            'type' => 'language'),
                ),
                'prompt' => 'Create a complete 5-email {goal} sequence in {language}.
Product: {product}
Audience: {audience}

For EACH email provide:
- Email # and purpose
- Send timing (Day 0, Day 1, etc.)
- Subject line (2 options)
- Preview text
- Complete email body
- CTA

Email Structure:
1. Welcome / Introduction (Day 0)
2. Value / Education (Day 1)
3. Case Study / Social Proof (Day 3)
4. Offer / Pitch (Day 5)
5. Last Chance / Urgency (Day 7)',
            ),

            // =====================================================================
            // ADS & SALES
            // =====================================================================
            'facebook_ad' => array(
                'label'       => 'Facebook / Instagram Ad',
                'group'       => 'Ads & Sales',
                'icon'        => 'megaphone',
                'description' => 'Converting ad copy with PAS framework',
                'fields'      => array(
                    array('name' => 'product',  'label' => 'Product / Service *', 'type' => 'text', 'placeholder' => 'e.g. Photography course Rs 999'),
                    array('name' => 'audience', 'label' => 'Target Audience *',   'type' => 'text', 'placeholder' => 'e.g. amateur photographers 20-35'),
                    array('name' => 'offer',    'label' => 'Offer / USP',         'type' => 'text', 'placeholder' => 'e.g. 50% off, only 100 seats'),
                    array('name' => 'language', 'label' => 'Language',            'type' => 'language'),
                ),
                'prompt' => 'Write 3 Facebook/Instagram ad copies in {language}.
Product: {product}. Audience: {audience}. Offer: {offer}.

Each ad version:
1. Primary Text (125 words max, use PAS: Problem-Agitate-Solution)
2. Headline (40 chars max)
3. Description (25 chars max)
4. CTA button suggestion
5. Image/Video description suggestion

Version 1: Pain-point focused
Version 2: Benefit-focused
Version 3: Social proof focused',
            ),

            'google_ad' => array(
                'label'       => 'Google Ads Copy',
                'group'       => 'Ads & Sales',
                'icon'        => 'google',
                'description' => 'Google Search and Display ad copies',
                'fields'      => array(
                    array('name' => 'product',  'label' => 'Product / Service *', 'type' => 'text', 'placeholder' => 'e.g. WordPress development services'),
                    array('name' => 'keywords', 'label' => 'Target Keywords *',   'type' => 'text', 'placeholder' => 'e.g. WordPress developer, hire WordPress'),
                    array('name' => 'usp',      'label' => 'Unique Selling Point', 'type' => 'text', 'placeholder' => 'e.g. 10+ years experience, 500+ sites'),
                    array('name' => 'language', 'label' => 'Language',             'type' => 'language'),
                ),
                'prompt' => 'Write Google Ads copies in {language} for: "{product}"
Keywords: {keywords}. USP: {usp}

Generate 3 Responsive Search Ads:
For EACH ad:
- 15 Headlines (max 30 chars each, include keywords)
- 4 Descriptions (max 90 chars each)
- Display URL paths (2, max 15 chars each)
- Sitelink suggestions (4)
- Callout extensions (4)

Rules:
- Include keyword in at least 5 headlines
- Include CTA in descriptions
- Use numbers and power words
- Include brand/product name',
            ),

            'product_description' => array(
                'label'       => 'Product Description',
                'group'       => 'Ads & Sales',
                'icon'        => 'cart',
                'description' => 'E-commerce product description (WooCommerce ready)',
                'fields'      => array(
                    array('name' => 'product',  'label' => 'Product Name *', 'type' => 'text',     'placeholder' => 'e.g. Wireless Earbuds X200'),
                    array('name' => 'features', 'label' => 'Key Features',   'type' => 'textarea', 'placeholder' => "e.g.\n- 30hr battery\n- ANC noise cancellation"),
                    array('name' => 'audience', 'label' => 'Target Customer','type' => 'text',     'placeholder' => 'e.g. gym-goers, students'),
                    array('name' => 'language', 'label' => 'Language',       'type' => 'language'),
                ),
                'prompt' => 'Write a WooCommerce-optimized product description in {language} for: {product}
Features: {features}. Customer: {audience}.

Include:
1. SEO Product Title
2. Short Description (50 words, benefit-focused)
3. Long Description (200 words):
   - Attention-grabbing headline
   - Benefit-first intro paragraph
   - 5 bullet features (feature -> benefit format)
   - Social proof line
   - Urgency/scarcity line
4. Meta description for SEO
5. 5 relevant product tags
6. Suggested categories',
            ),

            'landing_page' => array(
                'label'       => 'Landing Page Copy',
                'group'       => 'Ads & Sales',
                'icon'        => 'admin-home',
                'description' => 'High-converting landing page copy',
                'fields'      => array(
                    array('name' => 'product',  'label' => 'Product / Offer *',  'type' => 'text', 'placeholder' => 'e.g. WordPress Mastery Course'),
                    array('name' => 'audience', 'label' => 'Target Audience *',  'type' => 'text', 'placeholder' => 'e.g. aspiring web developers'),
                    array('name' => 'price',    'label' => 'Price / Offer',      'type' => 'text', 'placeholder' => 'e.g. Rs 1999, was Rs 4999'),
                    array('name' => 'language', 'label' => 'Language',           'type' => 'language'),
                ),
                'prompt' => 'Write complete landing page copy in {language} for: "{product}"
Audience: {audience}. Price: {price}.

Sections (in order):
1. HERO: Headline (benefit) + Sub-headline + CTA button text
2. PROBLEM: Pain points (3-4)
3. SOLUTION: Your product as the answer
4. FEATURES: 6 key features with benefits
5. SOCIAL PROOF: 3 testimonials
6. HOW IT WORKS: 3 simple steps
7. PRICING: Price with value stack
8. FAQ: 5 common questions
9. FINAL CTA: Urgency-driven closing
10. GUARANTEE: Risk-reversal statement

Use proven copywriting frameworks (AIDA, PAS).',
            ),

            'sales_page' => array(
                'label'       => 'Sales Page / Funnel',
                'group'       => 'Ads & Sales',
                'icon'        => 'money-alt',
                'description' => 'Long-form sales page for products/services',
                'fields'      => array(
                    array('name' => 'product',  'label' => 'Product *',        'type' => 'text', 'placeholder' => 'e.g. Complete PHP & WordPress Course'),
                    array('name' => 'audience', 'label' => 'Target Audience',  'type' => 'text', 'placeholder' => 'e.g. beginners who want to learn coding'),
                    array('name' => 'benefits', 'label' => 'Key Benefits',     'type' => 'textarea', 'placeholder' => 'List 3-5 key benefits...'),
                    array('name' => 'language', 'label' => 'Language',         'type' => 'language'),
                ),
                'prompt' => 'Write a long-form sales page in {language} for: "{product}"
Audience: {audience}. Benefits: {benefits}.

Full sales page structure:
1. Pre-headline (target audience qualifier)
2. Headline (big promise)
3. Sub-headline (how + timeframe)
4. Opening story (paint the pain)
5. Problem agitation (make it worse)
6. Solution reveal
7. Benefits (not features)
8. Curriculum / What you get
9. Bonuses (3)
10. Testimonials (3 detailed)
11. Who this is for / not for
12. Pricing (with value stack: total value vs price)
13. Guarantee
14. Final CTA
15. PS (urgency/scarcity)',
            ),

            // =====================================================================
            // VIDEO CONTENT
            // =====================================================================
            'youtube_script' => array(
                'label'       => 'YouTube Script',
                'group'       => 'Video Content',
                'icon'        => 'video-alt3',
                'description' => 'Complete video script with timestamps and B-roll',
                'fields'      => array(
                    array('name' => 'topic',    'label' => 'Video Topic *',    'type' => 'text', 'placeholder' => 'e.g. How to install WordPress locally'),
                    array('name' => 'duration', 'label' => 'Duration',         'type' => 'select', 'options' => array('5 min','8 min','10 min','15 min','20 min')),
                    array('name' => 'audience', 'label' => 'Target Audience',  'type' => 'text', 'placeholder' => 'e.g. WordPress beginners'),
                    array('name' => 'language', 'label' => 'Language',         'type' => 'language'),
                ),
                'prompt' => 'Write a {duration} YouTube script in {language}.
Topic: {topic}. Audience: {audience}.

Format:
[HOOK 0:00-0:30] - Attention-grabbing opening (problem/question/shocking fact)
[INTRO 0:30-1:00] - Channel intro + what they will learn
[STEP 1] - First main point
[STEP 2] - Second main point
... continue for all steps
[RECAP] - Summary of key points
[OUTRO] - Subscribe CTA + next video teaser

Include:
- Exact dialogue/narration
- [B-ROLL: description] suggestions
- [SCREEN RECORDING: description] notes
- [GRAPHICS: text to show] overlays
- Engagement prompts (like, comment, subscribe)

Conversational tone, as if talking to a friend.',
            ),

            'youtube_description' => array(
                'label'       => 'YouTube Description',
                'group'       => 'Video Content',
                'icon'        => 'media-text',
                'description' => 'SEO-optimized video description with timestamps',
                'fields'      => array(
                    array('name' => 'title',    'label' => 'Video Title *',   'type' => 'text',     'placeholder' => 'e.g. WordPress Tutorial for Beginners 2025'),
                    array('name' => 'topic',    'label' => 'Video Content *', 'type' => 'textarea', 'placeholder' => 'Briefly describe what the video covers...'),
                    array('name' => 'keywords', 'label' => 'Keywords',        'type' => 'text',     'placeholder' => 'e.g. WordPress, tutorial, beginners'),
                    array('name' => 'language', 'label' => 'Language',        'type' => 'language'),
                ),
                'prompt' => 'Write a YouTube description in {language}.
Title: {title}. Content: {topic}. Keywords: {keywords}.

Include:
1. Hook (2 compelling lines above "Show more")
2. Summary (100 words with keywords)
3. Timestamps (8-10 chapters)
4. Resources mentioned (with [LINK] placeholders)
5. About section (50 words)
6. Social media links section
7. 20 relevant hashtags
8. Keywords naturally placed throughout',
            ),

            'video_title_thumbnail' => array(
                'label'       => 'Video Title + Thumbnail Ideas',
                'group'       => 'Video Content',
                'icon'        => 'format-image',
                'description' => 'Click-worthy video titles and thumbnail concepts',
                'fields'      => array(
                    array('name' => 'topic',    'label' => 'Video Topic *',  'type' => 'text', 'placeholder' => 'e.g. WordPress page builder comparison'),
                    array('name' => 'niche',    'label' => 'Channel Niche',  'type' => 'text', 'placeholder' => 'e.g. Web development tutorials'),
                    array('name' => 'language', 'label' => 'Language',       'type' => 'language'),
                ),
                'prompt' => 'Generate 10 click-worthy YouTube title + thumbnail combinations in {language}.
Topic: {topic}. Niche: {niche}.

For each:
1. Title (under 60 chars, curiosity-driven)
2. Thumbnail concept:
   - Text on thumbnail (3-4 words max, large font)
   - Face expression suggestion
   - Background color scheme
   - Visual element/icon
   - Layout description

Mix these title formulas:
- How I... (personal)
- X Things You... (listicle)
- Stop Doing... (contrarian)
- The Truth About... (curiosity)
- I Tried... (experiment)',
            ),

            'reels_script' => array(
                'label'       => 'Reels / Shorts Script',
                'group'       => 'Video Content',
                'icon'        => 'smartphone',
                'description' => 'Instagram Reels / YouTube Shorts / TikTok scripts',
                'fields'      => array(
                    array('name' => 'topic',    'label' => 'Topic *',        'type' => 'text', 'placeholder' => 'e.g. 5 CSS tricks every developer should know'),
                    array('name' => 'platform', 'label' => 'Platform',       'type' => 'select', 'options' => array('Instagram Reels','YouTube Shorts','TikTok','All')),
                    array('name' => 'language', 'label' => 'Language',       'type' => 'language'),
                ),
                'prompt' => 'Write 5 short-form video scripts (30-60 seconds each) in {language} for {platform}.
Topic: {topic}.

For each script:
1. HOOK (first 3 seconds - most important!)
2. Content (value delivery, fast-paced)
3. CTA (follow, like, save, share)
4. On-screen text suggestions
5. Trending audio/music suggestion
6. Caption for posting
7. 10 hashtags

Make them punchy, fast-paced, and value-packed.',
            ),

            // =====================================================================
            // WORDPRESS & ELEMENTOR
            // =====================================================================
            'wp_page_content' => array(
                'label'       => 'WordPress Page Content',
                'group'       => 'WordPress & Elementor',
                'icon'        => 'admin-page',
                'description' => 'Content for WordPress pages (About, Services, Contact, etc.)',
                'fields'      => array(
                    array('name' => 'page_type', 'label' => 'Page Type *',      'type' => 'select', 'options' => array('Home Page','About Us','Services','Contact','Portfolio','Pricing','Team','Testimonials','Privacy Policy','Terms of Service')),
                    array('name' => 'business',  'label' => 'Business Name *',  'type' => 'text', 'placeholder' => 'e.g. TechNova Solutions'),
                    array('name' => 'industry',  'label' => 'Industry',         'type' => 'text', 'placeholder' => 'e.g. Web development, Digital marketing'),
                    array('name' => 'language',  'label' => 'Language',         'type' => 'language'),
                ),
                'prompt' => 'Write complete {page_type} page content in {language} for {business}.
Industry: {industry}.

Include:
1. SEO title and meta description
2. Hero section copy (headline + sub-headline + CTA)
3. All sections with headings and body text
4. Call-to-action sections
5. Trust signals
6. Elementor section layout suggestions in [brackets]

Make it professional, conversion-focused, and SEO-optimized.
Suggest Elementor widgets to use for each section.',
            ),

            'elementor_layout' => array(
                'label'       => 'Elementor Page Layout Plan',
                'group'       => 'WordPress & Elementor',
                'icon'        => 'editor-table',
                'description' => 'Detailed Elementor page layout with widgets and settings',
                'fields'      => array(
                    array('name' => 'page_type', 'label' => 'Page Type *',  'type' => 'select', 'options' => array('Homepage','Landing Page','Sales Page','Portfolio','Blog Archive','Single Post','WooCommerce Shop','Service Page','About Page','Contact Page')),
                    array('name' => 'style',     'label' => 'Design Style', 'type' => 'select', 'options' => array('Modern Minimal','Bold & Colorful','Corporate Professional','Creative Agency','Dark Theme','Soft & Clean')),
                    array('name' => 'language',  'label' => 'Language',     'type' => 'language'),
                ),
                'prompt' => 'Create a detailed Elementor page layout plan in {language} for a {page_type}.
Design Style: {style}

For EACH section provide:
1. Section name and purpose
2. Layout (Full width / Boxed)
3. Columns structure (e.g., 1/2 + 1/2, 1/3 + 1/3 + 1/3)
4. Background (color hex code / gradient / image)
5. Widgets to use:
   - Widget name
   - Content
   - Typography settings (font, size, weight)
   - Color settings
   - Spacing (padding/margin)
   - Animation suggestion
6. Responsive adjustments (tablet/mobile)

Suggest 8-12 sections.
Include Elementor Pro widgets where applicable.
Add CSS snippets for custom effects.',
            ),

            'elementor_css' => array(
                'label'       => 'Elementor Custom CSS',
                'group'       => 'WordPress & Elementor',
                'icon'        => 'editor-code',
                'description' => 'Custom CSS snippets for Elementor designs',
                'fields'      => array(
                    array('name' => 'effect',   'label' => 'Desired Effect *', 'type' => 'text', 'placeholder' => 'e.g. Glassmorphism cards, Gradient text, Hover animations'),
                    array('name' => 'element',  'label' => 'Element Type',     'type' => 'select', 'options' => array('Section/Container','Heading','Button','Image','Card/Box','Navigation','Footer','Hero Section','Testimonial','Pricing Table','Form','Custom')),
                ),
                'prompt' => 'Write custom CSS code for Elementor to achieve: "{effect}" on {element}.

Provide:
1. The CSS code (clean, commented)
2. Where to paste it in Elementor (Custom CSS field or Additional CSS)
3. Which Elementor widget/section to apply it to
4. Step-by-step instructions to implement
5. Responsive media query adjustments
6. Before/after description of the effect
7. Browser compatibility notes

Make sure CSS works with Elementor class naming conventions.',
            ),

            'wp_plugin_recommendation' => array(
                'label'       => 'WordPress Plugin Recommendation',
                'group'       => 'WordPress & Elementor',
                'icon'        => 'admin-plugins',
                'description' => 'Get expert plugin recommendations for any WordPress need',
                'fields'      => array(
                    array('name' => 'need',     'label' => 'What do you need? *', 'type' => 'text', 'placeholder' => 'e.g. SEO optimization, form builder, caching, security'),
                    array('name' => 'budget',   'label' => 'Budget',              'type' => 'select', 'options' => array('Free only','Under $50/yr','Under $100/yr','No limit')),
                    array('name' => 'language', 'label' => 'Language',            'type' => 'language'),
                ),
                'prompt' => 'As a WordPress expert who knows 500+ plugins, recommend the best plugins in {language} for: "{need}"
Budget: {budget}

For each recommendation (provide 5 options):
1. Plugin name
2. Free / Premium / Freemium
3. Price (if premium)
4. Key features (5 bullet points)
5. Pros (3)
6. Cons (2)
7. Best for (use case)
8. Alternative plugins
9. Compatibility notes (Elementor, WooCommerce, etc.)
10. Installation & setup tips

Rank them: Best Overall, Best Free, Best Value, Most Features, Easiest to Use.',
            ),

            'wp_speed_optimization' => array(
                'label'       => 'WordPress Speed Optimization Guide',
                'group'       => 'WordPress & Elementor',
                'icon'        => 'performance',
                'description' => 'Complete speed optimization plan for WordPress',
                'fields'      => array(
                    array('name' => 'site_type', 'label' => 'Site Type *', 'type' => 'select', 'options' => array('Blog','WooCommerce Store','Business Website','Portfolio','Membership Site','LMS / Course Site','News / Magazine')),
                    array('name' => 'builder',   'label' => 'Page Builder', 'type' => 'select', 'options' => array('Elementor','Gutenberg','Divi','Beaver Builder','No builder','Other')),
                    array('name' => 'language',  'label' => 'Language',     'type' => 'language'),
                ),
                'prompt' => 'Create a complete WordPress speed optimization guide in {language} for a {site_type} using {builder}.

Cover ALL areas:

1. HOSTING Optimization
   - Recommended hosting providers
   - Server configuration tips

2. CACHING Setup
   - Page caching plugin recommendation
   - Browser caching
   - Object caching (Redis/Memcached)

3. IMAGE Optimization
   - Compression plugins
   - WebP conversion
   - Lazy loading
   - Proper sizing

4. CSS/JS Optimization
   - Minification
   - Combining files
   - Defer/async loading
   - Remove unused CSS

5. DATABASE Optimization
   - Cleanup plugins
   - Post revisions limit
   - Transients cleanup

6. CDN Setup
   - Cloudflare setup guide
   - CDN configuration

7. {builder}-SPECIFIC Tips
   - Builder-specific optimization
   - Widget optimization
   - Template optimization

8. CORE WEB VITALS
   - LCP optimization
   - FID/INP optimization
   - CLS optimization

9. PLUGINS to use (with settings)
10. Step-by-step implementation order',
            ),

            // =====================================================================
            // WEB DEVELOPMENT
            // =====================================================================
            'php_function' => array(
                'label'       => 'PHP Function / Code',
                'group'       => 'Web Development',
                'icon'        => 'editor-code',
                'description' => 'Generate PHP functions for WordPress and general use',
                'fields'      => array(
                    array('name' => 'task',     'label' => 'What should it do? *', 'type' => 'textarea', 'placeholder' => 'e.g. Create a custom post type for portfolio items with taxonomy'),
                    array('name' => 'context',  'label' => 'Context',              'type' => 'select', 'options' => array('WordPress Plugin','WordPress Theme (functions.php)','Custom PHP Script','WooCommerce','WordPress REST API','General PHP')),
                ),
                'prompt' => 'Write clean, well-documented PHP code for: {task}
Context: {context}

Requirements:
1. Follow WordPress coding standards (if WordPress context)
2. Include proper sanitization and validation
3. Use prepared statements for any database queries
4. Add PHPDoc comments
5. Include error handling
6. Provide usage example
7. Security best practices applied
8. Explain each major block with inline comments

Output format:
- Complete code (ready to use)
- Installation/usage instructions
- Customization notes',
            ),

            'html_css_component' => array(
                'label'       => 'HTML/CSS Component',
                'group'       => 'Web Development',
                'icon'        => 'editor-code',
                'description' => 'Generate responsive HTML/CSS components',
                'fields'      => array(
                    array('name' => 'component', 'label' => 'Component Type *', 'type' => 'select', 'options' => array('Navigation Bar','Hero Section','Card Grid','Pricing Table','Footer','Contact Form','Testimonial Slider','Feature Section','CTA Section','Team Section','FAQ Accordion','Timeline','Stats Counter','Gallery Grid','Login Form','Custom')),
                    array('name' => 'style',     'label' => 'Design Style',     'type' => 'select', 'options' => array('Modern Minimal','Bootstrap 5','Tailwind CSS','Dark Theme','Glassmorphism','Neumorphism','Gradient','Corporate')),
                    array('name' => 'custom',    'label' => 'Custom Details',   'type' => 'textarea', 'placeholder' => 'Any specific requirements...'),
                ),
                'prompt' => 'Generate a {component} component with {style} style.
Details: {custom}

Provide:
1. Complete HTML code
2. Complete CSS code (responsive)
3. Responsive breakpoints (desktop, tablet, mobile)
4. Hover effects and transitions
5. Accessibility (ARIA labels, semantic HTML)
6. Cross-browser compatibility notes
7. How to integrate in WordPress / Elementor

Make it production-ready, modern, and pixel-perfect.',
            ),

            'python_script' => array(
                'label'       => 'Python Script',
                'group'       => 'Web Development',
                'icon'        => 'editor-code',
                'description' => 'Generate Python scripts for automation, scraping, data processing',
                'fields'      => array(
                    array('name' => 'task',     'label' => 'What should it do? *', 'type' => 'textarea', 'placeholder' => 'e.g. Scrape product prices from a website and save to CSV'),
                    array('name' => 'category', 'label' => 'Category',             'type' => 'select', 'options' => array('Web Scraping','Data Processing','API Integration','File Automation','WordPress REST API','Database','Email Automation','Image Processing','SEO Tool','General')),
                ),
                'prompt' => 'Write a clean Python script for: {task}
Category: {category}

Requirements:
1. Use modern Python (3.9+)
2. Include all necessary imports
3. Proper error handling (try/except)
4. Type hints
5. Docstrings
6. Logging
7. Requirements.txt content
8. Usage examples
9. Configuration via environment variables where needed

Output:
- Complete script code
- requirements.txt
- README with setup instructions
- Usage examples',
            ),

            'wordpress_theme_snippet' => array(
                'label'       => 'WordPress Theme Snippet',
                'group'       => 'Web Development',
                'icon'        => 'admin-appearance',
                'description' => 'Code snippets for WordPress theme customization',
                'fields'      => array(
                    array('name' => 'task',  'label' => 'What do you want to customize? *', 'type' => 'textarea', 'placeholder' => 'e.g. Add custom header with top bar, Custom post loop with pagination'),
                    array('name' => 'where', 'label' => 'Where to add',                     'type' => 'select', 'options' => array('functions.php','header.php','footer.php','single.php','archive.php','page.php','style.css','Custom template','Child theme','Plugin file')),
                ),
                'prompt' => 'Write WordPress theme code for: {task}
File: {where}

Provide:
1. Complete code (WordPress coding standards)
2. Exact file location and placement instructions
3. Any required hooks/filters
4. Enqueue scripts/styles if needed
5. Responsive CSS included
6. Child theme compatibility notes
7. Testing instructions

Follow WordPress best practices:
- Use WordPress functions (not raw PHP for WP tasks)
- Escape output properly
- Use translation functions
- Follow template hierarchy',
            ),

            'rest_api' => array(
                'label'       => 'REST API Endpoint',
                'group'       => 'Web Development',
                'icon'        => 'rest-api',
                'description' => 'Custom WordPress REST API endpoint',
                'fields'      => array(
                    array('name' => 'purpose', 'label' => 'API Purpose *', 'type' => 'textarea', 'placeholder' => 'e.g. Get all products with filters, Create custom form submission endpoint'),
                    array('name' => 'method',  'label' => 'HTTP Method',   'type' => 'select', 'options' => array('GET','POST','PUT','DELETE','GET + POST')),
                    array('name' => 'auth',    'label' => 'Authentication','type' => 'select', 'options' => array('Public (no auth)','Logged in users','Admin only','Custom capability','API Key')),
                ),
                'prompt' => 'Create a WordPress REST API endpoint for: {purpose}
Method: {method}. Auth: {auth}.

Provide complete code:
1. register_rest_route() with proper namespace
2. Callback function with full logic
3. Permission callback
4. Request parameter validation (sanitize + validate)
5. Proper WP_REST_Response
6. Error handling with WP_Error
7. Example API call (curl + JavaScript fetch)
8. Postman collection format

Follow WordPress REST API best practices.',
            ),

            'woocommerce_snippet' => array(
                'label'       => 'WooCommerce Code',
                'group'       => 'Web Development',
                'icon'        => 'cart',
                'description' => 'WooCommerce customization code snippets',
                'fields'      => array(
                    array('name' => 'task',  'label' => 'What to customize? *', 'type' => 'textarea', 'placeholder' => 'e.g. Add custom field to checkout, Modify product price display, Custom order status'),
                    array('name' => 'area',  'label' => 'WooCommerce Area',     'type' => 'select', 'options' => array('Checkout','Cart','Product Page','Shop Page','My Account','Orders','Emails','Shipping','Payment','Coupons','REST API','Admin')),
                ),
                'prompt' => 'Write WooCommerce customization code for: {task}
Area: {area}

Provide:
1. Complete PHP code with proper WooCommerce hooks
2. Placement instructions (functions.php / plugin)
3. Any required JavaScript
4. CSS if needed
5. Database considerations
6. WooCommerce version compatibility notes
7. Testing instructions

Use WooCommerce coding standards and hooks properly.',
            ),

            // =====================================================================
            // GRAPHIC DESIGN
            // =====================================================================
            'image_prompt' => array(
                'label'       => 'AI Image Prompt',
                'group'       => 'Graphic Design',
                'icon'        => 'format-image',
                'description' => 'Generate detailed prompts for AI image generators (DALL-E, Midjourney, Stable Diffusion)',
                'fields'      => array(
                    array('name' => 'concept',    'label' => 'Image Concept *', 'type' => 'text', 'placeholder' => 'e.g. WordPress developer working at desk'),
                    array('name' => 'style',      'label' => 'Art Style',       'type' => 'select', 'options' => array('Photorealistic','Flat Illustration','3D Render','Watercolor','Minimalist','Isometric','Comic/Cartoon','Abstract','Cinematic','Corporate')),
                    array('name' => 'platform',   'label' => 'AI Tool',         'type' => 'select', 'options' => array('Midjourney','DALL-E 3','Stable Diffusion','Leonardo AI','Any')),
                    array('name' => 'use_case',   'label' => 'Use Case',        'type' => 'select', 'options' => array('Blog Featured Image','Social Media Post','Website Banner','Logo Concept','Product Mockup','YouTube Thumbnail','Ad Creative','Icon Set')),
                ),
                'prompt' => 'Generate 5 detailed AI image prompts for {platform}.
Concept: {concept}
Style: {style}
Use: {use_case}

For each prompt include:
1. Main prompt (detailed, specific)
2. Style modifiers
3. Lighting description
4. Color palette suggestion
5. Composition notes
6. Negative prompt (what to exclude)
7. Recommended aspect ratio
8. Recommended settings (if platform-specific)

Format prompts ready to copy-paste into {platform}.',
            ),

            'brand_style_guide' => array(
                'label'       => 'Brand Style Guide',
                'group'       => 'Graphic Design',
                'icon'        => 'art',
                'description' => 'Complete brand style guide for consistent design',
                'fields'      => array(
                    array('name' => 'brand',    'label' => 'Brand Name *',  'type' => 'text', 'placeholder' => 'e.g. TechNova'),
                    array('name' => 'industry', 'label' => 'Industry *',   'type' => 'text', 'placeholder' => 'e.g. Technology, Education'),
                    array('name' => 'vibe',     'label' => 'Brand Personality', 'type' => 'text', 'placeholder' => 'e.g. Modern, Trustworthy, Innovative'),
                    array('name' => 'language', 'label' => 'Language',     'type' => 'language'),
                ),
                'prompt' => 'Create a complete brand style guide in {language} for: {brand}
Industry: {industry}. Personality: {vibe}.

Include:
1. BRAND IDENTITY
   - Mission statement
   - Vision statement
   - Brand values (5)
   - Brand voice & tone guidelines

2. COLOR PALETTE
   - Primary colors (2) with hex codes
   - Secondary colors (3) with hex codes
   - Accent color with hex code
   - Background colors
   - Text colors
   - Color usage rules

3. TYPOGRAPHY
   - Heading font recommendation (Google Fonts)
   - Body font recommendation
   - Font sizes (H1-H6, body, small)
   - Line height and spacing

4. LOGO Usage
   - Logo placement rules
   - Minimum size
   - Clear space
   - Do and dont guidelines

5. IMAGERY Style
   - Photography style
   - Illustration style
   - Icon style

6. SOCIAL MEDIA Templates
   - Post dimensions
   - Story dimensions
   - Profile/cover image specs

7. CSS Variables code for website implementation',
            ),

            'canva_design_guide' => array(
                'label'       => 'Canva Design Guide',
                'group'       => 'Graphic Design',
                'icon'        => 'admin-customizer',
                'description' => 'Step-by-step Canva design instructions',
                'fields'      => array(
                    array('name' => 'design_type', 'label' => 'Design Type *', 'type' => 'select', 'options' => array('Instagram Post','Instagram Story','Facebook Post','YouTube Thumbnail','Blog Banner','Logo','Business Card','Flyer/Poster','Presentation','Infographic','Resume','Email Header')),
                    array('name' => 'topic',       'label' => 'Design Topic *','type' => 'text', 'placeholder' => 'e.g. WordPress course announcement'),
                    array('name' => 'language',    'label' => 'Language',      'type' => 'language'),
                ),
                'prompt' => 'Create a step-by-step Canva design guide in {language} for creating a {design_type}.
Topic: {topic}

Include:
1. Canvas size and template recommendation
2. Step-by-step design process:
   - Background setup
   - Text placement and fonts
   - Image/element placement
   - Color scheme
   - Layout grid
3. Typography recommendations (Canva fonts)
4. Color palette (with hex codes)
5. Elements to use (shapes, icons, frames)
6. Text content for the design
7. Export settings
8. A/B testing suggestions (2 design variations)
9. Where to use the final design
10. Design principles applied',
            ),

            // =====================================================================
            // TOOLS & UTILITIES
            // =====================================================================
            'rewrite' => array(
                'label'       => 'Rewrite / Improve',
                'group'       => 'Tools',
                'icon'        => 'editor-paste-text',
                'description' => 'Rewrite, improve, or transform existing content',
                'fields'      => array(
                    array('name' => 'content', 'label' => 'Your Content *', 'type' => 'textarea', 'placeholder' => 'Paste your content here...'),
                    array('name' => 'goal',    'label' => 'Goal',           'type' => 'select', 'options' => array('Make it SEO-friendly','Make it engaging','Simplify language','Make it professional','Expand it','Shorten it','Fix grammar','Change tone','Add keywords','Make it viral')),
                    array('name' => 'tone',    'label' => 'Tone',           'type' => 'tone'),
                    array('name' => 'language','label' => 'Language',       'type' => 'language'),
                ),
                'prompt' => 'Rewrite this content in {language}. Goal: {goal}. Tone: {tone}.

Original Content:
{content}

Output:
1. Improved version (complete rewrite)
2. Changes made (bullet points)
3. SEO suggestions
4. Readability score estimate (grade level)
5. Word count comparison (original vs new)',
            ),

            'testimonial' => array(
                'label'       => 'Testimonials',
                'group'       => 'Tools',
                'icon'        => 'format-quote',
                'description' => 'Authentic customer testimonials for social proof',
                'fields'      => array(
                    array('name' => 'product', 'label' => 'Product / Service *', 'type' => 'text', 'placeholder' => 'e.g. WordPress SEO course'),
                    array('name' => 'benefit', 'label' => 'Key Result *',        'type' => 'text', 'placeholder' => 'e.g. ranked on page 1 in 2 months'),
                    array('name' => 'language','label' => 'Language',             'type' => 'language'),
                ),
                'prompt' => 'Write 5 genuine customer testimonials in {language} for: "{product}"
Result: {benefit}.

Each testimonial:
- 60-100 words
- Specific result/metric
- Before/after scenario
- Personal touch (name, role, location)
- Star rating
- Different customer personas

Make them authentic, specific, and believable.',
            ),

            'content_brief' => array(
                'label'       => 'Content Brief',
                'group'       => 'Tools',
                'icon'        => 'media-document',
                'description' => 'Detailed content brief for writers',
                'fields'      => array(
                    array('name' => 'topic',    'label' => 'Content Topic *',  'type' => 'text', 'placeholder' => 'e.g. WordPress Security Guide'),
                    array('name' => 'type',     'label' => 'Content Type',     'type' => 'select', 'options' => array('Blog Post','Landing Page','Product Page','Email','Video Script','Social Post','Case Study','White Paper')),
                    array('name' => 'audience', 'label' => 'Target Audience',  'type' => 'text', 'placeholder' => 'e.g. WordPress beginners'),
                    array('name' => 'language', 'label' => 'Language',         'type' => 'language'),
                ),
                'prompt' => 'Create a detailed content brief in {language} for a writer.
Topic: {topic}. Type: {type}. Audience: {audience}.

Include:
1. Working title (3 options)
2. Target keywords (primary + secondary)
3. Search intent
4. Word count recommendation
5. Tone and style guide
6. Outline with H2/H3 structure
7. Key points to cover
8. Statistics/data to include
9. Competitor content analysis (what to improve on)
10. Internal link opportunities
11. CTA suggestions
12. Featured image description
13. Meta title and description
14. Success metrics (traffic, engagement, conversions)',
            ),

            'press_release' => array(
                'label'       => 'Press Release',
                'group'       => 'Tools',
                'icon'        => 'admin-site',
                'description' => 'Professional press release for announcements',
                'fields'      => array(
                    array('name' => 'announcement', 'label' => 'Announcement *', 'type' => 'textarea', 'placeholder' => 'e.g. Launching new WordPress plugin that helps bloggers...'),
                    array('name' => 'company',      'label' => 'Company Name *', 'type' => 'text', 'placeholder' => 'e.g. TechNova Solutions'),
                    array('name' => 'language',     'label' => 'Language',       'type' => 'language'),
                ),
                'prompt' => 'Write a professional press release in {language}.
Company: {company}
Announcement: {announcement}

Format:
1. FOR IMMEDIATE RELEASE header
2. Headline (compelling, newsworthy)
3. Sub-headline
4. Dateline (City, Date)
5. Lead paragraph (who, what, when, where, why)
6. Body (2-3 paragraphs with details)
7. Quote from company spokesperson
8. About [Company] boilerplate
9. Contact information section
10. ### (end mark)

Make it newsworthy, factual, and professional.',
            ),

            'case_study' => array(
                'label'       => 'Case Study',
                'group'       => 'Tools',
                'icon'        => 'analytics',
                'description' => 'Detailed case study for social proof',
                'fields'      => array(
                    array('name' => 'client',   'label' => 'Client / Project *', 'type' => 'text', 'placeholder' => 'e.g. E-commerce store for fashion brand'),
                    array('name' => 'service',  'label' => 'Service Provided *', 'type' => 'text', 'placeholder' => 'e.g. WordPress development + SEO'),
                    array('name' => 'results',  'label' => 'Results Achieved *', 'type' => 'textarea', 'placeholder' => 'e.g. 300% traffic increase, 50% more sales'),
                    array('name' => 'language', 'label' => 'Language',           'type' => 'language'),
                ),
                'prompt' => 'Write a detailed case study in {language}.
Client: {client}. Service: {service}. Results: {results}.

Structure:
1. Title (result-focused)
2. Executive Summary (50 words)
3. Client Background
4. Challenge / Problem
5. Solution / Approach (step-by-step)
6. Implementation Details
7. Results (with metrics, percentages, before/after)
8. Client Testimonial (generated)
9. Key Takeaways
10. CTA (how to get similar results)

Include data visualizations suggestions (charts, graphs) in [brackets].',
            ),

            'newsletter' => array(
                'label'       => 'Newsletter',
                'group'       => 'Tools',
                'icon'        => 'email-alt2',
                'description' => 'Weekly/monthly newsletter content',
                'fields'      => array(
                    array('name' => 'niche',    'label' => 'Newsletter Niche *', 'type' => 'text', 'placeholder' => 'e.g. WordPress tips, Web development'),
                    array('name' => 'topics',   'label' => 'This Week Topics',   'type' => 'textarea', 'placeholder' => 'List 3-5 topics to cover...'),
                    array('name' => 'language', 'label' => 'Language',            'type' => 'language'),
                ),
                'prompt' => 'Write a complete newsletter in {language} for {niche} niche.
Topics to cover: {topics}

Include:
1. Subject line (3 options)
2. Preview text
3. Personal greeting
4. Quick intro (what is in this issue)
5. Main article / Feature story (200 words)
6. Quick tips section (3-5 tips)
7. Tool of the week recommendation
8. Community spotlight / Q&A
9. Resource links
10. CTA
11. Sign-off
12. PS line',
            ),

            // =====================================================================
            // BULK CONTENT
            // =====================================================================
            'bulk_titles' => array(
                'label'       => 'Bulk Blog Titles (50)',
                'group'       => 'Bulk Content',
                'icon'        => 'editor-ol',
                'description' => 'Generate 50 blog post titles for content planning',
                'fields'      => array(
                    array('name' => 'niche',    'label' => 'Niche / Topic *', 'type' => 'text', 'placeholder' => 'e.g. WordPress, Digital Marketing, Python'),
                    array('name' => 'keyword',  'label' => 'Main Keyword',    'type' => 'text', 'placeholder' => 'e.g. WordPress development'),
                    array('name' => 'language', 'label' => 'Language',        'type' => 'language'),
                ),
                'prompt' => 'Generate 50 SEO-optimized blog post titles in {language} for the {niche} niche.
Keyword: {keyword}

Mix these formats:
- How-to (10 titles)
- Listicles (10 titles): "X Best...", "Top X..."
- Questions (10 titles): "Why...", "What...", "How..."
- Comparison (5 titles): "X vs Y"
- Guides (5 titles): "Complete Guide to..."
- Trends (5 titles): "...in 2025"
- Mistakes (5 titles): "X Mistakes..."

Each title should be SEO-friendly (under 60 chars) with target keyword.
Number them 1-50.',
            ),

            'bulk_social_posts' => array(
                'label'       => 'Bulk Social Posts (30)',
                'group'       => 'Bulk Content',
                'icon'        => 'share',
                'description' => '30 social media posts for a month',
                'fields'      => array(
                    array('name' => 'niche',    'label' => 'Niche / Brand *', 'type' => 'text', 'placeholder' => 'e.g. Web development agency'),
                    array('name' => 'platform', 'label' => 'Platform',        'type' => 'select', 'options' => array('Instagram','Facebook','Twitter/X','LinkedIn','Mixed')),
                    array('name' => 'language', 'label' => 'Language',        'type' => 'language'),
                ),
                'prompt' => 'Generate 30 {platform} posts in {language} for {niche} (1 per day for a month).

For each post:
- Day # and content type
- Complete caption/text
- Hashtags (5-10)
- Image/graphic description
- Best time to post

Content mix:
- Educational tips (12 posts)
- Behind-the-scenes (4 posts)
- Client success / testimonials (4 posts)
- Industry news / trends (3 posts)
- Promotional (4 posts)
- Engagement / polls / questions (3 posts)

Number them Day 1-30.',
            ),

            'bulk_product_descriptions' => array(
                'label'       => 'Bulk Product Descriptions',
                'group'       => 'Bulk Content',
                'icon'        => 'cart',
                'description' => 'Generate multiple WooCommerce product descriptions',
                'fields'      => array(
                    array('name' => 'products', 'label' => 'Product List *',  'type' => 'textarea', 'placeholder' => "List products (one per line):\nProduct 1 - brief details\nProduct 2 - brief details"),
                    array('name' => 'category', 'label' => 'Product Category','type' => 'text', 'placeholder' => 'e.g. Electronics, Clothing, Software'),
                    array('name' => 'language', 'label' => 'Language',        'type' => 'language'),
                ),
                'prompt' => 'Write WooCommerce product descriptions in {language} for these products:
{products}
Category: {category}

For EACH product:
1. SEO Product Title
2. Short Description (50 words)
3. Long Description (150 words with bullet features)
4. Meta description
5. Product tags (5)
6. Suggested price positioning

Format each product clearly with separators.',
            ),
        );
    }

    public static function get_tones() {
        return array(
            'professional'  => 'Professional',
            'friendly'      => 'Friendly',
            'casual'        => 'Casual',
            'persuasive'    => 'Persuasive',
            'authoritative' => 'Authoritative',
            'humorous'      => 'Humorous',
            'empathetic'    => 'Empathetic',
            'inspirational' => 'Inspirational',
            'conversational'=> 'Conversational',
            'formal'        => 'Formal',
            'enthusiastic'  => 'Enthusiastic',
            'educational'   => 'Educational',
        );
    }

    public static function get_languages() {
        return array('Hindi','English','Hinglish','Marathi','Bengali','Tamil','Telugu','Gujarati','Punjabi','Urdu','Kannada','Malayalam','Spanish','French','German','Arabic','Japanese','Chinese','Korean','Portuguese','Russian','Italian');
    }

    public static function get_groups_with_icons() {
        return array(
            'Blog Content'           => 'edit',
            'SEO & Rank Math'        => 'chart-line',
            'Digital Marketing'      => 'megaphone',
            'Ads & Sales'            => 'money-alt',
            'Video Content'          => 'video-alt3',
            'WordPress & Elementor'  => 'wordpress',
            'Web Development'        => 'editor-code',
            'Graphic Design'         => 'art',
            'Tools'                  => 'admin-tools',
            'Bulk Content'           => 'editor-ol',
        );
    }

    /**
     * Build final prompt — replace {placeholders} with actual values
     */
    public static function build_prompt($template_key, $fields) {
        $templates = self::get_all();
        if (!isset($templates[$template_key])) return '';

        $prompt = $templates[$template_key]['prompt'];
        if (!is_array($fields)) return $prompt;

        foreach ($fields as $key => $value) {
            $prompt = str_replace('{' . sanitize_key($key) . '}', sanitize_textarea_field((string) $value), $prompt);
        }
        return $prompt;
    }
}
