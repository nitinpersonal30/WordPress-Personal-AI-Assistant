<?php
/**
 * Provider manager — instantiates the active AI provider, supports
 * automatic failover to user-configured fallback providers, and exposes
 * a uniform chat()/chat_stream() interface used by the REST API.
 *
 * Configuration is stored in wp_options under `wpcw_providers`:
 *   array(
 *     'active'   => 'groq',
 *     'fallback' => array('openai', 'anthropic'),
 *     'configs'  => array(
 *        'groq'       => array('api_key' => …, 'model' => …, 'base_url' => …),
 *        'openai'     => array('api_key' => …, 'model' => …),
 *        …
 *     ),
 *   )
 */

if (!defined('ABSPATH')) exit;

class WPCW_Provider_Manager {

    const OPTION = 'wpcw_providers';

    /** @var array<string, WPCW_Provider_Base> */
    private $instances = array();

    public function get_settings_data() {
        $defaults = array(
            'active'   => 'groq',
            'fallback' => array(),
            'configs'  => array(),
        );
        $stored = get_option(self::OPTION, array());
        if (!is_array($stored)) $stored = array();
        $merged = wp_parse_args($stored, $defaults);
        if (!is_array($merged['fallback'])) $merged['fallback'] = array();
        if (!is_array($merged['configs']))  $merged['configs']  = array();

        // Decrypt api_keys before returning.
        foreach ($merged['configs'] as $id => &$cfg) {
            if (isset($cfg['api_key'])) {
                $cfg['api_key'] = WPCW_Encryption::decrypt($cfg['api_key']);
            }
        }
        unset($cfg);
        return $merged;
    }

    public function save_settings_data($data) {
        $data = is_array($data) ? $data : array();
        if (!isset($data['active']))   $data['active']   = 'groq';
        if (!isset($data['fallback'])) $data['fallback'] = array();
        if (!isset($data['configs']))  $data['configs']  = array();

        // Encrypt api_keys before storing.
        foreach ($data['configs'] as $id => &$cfg) {
            if (isset($cfg['api_key']) && '' !== $cfg['api_key'] && !WPCW_Encryption::is_encrypted($cfg['api_key'])) {
                $cfg['api_key'] = WPCW_Encryption::encrypt($cfg['api_key']);
            }
        }
        unset($cfg);
        update_option(self::OPTION, $data, false);
    }

    public function available_providers() {
        return array(
            'groq'       => 'WPCW_Provider_Groq',
            'openai'     => 'WPCW_Provider_OpenAI',
            'anthropic'  => 'WPCW_Provider_Anthropic',
            'gemini'     => 'WPCW_Provider_Gemini',
            'openrouter' => 'WPCW_Provider_OpenRouter',
        );
    }

    public function provider_labels() {
        return array(
            'groq'       => 'Groq Cloud',
            'openai'     => 'OpenAI',
            'anthropic'  => 'Anthropic Claude',
            'gemini'     => 'Google Gemini',
            'openrouter' => 'OpenRouter',
        );
    }

    public function get($id) {
        $id = sanitize_key($id);
        if (isset($this->instances[$id])) return $this->instances[$id];

        $available = $this->available_providers();
        if (!isset($available[$id])) return null;
        $class = $available[$id];
        if (!class_exists($class)) return null;

        $data = $this->get_settings_data();
        $cfg = isset($data['configs'][$id]) && is_array($data['configs'][$id]) ? $data['configs'][$id] : array();
        $cfg = wp_parse_args($cfg, array(
            'api_key'  => '',
            'model'    => '',
            'base_url' => '',
            'timeout'  => 180,
        ));

        $this->instances[$id] = new $class($cfg);
        return $this->instances[$id];
    }

    public function get_active() {
        $data = $this->get_settings_data();
        $tier = class_exists('WPCW_License') ? WPCW_License::get_tier() : 'free';
        $active = $data['active'];

        // Free tier is always pinned to Groq (the default bundled provider).
        if ('free' === $tier) {
            return $this->get('groq');
        }

        $provider = $this->get($active);
        return $provider ? $provider : $this->get('groq');
    }

    public function get_fallback_chain() {
        $data = $this->get_settings_data();
        $tier = class_exists('WPCW_License') ? WPCW_License::get_tier() : 'free';
        if ('free' === $tier) return array();
        $chain = array();
        foreach ((array) $data['fallback'] as $id) {
            $p = $this->get($id);
            if ($p) $chain[] = $p;
        }
        return $chain;
    }

    /**
     * Try the active provider, then each fallback in order. Returns the
     * first successful response (or the last WP_Error if all fail).
     */
    public function chat(array $messages, array $options = array()) {
        $providers = array_filter(array_merge(array($this->get_active()), $this->get_fallback_chain()));
        $last_err = new WP_Error('no_provider', 'No AI provider configured.');
        foreach ($providers as $p) {
            $effective = $options;
            if (empty($effective['model'])) {
                $cfg_model = $p->get_config('model');
                $effective['model'] = $cfg_model ? $cfg_model : $p->default_model();
            }
            $r = $p->chat($messages, $effective);
            if (!is_wp_error($r)) {
                $r['provider'] = $p->id();
                return $r;
            }
            $last_err = $r;
        }
        return $last_err;
    }

    public function chat_stream(array $messages, array $options, $on_token) {
        $p = $this->get_active();
        if (!$p) return new WP_Error('no_provider', 'No AI provider configured.');
        $effective = $options;
        if (empty($effective['model'])) {
            $cfg_model = $p->get_config('model');
            $effective['model'] = $cfg_model ? $cfg_model : $p->default_model();
        }
        $r = $p->chat_stream($messages, $effective, $on_token);
        if (is_wp_error($r)) {
            // Fallback chain — the on_token caller has already emitted partial
            // tokens for the failing attempt, but we still want to retry.
            foreach ($this->get_fallback_chain() as $fb) {
                $effective_fb = $options;
                if (empty($effective_fb['model'])) {
                    $cfg_model = $fb->get_config('model');
                    $effective_fb['model'] = $cfg_model ? $cfg_model : $fb->default_model();
                }
                $r = $fb->chat_stream($messages, $effective_fb, $on_token);
                if (!is_wp_error($r)) {
                    $r['provider'] = $fb->id();
                    return $r;
                }
            }
            return $r;
        }
        $r['provider'] = $p->id();
        return $r;
    }
}
