<?php
/**
 * Encryption helper — AES-256-CBC.
 *
 * Used to store sensitive values (API keys, license keys) at rest in
 * wp_options without leaving them in plain text. Falls back to a hash
 * of the WP_AUTH_KEY constants if the site does not define a custom
 * WPCW_ENCRYPTION_KEY.
 */

if (!defined('ABSPATH')) exit;

class WPCW_Encryption {

    const CIPHER = 'AES-256-CBC';
    const PREFIX = 'wpcw_enc_v1::';

    private static function key() {
        if (defined('WPCW_ENCRYPTION_KEY') && WPCW_ENCRYPTION_KEY) {
            return hash('sha256', WPCW_ENCRYPTION_KEY, true);
        }
        $material = '';
        foreach (array('AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY') as $c) {
            if (defined($c)) $material .= constant($c);
        }
        if ('' === $material) {
            $material = get_option('wpcw_enc_seed');
            if (!$material) {
                $material = wp_generate_password(64, true, true);
                update_option('wpcw_enc_seed', $material, false);
            }
        }
        return hash('sha256', $material, true);
    }

    public static function encrypt($plaintext) {
        if ('' === (string) $plaintext) return '';
        if (!function_exists('openssl_encrypt')) return $plaintext;
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length(self::CIPHER));
        $cipher = openssl_encrypt((string) $plaintext, self::CIPHER, self::key(), OPENSSL_RAW_DATA, $iv);
        if (false === $cipher) return $plaintext;
        return self::PREFIX . base64_encode($iv . $cipher);
    }

    public static function decrypt($value) {
        if (!is_string($value) || '' === $value) return $value;
        if (0 !== strpos($value, self::PREFIX)) {
            return $value; // Not encrypted (legacy plaintext) — return as-is.
        }
        if (!function_exists('openssl_decrypt')) return '';
        $raw = base64_decode(substr($value, strlen(self::PREFIX)), true);
        if (false === $raw) return '';
        $ivlen = openssl_cipher_iv_length(self::CIPHER);
        if (strlen($raw) < $ivlen + 1) return '';
        $iv = substr($raw, 0, $ivlen);
        $cipher = substr($raw, $ivlen);
        $plain = openssl_decrypt($cipher, self::CIPHER, self::key(), OPENSSL_RAW_DATA, $iv);
        return (false === $plain) ? '' : $plain;
    }

    public static function is_encrypted($value) {
        return is_string($value) && 0 === strpos($value, self::PREFIX);
    }
}
