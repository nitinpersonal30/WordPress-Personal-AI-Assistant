<?php
/**
 * Google Gemini provider — uses the Generative Language REST API.
 *
 * Streaming uses :streamGenerateContent which returns a JSON array
 * of candidate chunks; we parse them incrementally.
 */

if (!defined('ABSPATH')) exit;

class WPCW_Provider_Gemini extends WPCW_Provider_Base {

    public function id()    { return 'gemini'; }
    public function label() { return 'Google Gemini'; }

    public function models() {
        return array(
            'gemini-1.5-flash',
            'gemini-1.5-pro',
            'gemini-2.0-flash',
            'gemini-2.0-flash-thinking-exp',
            'gemini-pro',
        );
    }

    public function default_model() { return 'gemini-1.5-flash'; }

    private function base_url() {
        $base = (string) $this->get_config('base_url');
        if ('' === $base) $base = 'https://generativelanguage.googleapis.com/v1beta';
        return rtrim($base, '/');
    }

    private function build_payload(array $messages, array $options) {
        $system = '';
        $contents = array();
        foreach ($messages as $m) {
            if (!is_array($m)) continue;
            $role = isset($m['role']) ? $m['role'] : 'user';
            $text = isset($m['content']) ? (string) $m['content'] : '';
            if ('system' === $role) { $system .= ('' === $system ? '' : "\n\n") . $text; continue; }
            $contents[] = array(
                'role'  => ('assistant' === $role) ? 'model' : 'user',
                'parts' => array(array('text' => $text)),
            );
        }
        $body = array(
            'contents'         => $contents,
            'generationConfig' => array(
                'temperature'     => isset($options['temperature']) ? (float) $options['temperature'] : 0.7,
                'maxOutputTokens' => isset($options['max_tokens']) ? (int) $options['max_tokens'] : 4096,
                'topP'            => isset($options['top_p']) ? (float) $options['top_p'] : 0.9,
            ),
        );
        if ($system) {
            $body['systemInstruction'] = array('parts' => array(array('text' => $system)));
        }
        return $body;
    }

    private function endpoint($model, $stream = false) {
        $action = $stream ? ':streamGenerateContent' : ':generateContent';
        $key = (string) $this->get_config('api_key');
        return $this->base_url() . '/models/' . rawurlencode($model) . $action . '?alt=sse&key=' . rawurlencode($key);
    }

    public function chat(array $messages, array $options = array()) {
        if ('' === (string) $this->get_config('api_key')) {
            return new WP_Error('missing_key', 'Gemini API key not configured.');
        }
        $model = isset($options['model']) ? $options['model'] : $this->default_model();
        $body  = $this->build_payload($messages, $options);
        $r = wp_remote_post($this->endpoint($model, false), array(
            'timeout' => isset($this->config['timeout']) ? (int) $this->config['timeout'] : 180,
            'headers' => array('Content-Type' => 'application/json'),
            'body'    => wp_json_encode($body),
        ));
        if (is_wp_error($r)) return $r;
        $code = (int) wp_remote_retrieve_response_code($r);
        $data = json_decode(wp_remote_retrieve_body($r), true);
        if (200 !== $code) {
            $msg = isset($data['error']['message']) ? $data['error']['message'] : ('Gemini API error (HTTP ' . $code . ').');
            return new WP_Error('gemini_error', $msg);
        }
        $content = '';
        if (isset($data['candidates'][0]['content']['parts']) && is_array($data['candidates'][0]['content']['parts'])) {
            foreach ($data['candidates'][0]['content']['parts'] as $p) {
                if (isset($p['text'])) $content .= $p['text'];
            }
        }
        return array(
            'content'    => $content,
            'tokens_in'  => isset($data['usageMetadata']['promptTokenCount']) ? (int) $data['usageMetadata']['promptTokenCount'] : 0,
            'tokens_out' => isset($data['usageMetadata']['candidatesTokenCount']) ? (int) $data['usageMetadata']['candidatesTokenCount'] : 0,
            'model'      => $model,
        );
    }

    public function chat_stream(array $messages, array $options, $on_token) {
        if ('' === (string) $this->get_config('api_key')) {
            return new WP_Error('missing_key', 'Gemini API key not configured.');
        }
        if (!function_exists('curl_init')) {
            return new WP_Error('curl_missing', 'PHP cURL is required for streaming.');
        }
        $model = isset($options['model']) ? $options['model'] : $this->default_model();
        $body  = $this->build_payload($messages, $options);

        $aggregate = '';
        $sse_buffer = '';
        $stream_done = false;
        $tokens_in = 0; $tokens_out = 0;

        $ch = curl_init($this->endpoint($model, true));
        curl_setopt_array($ch, array(
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => wp_json_encode($body),
            CURLOPT_HTTPHEADER     => array('Content-Type: application/json', 'Accept: text/event-stream'),
            CURLOPT_TIMEOUT        => isset($this->config['timeout']) ? (int) $this->config['timeout'] : 180,
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_WRITEFUNCTION  => function ($curl, $chunk) use (&$sse_buffer, &$stream_done, &$aggregate, &$tokens_in, &$tokens_out, $on_token) {
                $sse_buffer .= $chunk;
                while (false !== ($nl = strpos($sse_buffer, "\n"))) {
                    $line = trim(substr($sse_buffer, 0, $nl));
                    $sse_buffer = substr($sse_buffer, $nl + 1);
                    if ('' === $line || 0 !== strpos($line, 'data:')) continue;
                    $payload = trim(substr($line, 5));
                    $obj = json_decode($payload, true);
                    if (!is_array($obj)) continue;
                    if (isset($obj['candidates'][0]['content']['parts']) && is_array($obj['candidates'][0]['content']['parts'])) {
                        foreach ($obj['candidates'][0]['content']['parts'] as $p) {
                            if (isset($p['text']) && '' !== $p['text']) {
                                $aggregate .= $p['text'];
                                if (is_callable($on_token)) call_user_func($on_token, $p['text'], false);
                            }
                        }
                    }
                    if (isset($obj['usageMetadata']['promptTokenCount']))     $tokens_in  = (int) $obj['usageMetadata']['promptTokenCount'];
                    if (isset($obj['usageMetadata']['candidatesTokenCount'])) $tokens_out = (int) $obj['usageMetadata']['candidatesTokenCount'];
                    if (isset($obj['candidates'][0]['finishReason']) && '' !== $obj['candidates'][0]['finishReason']) {
                        if (is_callable($on_token)) call_user_func($on_token, '', true);
                        $stream_done = true;
                        return 0;
                    }
                }
                return strlen($chunk);
            },
        ));
        curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        if (!$stream_done) {
            if ($err) return new WP_Error('stream_error', $err);
            if (is_callable($on_token)) call_user_func($on_token, '', true);
        }
        return array(
            'content'    => $aggregate,
            'tokens_in'  => $tokens_in,
            'tokens_out' => $tokens_out,
            'model'      => $model,
        );
    }

    public function estimate_cost($tokens_in, $tokens_out, $model = '') {
        $rates = array(
            'gemini-1.5-flash' => array(0.075, 0.30),
            'gemini-1.5-pro'   => array(1.25,  5.00),
            'gemini-2.0-flash' => array(0.10,  0.40),
            'gemini-pro'       => array(0.50,  1.50),
        );
        $rate = isset($rates[$model]) ? $rates[$model] : array(0.50, 1.50);
        return ($tokens_in / 1e6) * $rate[0] + ($tokens_out / 1e6) * $rate[1];
    }
}
