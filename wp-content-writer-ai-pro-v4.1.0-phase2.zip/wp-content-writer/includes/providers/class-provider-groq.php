<?php
/**
 * Groq Cloud provider — OpenAI-compatible streaming chat completions.
 */

if (!defined('ABSPATH')) exit;

class WPCW_Provider_Groq extends WPCW_Provider_Base {

    public function id()     { return 'groq'; }
    public function label()  { return 'Groq Cloud'; }

    public function models() {
        return array(
            'llama-3.1-8b-instant',
            'llama-3.3-70b-versatile',
            'llama3-8b-8192',
            'llama3-70b-8192',
            'mixtral-8x7b-32768',
            'gemma2-9b-it',
            'deepseek-r1-distill-llama-70b',
            'qwen-2.5-32b',
            'kimi-k2-instruct',
            'gpt-oss-20b',
            'meta-llama/llama-4-scout-17b-16e-instruct',
        );
    }

    public function default_model() {
        return 'llama-3.1-8b-instant';
    }

    private function base_url() {
        $base = (string) $this->get_config('base_url');
        if ('' === $base) $base = 'https://api.groq.com/openai/v1';
        return rtrim($base, '/');
    }

    private function headers($accept = 'application/json') {
        $key = (string) $this->get_config('api_key');
        $h = array(
            'Content-Type'  => 'application/json',
            'Accept'        => $accept,
            'Authorization' => 'Bearer ' . $key,
        );
        $host = trim((string) $this->get_config('host_header'));
        if ($host) $h['Host'] = $host;
        return $h;
    }

    public function chat(array $messages, array $options = array()) {
        if ('' === (string) $this->get_config('api_key')) {
            return new WP_Error('missing_key', 'Groq API key not configured.');
        }
        $body = array(
            'model'       => isset($options['model']) ? $options['model'] : $this->default_model(),
            'messages'    => $messages,
            'stream'      => false,
            'temperature' => isset($options['temperature']) ? (float) $options['temperature'] : 0.7,
            'top_p'       => isset($options['top_p']) ? (float) $options['top_p'] : 0.9,
            'max_tokens'  => isset($options['max_tokens']) ? (int) $options['max_tokens'] : 4096,
        );
        $r = wp_remote_post($this->base_url() . '/chat/completions', array(
            'timeout' => isset($this->config['timeout']) ? (int) $this->config['timeout'] : 180,
            'headers' => $this->headers(),
            'body'    => wp_json_encode($body),
        ));
        if (is_wp_error($r)) return $r;
        $data = json_decode(wp_remote_retrieve_body($r), true);
        $code = (int) wp_remote_retrieve_response_code($r);
        $content = $this->extract_openai_content($data);
        if (200 !== $code || null === $content) {
            $msg = isset($data['error']['message']) ? $data['error']['message'] : ('Groq API error (HTTP ' . $code . ').');
            return new WP_Error('groq_error', $msg);
        }
        return array(
            'content'    => $content,
            'tokens_in'  => isset($data['usage']['prompt_tokens']) ? (int) $data['usage']['prompt_tokens'] : 0,
            'tokens_out' => isset($data['usage']['completion_tokens']) ? (int) $data['usage']['completion_tokens'] : 0,
            'model'      => $body['model'],
        );
    }

    public function chat_stream(array $messages, array $options, $on_token) {
        if ('' === (string) $this->get_config('api_key')) {
            return new WP_Error('missing_key', 'Groq API key not configured.');
        }
        $body = array(
            'model'       => isset($options['model']) ? $options['model'] : $this->default_model(),
            'messages'    => $messages,
            'stream'      => true,
            'temperature' => isset($options['temperature']) ? (float) $options['temperature'] : 0.7,
            'top_p'       => isset($options['top_p']) ? (float) $options['top_p'] : 0.9,
            'max_tokens'  => isset($options['max_tokens']) ? (int) $options['max_tokens'] : 4096,
        );
        $headers = array(
            'Content-Type: application/json',
            'Accept: text/event-stream',
            'Authorization: Bearer ' . (string) $this->get_config('api_key'),
        );
        $host = trim((string) $this->get_config('host_header'));
        if ($host) $headers[] = 'Host: ' . $host;
        return $this->stream_openai_compatible($this->base_url() . '/chat/completions', $headers, $body, $on_token);
    }

    public function estimate_cost($tokens_in, $tokens_out, $model = '') {
        // Groq pricing (USD per 1M tokens, approximate; updated 2025).
        $rates = array(
            'llama-3.1-8b-instant'    => array(0.05, 0.08),
            'llama-3.3-70b-versatile' => array(0.59, 0.79),
            'llama3-8b-8192'          => array(0.05, 0.08),
            'llama3-70b-8192'         => array(0.59, 0.79),
            'mixtral-8x7b-32768'      => array(0.24, 0.24),
        );
        $rate = isset($rates[$model]) ? $rates[$model] : array(0.10, 0.20);
        return ($tokens_in / 1e6) * $rate[0] + ($tokens_out / 1e6) * $rate[1];
    }
}
