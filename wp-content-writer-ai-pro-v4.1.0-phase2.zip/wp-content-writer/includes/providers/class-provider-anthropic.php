<?php
/**
 * Anthropic Claude provider — translates OpenAI-style messages into the
 * /v1/messages API. Streaming uses Anthropic's SSE event format.
 */

if (!defined('ABSPATH')) exit;

class WPCW_Provider_Anthropic extends WPCW_Provider_Base {

    public function id()    { return 'anthropic'; }
    public function label() { return 'Anthropic Claude'; }

    public function models() {
        return array(
            'claude-3-5-sonnet-20241022',
            'claude-3-5-haiku-20241022',
            'claude-3-opus-20240229',
            'claude-3-sonnet-20240229',
            'claude-3-haiku-20240307',
        );
    }

    public function default_model() { return 'claude-3-5-haiku-20241022'; }

    private function base_url() {
        $base = (string) $this->get_config('base_url');
        if ('' === $base) $base = 'https://api.anthropic.com/v1';
        return rtrim($base, '/');
    }

    private function split_messages(array $messages) {
        $system = '';
        $turns  = array();
        foreach ($messages as $m) {
            if (!is_array($m)) continue;
            $role = isset($m['role']) ? $m['role'] : 'user';
            $content = isset($m['content']) ? (string) $m['content'] : '';
            if ('system' === $role) {
                $system .= ('' === $system ? '' : "\n\n") . $content;
            } else {
                $turns[] = array('role' => $role, 'content' => $content);
            }
        }
        return array($system, $turns);
    }

    private function headers() {
        return array(
            'Content-Type'      => 'application/json',
            'x-api-key'         => (string) $this->get_config('api_key'),
            'anthropic-version' => '2023-06-01',
        );
    }

    public function chat(array $messages, array $options = array()) {
        if ('' === (string) $this->get_config('api_key')) {
            return new WP_Error('missing_key', 'Anthropic API key not configured.');
        }
        list($system, $turns) = $this->split_messages($messages);
        $body = array(
            'model'       => isset($options['model']) ? $options['model'] : $this->default_model(),
            'messages'    => $turns,
            'max_tokens'  => isset($options['max_tokens']) ? (int) $options['max_tokens'] : 4096,
            'temperature' => isset($options['temperature']) ? (float) $options['temperature'] : 0.7,
        );
        if ($system) $body['system'] = $system;

        $r = wp_remote_post($this->base_url() . '/messages', array(
            'timeout' => isset($this->config['timeout']) ? (int) $this->config['timeout'] : 180,
            'headers' => $this->headers(),
            'body'    => wp_json_encode($body),
        ));
        if (is_wp_error($r)) return $r;
        $data = json_decode(wp_remote_retrieve_body($r), true);
        $code = (int) wp_remote_retrieve_response_code($r);
        if (200 !== $code) {
            $msg = isset($data['error']['message']) ? $data['error']['message'] : ('Anthropic API error (HTTP ' . $code . ').');
            return new WP_Error('anthropic_error', $msg);
        }
        $content = '';
        if (isset($data['content']) && is_array($data['content'])) {
            foreach ($data['content'] as $block) {
                if (isset($block['type']) && 'text' === $block['type'] && isset($block['text'])) {
                    $content .= $block['text'];
                }
            }
        }
        return array(
            'content'    => $content,
            'tokens_in'  => isset($data['usage']['input_tokens']) ? (int) $data['usage']['input_tokens'] : 0,
            'tokens_out' => isset($data['usage']['output_tokens']) ? (int) $data['usage']['output_tokens'] : 0,
            'model'      => $body['model'],
        );
    }

    public function chat_stream(array $messages, array $options, $on_token) {
        if ('' === (string) $this->get_config('api_key')) {
            return new WP_Error('missing_key', 'Anthropic API key not configured.');
        }
        if (!function_exists('curl_init')) {
            return new WP_Error('curl_missing', 'PHP cURL is required for streaming.');
        }
        list($system, $turns) = $this->split_messages($messages);
        $body = array(
            'model'       => isset($options['model']) ? $options['model'] : $this->default_model(),
            'messages'    => $turns,
            'max_tokens'  => isset($options['max_tokens']) ? (int) $options['max_tokens'] : 4096,
            'temperature' => isset($options['temperature']) ? (float) $options['temperature'] : 0.7,
            'stream'      => true,
        );
        if ($system) $body['system'] = $system;

        $headers = array(
            'Content-Type: application/json',
            'Accept: text/event-stream',
            'x-api-key: ' . (string) $this->get_config('api_key'),
            'anthropic-version: 2023-06-01',
        );

        $aggregate = '';
        $sse_buffer = '';
        $stream_done = false;
        $tokens_in = 0; $tokens_out = 0;

        $ch = curl_init($this->base_url() . '/messages');
        curl_setopt_array($ch, array(
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => wp_json_encode($body),
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_TIMEOUT        => isset($this->config['timeout']) ? (int) $this->config['timeout'] : 180,
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_WRITEFUNCTION  => function ($curl, $chunk) use (&$sse_buffer, &$stream_done, &$aggregate, &$tokens_in, &$tokens_out, $on_token) {
                $sse_buffer .= $chunk;
                while (false !== ($nl = strpos($sse_buffer, "\n"))) {
                    $line = trim(substr($sse_buffer, 0, $nl));
                    $sse_buffer = substr($sse_buffer, $nl + 1);
                    if ('' === $line || 0 !== strpos($line, 'data:')) continue;
                    $payload = trim(substr($line, 5));
                    $obj = json_decode($payload, true);
                    if (!is_array($obj)) continue;
                    $type = isset($obj['type']) ? $obj['type'] : '';
                    if ('content_block_delta' === $type && isset($obj['delta']['text'])) {
                        $token = (string) $obj['delta']['text'];
                        $aggregate .= $token;
                        if (is_callable($on_token)) call_user_func($on_token, $token, false);
                    } elseif ('message_delta' === $type && isset($obj['usage']['output_tokens'])) {
                        $tokens_out = (int) $obj['usage']['output_tokens'];
                    } elseif ('message_start' === $type && isset($obj['message']['usage']['input_tokens'])) {
                        $tokens_in = (int) $obj['message']['usage']['input_tokens'];
                    } elseif ('message_stop' === $type) {
                        if (is_callable($on_token)) call_user_func($on_token, '', true);
                        $stream_done = true;
                        return 0;
                    }
                }
                return strlen($chunk);
            },
        ));
        curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        if (!$stream_done) {
            if ($err) return new WP_Error('stream_error', $err);
            if (is_callable($on_token)) call_user_func($on_token, '', true);
        }
        return array(
            'content'    => $aggregate,
            'tokens_in'  => $tokens_in,
            'tokens_out' => $tokens_out,
            'model'      => $body['model'],
        );
    }

    public function estimate_cost($tokens_in, $tokens_out, $model = '') {
        $rates = array(
            'claude-3-5-sonnet-20241022' => array(3.00, 15.00),
            'claude-3-5-haiku-20241022'  => array(0.80,  4.00),
            'claude-3-opus-20240229'     => array(15.00, 75.00),
            'claude-3-sonnet-20240229'   => array(3.00, 15.00),
            'claude-3-haiku-20240307'    => array(0.25,  1.25),
        );
        $rate = isset($rates[$model]) ? $rates[$model] : array(1.0, 5.0);
        return ($tokens_in / 1e6) * $rate[0] + ($tokens_out / 1e6) * $rate[1];
    }
}
