<?php
/**
 * Abstract base for AI providers. Each concrete driver translates the
 * common chat() / chat_stream() calls into the vendor-specific HTTP
 * payload + parses the response.
 *
 * Streaming uses a writer callback so the WordPress REST handler can
 * forward Server-Sent Events to the browser without buffering the whole
 * response in memory.
 */

if (!defined('ABSPATH')) exit;

abstract class WPCW_Provider_Base {

    /** @var array Provider configuration (api_key, base_url, model, etc.) */
    protected $config;

    public function __construct(array $config) {
        $this->config = $config;
    }

    /** Short identifier (groq, openai, anthropic, gemini, openrouter). */
    abstract public function id();

    /** Human-readable display name. */
    abstract public function label();

    /** List of supported model identifiers (string[]). */
    abstract public function models();

    /** Default model used when the user has not picked one. */
    abstract public function default_model();

    /**
     * Non-streaming chat completion.
     *
     * @param array $messages [['role' => 'system|user|assistant', 'content' => '…']]
     * @param array $options  ['model' => …, 'temperature' => …, 'max_tokens' => …]
     * @return array|WP_Error ['content' => string, 'tokens_in' => int, 'tokens_out' => int, 'model' => string]
     */
    abstract public function chat(array $messages, array $options = array());

    /**
     * Streaming chat completion. The $on_token callback receives partial
     * token strings; $on_done is called once with the final aggregated text.
     *
     * @return array|WP_Error ['content' => string, 'tokens_in' => int, 'tokens_out' => int, 'model' => string]
     */
    abstract public function chat_stream(array $messages, array $options, $on_token);

    /** Health check — returns bool. */
    public function ping() {
        $r = $this->chat(array(
            array('role' => 'user', 'content' => 'ping'),
        ), array('max_tokens' => 1));
        return !is_wp_error($r);
    }

    public function get_config($key, $default = '') {
        return isset($this->config[$key]) ? $this->config[$key] : $default;
    }

    /**
     * Best-effort cost estimate (USD) per 1k input + output tokens.
     * Override in subclasses with vendor pricing.
     */
    public function estimate_cost($tokens_in, $tokens_out, $model = '') {
        return 0.0;
    }

    /** Helper — pull "content" out of an OpenAI-style chat completion. */
    protected function extract_openai_content($data) {
        if (!is_array($data)) return null;
        if (isset($data['choices'][0]['message']['content'])) return (string) $data['choices'][0]['message']['content'];
        if (isset($data['choices'][0]['text']))               return (string) $data['choices'][0]['text'];
        return null;
    }

    /**
     * Run a streaming HTTP POST and feed each parsed SSE token to the callback.
     * Used by all OpenAI-compatible providers (Groq, OpenAI, OpenRouter).
     */
    protected function stream_openai_compatible($endpoint, $headers, $body, $on_token) {
        if (!function_exists('curl_init')) {
            return new WP_Error('curl_missing', 'PHP cURL extension is required for streaming.');
        }
        $aggregate = '';
        $sse_buffer = '';
        $stream_done = false;

        $ch = curl_init($endpoint);
        curl_setopt_array($ch, array(
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => wp_json_encode($body),
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_TIMEOUT        => isset($this->config['timeout']) ? (int) $this->config['timeout'] : 180,
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_WRITEFUNCTION  => function ($curl, $chunk) use (&$sse_buffer, &$stream_done, &$aggregate, $on_token) {
                $sse_buffer .= $chunk;
                while (false !== ($nl = strpos($sse_buffer, "\n"))) {
                    $line = trim(substr($sse_buffer, 0, $nl));
                    $sse_buffer = substr($sse_buffer, $nl + 1);
                    if ('' === $line || 0 !== strpos($line, 'data:')) continue;
                    $payload = trim(substr($line, 5));
                    if ('[DONE]' === $payload) {
                        if (is_callable($on_token)) call_user_func($on_token, '', true);
                        $stream_done = true;
                        return 0;
                    }
                    $obj = json_decode($payload, true);
                    if (!is_array($obj)) continue;
                    $token = '';
                    if (isset($obj['choices'][0]['delta']['content'])) {
                        $token = (string) $obj['choices'][0]['delta']['content'];
                    } elseif (isset($obj['choices'][0]['message']['content'])) {
                        $token = (string) $obj['choices'][0]['message']['content'];
                    }
                    $finish = isset($obj['choices'][0]['finish_reason']) ? $obj['choices'][0]['finish_reason'] : null;
                    $done = !empty($finish);
                    if ('' !== $token) {
                        $aggregate .= $token;
                        if (is_callable($on_token)) call_user_func($on_token, $token, false);
                    }
                    if ($done) {
                        if (is_callable($on_token)) call_user_func($on_token, '', true);
                        $stream_done = true;
                        return 0;
                    }
                }
                return strlen($chunk);
            },
        ));
        curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        if (!$stream_done) {
            if ($err) return new WP_Error('stream_error', $err);
            if (is_callable($on_token)) call_user_func($on_token, '', true);
        }
        return array(
            'content'    => $aggregate,
            'tokens_in'  => 0,
            'tokens_out' => max(1, (int) round(str_word_count($aggregate) * 1.33)),
            'model'      => isset($body['model']) ? (string) $body['model'] : $this->default_model(),
        );
    }
}
