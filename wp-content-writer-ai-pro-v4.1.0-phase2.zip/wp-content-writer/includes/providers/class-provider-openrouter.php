<?php
/**
 * OpenRouter provider — OpenAI-compatible aggregator giving access to
 * 200+ models behind one API key.
 */

if (!defined('ABSPATH')) exit;

class WPCW_Provider_OpenRouter extends WPCW_Provider_Base {

    public function id()    { return 'openrouter'; }
    public function label() { return 'OpenRouter'; }

    public function models() {
        return array(
            'openai/gpt-4o-mini',
            'openai/gpt-4o',
            'anthropic/claude-3.5-sonnet',
            'anthropic/claude-3.5-haiku',
            'google/gemini-2.0-flash-001',
            'meta-llama/llama-3.3-70b-instruct',
            'mistralai/mistral-large',
            'deepseek/deepseek-chat',
            'qwen/qwen-2.5-72b-instruct',
            'x-ai/grok-2-1212',
        );
    }

    public function default_model() { return 'openai/gpt-4o-mini'; }

    private function base_url() {
        $base = (string) $this->get_config('base_url');
        if ('' === $base) $base = 'https://openrouter.ai/api/v1';
        return rtrim($base, '/');
    }

    private function headers($accept = 'application/json') {
        $h = array(
            'Content-Type'  => 'application/json',
            'Accept'        => $accept,
            'Authorization' => 'Bearer ' . (string) $this->get_config('api_key'),
            'HTTP-Referer'  => home_url(),
            'X-Title'       => 'WP Content Writer AI Pro',
        );
        return $h;
    }

    public function chat(array $messages, array $options = array()) {
        if ('' === (string) $this->get_config('api_key')) {
            return new WP_Error('missing_key', 'OpenRouter API key not configured.');
        }
        $body = array(
            'model'       => isset($options['model']) ? $options['model'] : $this->default_model(),
            'messages'    => $messages,
            'stream'      => false,
            'temperature' => isset($options['temperature']) ? (float) $options['temperature'] : 0.7,
            'max_tokens'  => isset($options['max_tokens']) ? (int) $options['max_tokens'] : 4096,
        );
        $r = wp_remote_post($this->base_url() . '/chat/completions', array(
            'timeout' => isset($this->config['timeout']) ? (int) $this->config['timeout'] : 180,
            'headers' => $this->headers(),
            'body'    => wp_json_encode($body),
        ));
        if (is_wp_error($r)) return $r;
        $data = json_decode(wp_remote_retrieve_body($r), true);
        $code = (int) wp_remote_retrieve_response_code($r);
        $content = $this->extract_openai_content($data);
        if (200 !== $code || null === $content) {
            $msg = isset($data['error']['message']) ? $data['error']['message'] : ('OpenRouter API error (HTTP ' . $code . ').');
            return new WP_Error('openrouter_error', $msg);
        }
        return array(
            'content'    => $content,
            'tokens_in'  => isset($data['usage']['prompt_tokens']) ? (int) $data['usage']['prompt_tokens'] : 0,
            'tokens_out' => isset($data['usage']['completion_tokens']) ? (int) $data['usage']['completion_tokens'] : 0,
            'model'      => $body['model'],
        );
    }

    public function chat_stream(array $messages, array $options, $on_token) {
        if ('' === (string) $this->get_config('api_key')) {
            return new WP_Error('missing_key', 'OpenRouter API key not configured.');
        }
        $body = array(
            'model'       => isset($options['model']) ? $options['model'] : $this->default_model(),
            'messages'    => $messages,
            'stream'      => true,
            'temperature' => isset($options['temperature']) ? (float) $options['temperature'] : 0.7,
            'max_tokens'  => isset($options['max_tokens']) ? (int) $options['max_tokens'] : 4096,
        );
        $headers = array(
            'Content-Type: application/json',
            'Accept: text/event-stream',
            'Authorization: Bearer ' . (string) $this->get_config('api_key'),
            'HTTP-Referer: ' . home_url(),
            'X-Title: WP Content Writer AI Pro',
        );
        return $this->stream_openai_compatible($this->base_url() . '/chat/completions', $headers, $body, $on_token);
    }

    public function estimate_cost($tokens_in, $tokens_out, $model = '') {
        // OpenRouter passes through vendor pricing — use a conservative average.
        return ($tokens_in / 1e6) * 1.0 + ($tokens_out / 1e6) * 3.0;
    }
}
