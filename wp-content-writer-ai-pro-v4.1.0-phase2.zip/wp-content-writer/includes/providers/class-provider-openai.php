<?php
/**
 * OpenAI provider.
 */

if (!defined('ABSPATH')) exit;

class WPCW_Provider_OpenAI extends WPCW_Provider_Base {

    public function id()    { return 'openai'; }
    public function label() { return 'OpenAI'; }

    public function models() {
        return array(
            'gpt-4o',
            'gpt-4o-mini',
            'gpt-4-turbo',
            'gpt-4',
            'gpt-3.5-turbo',
            'o1-preview',
            'o1-mini',
            'o3-mini',
        );
    }

    public function default_model() { return 'gpt-4o-mini'; }

    private function base_url() {
        $base = (string) $this->get_config('base_url');
        if ('' === $base) $base = 'https://api.openai.com/v1';
        return rtrim($base, '/');
    }

    public function chat(array $messages, array $options = array()) {
        if ('' === (string) $this->get_config('api_key')) {
            return new WP_Error('missing_key', 'OpenAI API key not configured.');
        }
        $body = array(
            'model'       => isset($options['model']) ? $options['model'] : $this->default_model(),
            'messages'    => $messages,
            'stream'      => false,
            'temperature' => isset($options['temperature']) ? (float) $options['temperature'] : 0.7,
            'max_tokens'  => isset($options['max_tokens']) ? (int) $options['max_tokens'] : 4096,
        );
        $r = wp_remote_post($this->base_url() . '/chat/completions', array(
            'timeout' => isset($this->config['timeout']) ? (int) $this->config['timeout'] : 180,
            'headers' => array(
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . (string) $this->get_config('api_key'),
            ),
            'body'    => wp_json_encode($body),
        ));
        if (is_wp_error($r)) return $r;
        $data = json_decode(wp_remote_retrieve_body($r), true);
        $code = (int) wp_remote_retrieve_response_code($r);
        $content = $this->extract_openai_content($data);
        if (200 !== $code || null === $content) {
            $msg = isset($data['error']['message']) ? $data['error']['message'] : ('OpenAI API error (HTTP ' . $code . ').');
            return new WP_Error('openai_error', $msg);
        }
        return array(
            'content'    => $content,
            'tokens_in'  => isset($data['usage']['prompt_tokens']) ? (int) $data['usage']['prompt_tokens'] : 0,
            'tokens_out' => isset($data['usage']['completion_tokens']) ? (int) $data['usage']['completion_tokens'] : 0,
            'model'      => $body['model'],
        );
    }

    public function chat_stream(array $messages, array $options, $on_token) {
        if ('' === (string) $this->get_config('api_key')) {
            return new WP_Error('missing_key', 'OpenAI API key not configured.');
        }
        $body = array(
            'model'       => isset($options['model']) ? $options['model'] : $this->default_model(),
            'messages'    => $messages,
            'stream'      => true,
            'temperature' => isset($options['temperature']) ? (float) $options['temperature'] : 0.7,
            'max_tokens'  => isset($options['max_tokens']) ? (int) $options['max_tokens'] : 4096,
        );
        $headers = array(
            'Content-Type: application/json',
            'Accept: text/event-stream',
            'Authorization: Bearer ' . (string) $this->get_config('api_key'),
        );
        return $this->stream_openai_compatible($this->base_url() . '/chat/completions', $headers, $body, $on_token);
    }

    public function estimate_cost($tokens_in, $tokens_out, $model = '') {
        $rates = array(
            'gpt-4o'        => array(2.50, 10.00),
            'gpt-4o-mini'   => array(0.15, 0.60),
            'gpt-4-turbo'   => array(10.00, 30.00),
            'gpt-4'         => array(30.00, 60.00),
            'gpt-3.5-turbo' => array(0.50, 1.50),
            'o1-preview'    => array(15.00, 60.00),
            'o1-mini'       => array(3.00, 12.00),
            'o3-mini'       => array(1.10, 4.40),
        );
        $rate = isset($rates[$model]) ? $rates[$model] : array(1.0, 2.0);
        return ($tokens_in / 1e6) * $rate[0] + ($tokens_out / 1e6) * $rate[1];
    }
}
