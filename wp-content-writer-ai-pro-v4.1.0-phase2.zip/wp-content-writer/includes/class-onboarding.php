<?php
/**
 * First-run onboarding wizard. Detects when no provider is configured and
 * a user with manage_options visits any plugin admin page, then nudges
 * them to the wizard. Provides a 3-step flow: provider key, license, defaults.
 */

if (!defined('ABSPATH')) exit;

class WPCW_Onboarding {

    const OPTION_DONE = 'wpcw_onboarding_complete';

    public static function is_complete() {
        return (bool) get_option(self::OPTION_DONE, false);
    }

    public static function mark_complete() {
        update_option(self::OPTION_DONE, time(), false);
    }

    public static function reset() {
        delete_option(self::OPTION_DONE);
    }

    /**
     * Whether the wizard should auto-redirect a fresh admin to the
     * onboarding screen. Returns true only on the plugin's own pages
     * to avoid hijacking unrelated screens.
     */
    public static function should_show_notice() {
        if (self::is_complete()) return false;
        if (!is_admin()) return false;
        if (!current_user_can('manage_options')) return false;
        $manager = new WPCW_Provider_Manager();
        $data = $manager->get_settings_data();
        $active_cfg = isset($data['configs'][$data['active']]) ? $data['configs'][$data['active']] : array();
        // Only show notice when there is genuinely no key configured.
        return empty($active_cfg['api_key']);
    }

    public static function render_notice() {
        if (!self::should_show_notice()) return;
        $url = admin_url('admin.php?page=wp-content-writer-onboarding');
        ?>
        <div class="notice notice-warning is-dismissible">
            <p>
                <strong>WP Content Writer AI Pro</strong> —
                <?php esc_html_e('Setup is incomplete. Add your AI provider API key to start generating content.', 'wp-content-writer'); ?>
                <a class="button button-primary" style="margin-left:8px;" href="<?php echo esc_url($url); ?>">
                    <?php esc_html_e('Run setup wizard', 'wp-content-writer'); ?>
                </a>
            </p>
        </div>
        <?php
    }
}
