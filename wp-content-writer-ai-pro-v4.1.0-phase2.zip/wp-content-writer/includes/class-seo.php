<?php
/**
 * SEO & Rank Math Integration — WP Content Writer AI Pro
 * Handles Rank Math score optimization, schema markup, and SEO analysis
 */

if (!defined('ABSPATH')) exit;

class WPCW_SEO {

    /**
     * Check if Rank Math plugin is active
     */
    public static function is_rankmath_active() {
        return class_exists('RankMath') || defined('RANK_MATH_VERSION');
    }

    /**
     * Check if Yoast SEO plugin is active
     */
    public static function is_yoast_active() {
        return defined('WPSEO_VERSION');
    }

    /**
     * Get active SEO plugin name
     */
    public static function get_active_seo_plugin() {
        if (self::is_rankmath_active()) return 'rankmath';
        if (self::is_yoast_active()) return 'yoast';
        return 'none';
    }

    /**
     * Set Rank Math SEO meta for a post
     */
    public static function set_rankmath_meta($post_id, $meta) {
        if (!self::is_rankmath_active()) return false;

        $fields = array(
            'focus_keyword'    => 'rank_math_focus_keyword',
            'seo_title'        => 'rank_math_title',
            'seo_description'  => 'rank_math_description',
            'canonical_url'    => 'rank_math_canonical_url',
            'schema_type'      => 'rank_math_rich_snippet',
            'breadcrumb_title' => 'rank_math_breadcrumb_title',
            'og_title'         => 'rank_math_facebook_title',
            'og_description'   => 'rank_math_facebook_description',
            'og_image'         => 'rank_math_facebook_image',
            'twitter_title'    => 'rank_math_twitter_title',
            'twitter_description' => 'rank_math_twitter_description',
            'robots_index'     => 'rank_math_robots',
        );

        foreach ($fields as $key => $meta_key) {
            if (isset($meta[$key]) && '' !== $meta[$key]) {
                update_post_meta($post_id, $meta_key, sanitize_text_field($meta[$key]));
            }
        }

        return true;
    }

    /**
     * Set Yoast SEO meta for a post
     */
    public static function set_yoast_meta($post_id, $meta) {
        if (!self::is_yoast_active()) return false;

        $fields = array(
            'focus_keyword'    => '_yoast_wpseo_focuskw',
            'seo_title'        => '_yoast_wpseo_title',
            'seo_description'  => '_yoast_wpseo_metadesc',
            'canonical_url'    => '_yoast_wpseo_canonical',
            'og_title'         => '_yoast_wpseo_opengraph-title',
            'og_description'   => '_yoast_wpseo_opengraph-description',
            'og_image'         => '_yoast_wpseo_opengraph-image',
            'twitter_title'    => '_yoast_wpseo_twitter-title',
            'twitter_description' => '_yoast_wpseo_twitter-description',
        );

        foreach ($fields as $key => $meta_key) {
            if (isset($meta[$key]) && '' !== $meta[$key]) {
                update_post_meta($post_id, $meta_key, sanitize_text_field($meta[$key]));
            }
        }

        return true;
    }

    /**
     * Set SEO meta using whichever plugin is active
     */
    public static function set_seo_meta($post_id, $meta) {
        $plugin = self::get_active_seo_plugin();
        if ('rankmath' === $plugin) {
            return self::set_rankmath_meta($post_id, $meta);
        } elseif ('yoast' === $plugin) {
            return self::set_yoast_meta($post_id, $meta);
        }
        return false;
    }

    /**
     * Analyze content for SEO score (Rank Math style)
     */
    public static function analyze_content($content, $keyword, $title = '', $description = '', $url = '') {
        $score  = 0;
        $checks = array();
        $max_score = 100;
        $content_lower = strtolower($content);
        $keyword_lower = strtolower($keyword);

        // 1. Focus keyword in title (max 10)
        if ('' !== $title) {
            if (stripos($title, $keyword) !== false) {
                $score += 10;
                $checks['title_keyword'] = array('status' => 'pass', 'message' => 'Focus keyword found in SEO title', 'points' => 10);
            } else {
                $checks['title_keyword'] = array('status' => 'fail', 'message' => 'Add focus keyword to SEO title', 'points' => 0);
            }
        }

        // 2. Focus keyword at beginning of title (max 5)
        if ('' !== $title) {
            $title_lower = strtolower($title);
            if (strpos($title_lower, $keyword_lower) !== false && strpos($title_lower, $keyword_lower) < (strlen($title_lower) / 3)) {
                $score += 5;
                $checks['title_keyword_begin'] = array('status' => 'pass', 'message' => 'Focus keyword appears near the beginning of SEO title', 'points' => 5);
            } else {
                $checks['title_keyword_begin'] = array('status' => 'warn', 'message' => 'Move focus keyword closer to the beginning of SEO title', 'points' => 0);
            }
        }

        // 3. Focus keyword in meta description (max 10)
        if ('' !== $description) {
            if (stripos($description, $keyword) !== false) {
                $score += 10;
                $checks['desc_keyword'] = array('status' => 'pass', 'message' => 'Focus keyword found in meta description', 'points' => 10);
            } else {
                $checks['desc_keyword'] = array('status' => 'fail', 'message' => 'Add focus keyword to meta description', 'points' => 0);
            }
        }

        // 4. Meta description length (max 5)
        if ('' !== $description) {
            $desc_len = strlen($description);
            if ($desc_len >= 120 && $desc_len <= 160) {
                $score += 5;
                $checks['desc_length'] = array('status' => 'pass', 'message' => 'Meta description length is optimal (' . $desc_len . ' chars)', 'points' => 5);
            } else {
                $checks['desc_length'] = array('status' => 'warn', 'message' => 'Meta description should be 120-160 characters (currently ' . $desc_len . ')', 'points' => 0);
            }
        }

        // 5. Focus keyword in URL (max 5)
        if ('' !== $url) {
            if (stripos($url, str_replace(' ', '-', $keyword_lower)) !== false || stripos($url, str_replace(' ', '', $keyword_lower)) !== false) {
                $score += 5;
                $checks['url_keyword'] = array('status' => 'pass', 'message' => 'Focus keyword found in URL', 'points' => 5);
            } else {
                $checks['url_keyword'] = array('status' => 'warn', 'message' => 'Include focus keyword in URL slug', 'points' => 0);
            }
        }

        // 6. Content length (max 10)
        $word_count = str_word_count($content);
        if ($word_count >= 1500) {
            $score += 10;
            $checks['content_length'] = array('status' => 'pass', 'message' => 'Great content length: ' . $word_count . ' words', 'points' => 10);
        } elseif ($word_count >= 600) {
            $score += 5;
            $checks['content_length'] = array('status' => 'warn', 'message' => 'Content length is okay (' . $word_count . ' words). Aim for 1500+', 'points' => 5);
        } else {
            $checks['content_length'] = array('status' => 'fail', 'message' => 'Content too short (' . $word_count . ' words). Minimum 600 recommended', 'points' => 0);
        }

        // 7. Keyword in first 10% of content (max 5)
        $first_10_percent = substr($content_lower, 0, (int) (strlen($content_lower) * 0.1));
        if (strpos($first_10_percent, $keyword_lower) !== false) {
            $score += 5;
            $checks['keyword_intro'] = array('status' => 'pass', 'message' => 'Focus keyword found in the introduction', 'points' => 5);
        } else {
            $checks['keyword_intro'] = array('status' => 'fail', 'message' => 'Add focus keyword in the first 10% of content', 'points' => 0);
        }

        // 8. Keyword density (max 10)
        $keyword_count = substr_count($content_lower, $keyword_lower);
        $density = ($word_count > 0) ? ($keyword_count / $word_count) * 100 : 0;
        if ($density >= 0.5 && $density <= 2.5) {
            $score += 10;
            $checks['keyword_density'] = array('status' => 'pass', 'message' => 'Keyword density is optimal: ' . round($density, 2) . '%', 'points' => 10);
        } elseif ($density > 0 && $density < 0.5) {
            $score += 3;
            $checks['keyword_density'] = array('status' => 'warn', 'message' => 'Keyword density too low: ' . round($density, 2) . '%. Aim for 1-2%', 'points' => 3);
        } elseif ($density > 2.5) {
            $score += 2;
            $checks['keyword_density'] = array('status' => 'warn', 'message' => 'Keyword density too high: ' . round($density, 2) . '%. Reduce to 1-2%', 'points' => 2);
        } else {
            $checks['keyword_density'] = array('status' => 'fail', 'message' => 'Focus keyword not found in content', 'points' => 0);
        }

        // 9. Headings present (max 5)
        $has_h2 = (bool) preg_match('/<h2|^##\s/mi', $content);
        $has_h3 = (bool) preg_match('/<h3|^###\s/mi', $content);
        if ($has_h2 && $has_h3) {
            $score += 5;
            $checks['headings'] = array('status' => 'pass', 'message' => 'Content has proper heading structure (H2 + H3)', 'points' => 5);
        } elseif ($has_h2) {
            $score += 3;
            $checks['headings'] = array('status' => 'warn', 'message' => 'Add H3 subheadings for better structure', 'points' => 3);
        } else {
            $checks['headings'] = array('status' => 'fail', 'message' => 'Add H2 and H3 headings to structure content', 'points' => 0);
        }

        // 10. Keyword in subheadings (max 5)
        if (preg_match_all('/<h[23][^>]*>(.*?)<\/h[23]>|^#{2,3}\s+(.+)/mi', $content, $heading_matches)) {
            $headings_text = implode(' ', array_merge($heading_matches[1], $heading_matches[2]));
            if (stripos($headings_text, $keyword) !== false) {
                $score += 5;
                $checks['heading_keyword'] = array('status' => 'pass', 'message' => 'Focus keyword found in subheading', 'points' => 5);
            } else {
                $checks['heading_keyword'] = array('status' => 'warn', 'message' => 'Add focus keyword to at least one H2/H3', 'points' => 0);
            }
        }

        // 11. Internal links (max 5)
        $internal_links = preg_match_all('/\[.*?\]\(.*?\)|<a\s/i', $content);
        if ($internal_links >= 2) {
            $score += 5;
            $checks['internal_links'] = array('status' => 'pass', 'message' => 'Content has ' . $internal_links . ' link references', 'points' => 5);
        } elseif ($internal_links >= 1) {
            $score += 3;
            $checks['internal_links'] = array('status' => 'warn', 'message' => 'Add more internal links (at least 2 recommended)', 'points' => 3);
        } else {
            $checks['internal_links'] = array('status' => 'fail', 'message' => 'Add internal links to related content', 'points' => 0);
        }

        // 12. Images / alt text references (max 5)
        $has_images = preg_match('/!\[.*?\]|<img|image|photo|screenshot|infographic/i', $content);
        if ($has_images) {
            $score += 5;
            $checks['images'] = array('status' => 'pass', 'message' => 'Content references images/media', 'points' => 5);
        } else {
            $checks['images'] = array('status' => 'warn', 'message' => 'Add images with alt text containing focus keyword', 'points' => 0);
        }

        // 13. Title length (max 5)
        if ('' !== $title) {
            $title_len = strlen($title);
            if ($title_len >= 30 && $title_len <= 65) {
                $score += 5;
                $checks['title_length'] = array('status' => 'pass', 'message' => 'SEO title length is optimal (' . $title_len . ' chars)', 'points' => 5);
            } else {
                $checks['title_length'] = array('status' => 'warn', 'message' => 'SEO title should be 30-65 characters (currently ' . $title_len . ')', 'points' => 0);
            }
        }

        // 14. Paragraphs not too long (max 5)
        $paragraphs = preg_split('/\n\n|\r\n\r\n/', $content);
        $long_paras = 0;
        foreach ($paragraphs as $p) {
            if (str_word_count($p) > 150) $long_paras++;
        }
        if ($long_paras === 0) {
            $score += 5;
            $checks['paragraph_length'] = array('status' => 'pass', 'message' => 'Good paragraph lengths for readability', 'points' => 5);
        } else {
            $checks['paragraph_length'] = array('status' => 'warn', 'message' => $long_paras . ' paragraphs are too long. Break them up', 'points' => 2);
            $score += 2;
        }

        // Cap at max
        $score = min($score, $max_score);

        // Rating
        if ($score >= 80) {
            $rating = 'excellent';
        } elseif ($score >= 60) {
            $rating = 'good';
        } elseif ($score >= 40) {
            $rating = 'needs_work';
        } else {
            $rating = 'poor';
        }

        return array(
            'score'      => $score,
            'max_score'  => $max_score,
            'rating'     => $rating,
            'checks'     => $checks,
            'word_count' => $word_count,
            'keyword_count'   => $keyword_count,
            'keyword_density' => round($density, 2),
        );
    }

    /**
     * Generate SEO-optimized slug from title and keyword
     */
    public static function generate_slug($title, $keyword = '') {
        $slug = sanitize_title($keyword ? $keyword : $title);
        $slug = substr($slug, 0, 60);
        return $slug;
    }

    /**
     * Get Rank Math checklist for 100% score
     */
    public static function get_rankmath_checklist() {
        return array(
            'basic' => array(
                'Focus keyword in SEO title',
                'Focus keyword in meta description',
                'Focus keyword in URL',
                'Focus keyword in the first 10% of content',
                'Content is at least 600 words',
                'Focus keyword found in subheading (H2/H3)',
                'Use focus keyword in image alt text',
                'Keyword density between 1-1.5%',
            ),
            'additional' => array(
                'SEO title contains a power word',
                'SEO title contains a number',
                'Meta description under 156 characters',
                'URL is less than 75 characters',
                'Content has table of contents',
                'Internal links present (at least 1)',
                'External links present (at least 1)',
                'Focus keyword used in at least one image alt text',
            ),
            'title_readability' => array(
                'Title is not too long (under 60 characters)',
                'Title uses a positive or negative sentiment word',
                'Title contains the focus keyword at the beginning',
            ),
            'content_readability' => array(
                'Content uses short paragraphs',
                'Content uses subheadings (H2, H3)',
                'Images/media added to the content',
                'Content is easy to read (short sentences)',
            ),
        );
    }

    /**
     * Generate FAQ schema JSON-LD
     */
    public static function generate_faq_schema($faqs) {
        if (!is_array($faqs) || empty($faqs)) return '';

        $items = array();
        foreach ($faqs as $faq) {
            if (empty($faq['question']) || empty($faq['answer'])) continue;
            $items[] = array(
                '@type'          => 'Question',
                'name'           => $faq['question'],
                'acceptedAnswer' => array(
                    '@type' => 'Answer',
                    'text'  => $faq['answer'],
                ),
            );
        }

        $schema = array(
            '@context'   => 'https://schema.org',
            '@type'      => 'FAQPage',
            'mainEntity' => $items,
        );

        return wp_json_encode($schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    /**
     * Generate Article schema JSON-LD
     */
    public static function generate_article_schema($data) {
        $schema = array(
            '@context'      => 'https://schema.org',
            '@type'         => isset($data['type']) ? $data['type'] : 'Article',
            'headline'      => isset($data['title']) ? $data['title'] : '',
            'description'   => isset($data['description']) ? $data['description'] : '',
            'author'        => array(
                '@type' => 'Person',
                'name'  => isset($data['author']) ? $data['author'] : get_the_author_meta('display_name', get_current_user_id()),
            ),
            'datePublished' => isset($data['date']) ? $data['date'] : current_time('c'),
            'dateModified'  => current_time('c'),
        );

        if (isset($data['image'])) {
            $schema['image'] = $data['image'];
        }

        if (isset($data['publisher'])) {
            $schema['publisher'] = array(
                '@type' => 'Organization',
                'name'  => $data['publisher'],
            );
        }

        return wp_json_encode($schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
