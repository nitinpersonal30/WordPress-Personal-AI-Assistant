<?php
/**
 * Editorial approval workflow — Phase 2.2.
 *
 * Adds a Draft → In Review → Approved → Published lifecycle on top of
 * the standard WP post statuses without breaking core editor behaviour.
 *
 * Storage:
 *   - meta `_wpcw_workflow_state`     : draft|review|approved|rejected|published
 *   - meta `_wpcw_workflow_assignee`  : reviewer user id (optional)
 *   - meta `_wpcw_workflow_history`   : array of {actor, from, to, note, ts}
 *   - meta `_wpcw_workflow_comments`  : array of {actor, body, ts}
 *
 * The plugin also registers an internal `wpcw_review` post status so
 * editors can filter the post list to in-review items easily.
 */

if (!defined('ABSPATH')) exit;

class WPCW_Workflow {

    const META_STATE     = '_wpcw_workflow_state';
    const META_ASSIGNEE  = '_wpcw_workflow_assignee';
    const META_HISTORY   = '_wpcw_workflow_history';
    const META_COMMENTS  = '_wpcw_workflow_comments';

    const STATE_DRAFT     = 'draft';
    const STATE_REVIEW    = 'review';
    const STATE_APPROVED  = 'approved';
    const STATE_REJECTED  = 'rejected';
    const STATE_PUBLISHED = 'published';

    public static function bootstrap() {
        add_action('init', array(__CLASS__, 'register_post_status'));
    }

    public static function register_post_status() {
        register_post_status('wpcw_review', array(
            'label'                     => _x('In Review', 'post status', 'wp-content-writer'),
            'public'                    => false,
            'exclude_from_search'       => true,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            // translators: %s = number of items in review.
            'label_count'               => _n_noop('In Review <span class="count">(%s)</span>', 'In Review <span class="count">(%s)</span>', 'wp-content-writer'),
        ));
    }

    public static function states() {
        return array(
            self::STATE_DRAFT     => 'Draft',
            self::STATE_REVIEW    => 'In Review',
            self::STATE_APPROVED  => 'Approved',
            self::STATE_REJECTED  => 'Rejected',
            self::STATE_PUBLISHED => 'Published',
        );
    }

    public static function get_state($post_id) {
        $state = get_post_meta((int) $post_id, self::META_STATE, true);
        if (!$state) {
            $post = get_post($post_id);
            if ($post && 'publish' === $post->post_status) return self::STATE_PUBLISHED;
            return self::STATE_DRAFT;
        }
        return $state;
    }

    /**
     * Allowed transitions per state. A user must additionally hold the
     * required wpcw_* capability for the transition to succeed.
     */
    public static function allowed_transitions($state) {
        $map = array(
            self::STATE_DRAFT => array(
                self::STATE_REVIEW    => 'wpcw_submit_review',
            ),
            self::STATE_REVIEW => array(
                self::STATE_APPROVED  => 'wpcw_approve',
                self::STATE_REJECTED  => 'wpcw_approve',
                self::STATE_DRAFT     => 'wpcw_save_draft',
            ),
            self::STATE_APPROVED => array(
                self::STATE_PUBLISHED => 'wpcw_publish',
                self::STATE_DRAFT     => 'wpcw_save_draft',
            ),
            self::STATE_REJECTED => array(
                self::STATE_DRAFT     => 'wpcw_save_draft',
                self::STATE_REVIEW    => 'wpcw_submit_review',
            ),
            self::STATE_PUBLISHED => array(
                self::STATE_DRAFT     => 'wpcw_save_draft',
            ),
        );
        return isset($map[$state]) ? $map[$state] : array();
    }

    public static function can_transition($post_id, $target_state, $user_id = 0) {
        $current = self::get_state($post_id);
        $allowed = self::allowed_transitions($current);
        if (!isset($allowed[$target_state])) {
            return new WP_Error('bad_transition', sprintf('Cannot move %s → %s.', $current, $target_state));
        }
        $cap = $allowed[$target_state];
        if ($user_id <= 0) $user_id = get_current_user_id();
        if (!user_can($user_id, $cap)) {
            return new WP_Error('forbidden', sprintf('Missing capability: %s.', $cap));
        }
        return true;
    }

    public static function transition($post_id, $target_state, $note = '', $user_id = 0) {
        $post_id = (int) $post_id;
        $post    = get_post($post_id);
        if (!$post) return new WP_Error('not_found', 'Post not found.');
        $check = self::can_transition($post_id, $target_state, $user_id);
        if (is_wp_error($check)) return $check;

        $current = self::get_state($post_id);
        if ($user_id <= 0) $user_id = get_current_user_id();

        update_post_meta($post_id, self::META_STATE, $target_state);
        self::push_history($post_id, $current, $target_state, $note, $user_id);

        if (self::STATE_PUBLISHED === $target_state) {
            wp_update_post(array('ID' => $post_id, 'post_status' => 'publish'));
        } elseif (self::STATE_REVIEW === $target_state) {
            // Use core "pending" so the post list shows it in the
            // standard pending bucket too.
            wp_update_post(array('ID' => $post_id, 'post_status' => 'pending'));
        } elseif (self::STATE_APPROVED === $target_state) {
            wp_update_post(array('ID' => $post_id, 'post_status' => 'pending'));
        } elseif (in_array($target_state, array(self::STATE_DRAFT, self::STATE_REJECTED), true)) {
            wp_update_post(array('ID' => $post_id, 'post_status' => 'draft'));
        }

        if (class_exists('WPCW_Activity_Log')) {
            WPCW_Activity_Log::log('workflow.' . $target_state, array(
                'object_type' => 'post',
                'object_id'   => $post_id,
                'message'     => sprintf('Workflow: %s → %s', $current, $target_state),
                'meta'        => array('from' => $current, 'to' => $target_state, 'note' => $note),
            ));
        }
        do_action('wpcw_workflow_transition', $post_id, $current, $target_state, $note, $user_id);
        return self::get_state($post_id);
    }

    public static function assign_reviewer($post_id, $reviewer_id) {
        $reviewer_id = (int) $reviewer_id;
        if ($reviewer_id <= 0) {
            delete_post_meta($post_id, self::META_ASSIGNEE);
            return true;
        }
        $u = get_user_by('id', $reviewer_id);
        if (!$u) return new WP_Error('bad_user', 'Invalid reviewer.');
        if (!user_can($reviewer_id, 'wpcw_approve')) {
            return new WP_Error('forbidden', 'User cannot approve content.');
        }
        update_post_meta($post_id, self::META_ASSIGNEE, $reviewer_id);
        if (class_exists('WPCW_Activity_Log')) {
            WPCW_Activity_Log::log('workflow.assigned', array(
                'object_type' => 'post',
                'object_id'   => (int) $post_id,
                'message'     => sprintf('Reviewer assigned: %s', $u->display_name),
                'meta'        => array('reviewer' => $reviewer_id),
            ));
        }
        return true;
    }

    public static function get_assignee($post_id) {
        return (int) get_post_meta((int) $post_id, self::META_ASSIGNEE, true);
    }

    public static function add_comment($post_id, $body, $user_id = 0) {
        $body = trim((string) $body);
        if ('' === $body) return new WP_Error('empty', 'Comment cannot be empty.');
        if ($user_id <= 0) $user_id = get_current_user_id();
        $comments = self::get_comments($post_id);
        $comments[] = array(
            'id'    => uniqid('wf_', false),
            'actor' => (int) $user_id,
            'body'  => substr($body, 0, 4000),
            'ts'    => time(),
        );
        update_post_meta($post_id, self::META_COMMENTS, $comments);
        if (class_exists('WPCW_Activity_Log')) {
            WPCW_Activity_Log::log('workflow.comment', array(
                'object_type' => 'post',
                'object_id'   => (int) $post_id,
                'message'     => 'Review comment added',
            ));
        }
        return end($comments);
    }

    public static function get_comments($post_id) {
        $c = get_post_meta((int) $post_id, self::META_COMMENTS, true);
        return is_array($c) ? $c : array();
    }

    public static function get_history($post_id) {
        $h = get_post_meta((int) $post_id, self::META_HISTORY, true);
        return is_array($h) ? $h : array();
    }

    private static function push_history($post_id, $from, $to, $note, $user_id) {
        $hist = self::get_history($post_id);
        $hist[] = array(
            'actor' => (int) $user_id,
            'from'  => $from,
            'to'    => $to,
            'note'  => substr((string) $note, 0, 1000),
            'ts'    => time(),
        );
        update_post_meta($post_id, self::META_HISTORY, $hist);
    }

    /**
     * Formatted bundle for the REST review endpoint.
     */
    public static function get_full($post_id) {
        $post = get_post($post_id);
        if (!$post) return null;
        $state    = self::get_state($post_id);
        $reviewer = self::get_assignee($post_id);
        $rev      = $reviewer ? get_user_by('id', $reviewer) : null;
        $comments = array();
        foreach (self::get_comments($post_id) as $c) {
            $u = get_user_by('id', (int) $c['actor']);
            $comments[] = array(
                'id'         => $c['id'],
                'actor_id'   => (int) $c['actor'],
                'actor_name' => $u ? $u->display_name : 'Unknown',
                'body'       => $c['body'],
                'ts'         => (int) $c['ts'],
                'date'       => gmdate('c', (int) $c['ts']),
            );
        }
        $history = array();
        foreach (self::get_history($post_id) as $h) {
            $u = get_user_by('id', (int) $h['actor']);
            $history[] = array(
                'actor_id'   => (int) $h['actor'],
                'actor_name' => $u ? $u->display_name : 'System',
                'from'       => $h['from'],
                'to'         => $h['to'],
                'note'       => $h['note'],
                'ts'         => (int) $h['ts'],
                'date'       => gmdate('c', (int) $h['ts']),
            );
        }
        $allowed = array_keys(self::allowed_transitions($state));
        $available = array();
        foreach ($allowed as $target) {
            $check = self::can_transition($post_id, $target);
            if (!is_wp_error($check)) $available[] = $target;
        }
        return array(
            'post_id'      => (int) $post->ID,
            'title'        => $post->post_title,
            'edit_url'     => get_edit_post_link($post->ID, 'raw'),
            'view_url'     => get_permalink($post->ID),
            'author_id'    => (int) $post->post_author,
            'modified'     => $post->post_modified_gmt,
            'state'        => $state,
            'state_label'  => self::states()[$state] ?? $state,
            'reviewer_id'  => $reviewer,
            'reviewer'     => $rev ? array('id' => (int) $rev->ID, 'name' => $rev->display_name) : null,
            'comments'     => $comments,
            'history'      => $history,
            'transitions'  => $available,
        );
    }

    /**
     * Returns posts grouped by workflow state. Used by the "Review
     * Queue" admin page.
     */
    public static function queue($args = array()) {
        $defaults = array(
            'state'   => self::STATE_REVIEW,
            'assignee'=> 0,
            'per_page'=> 30,
            'page'    => 1,
        );
        $a = wp_parse_args($args, $defaults);

        $meta_query = array(array(
            'key'   => self::META_STATE,
            'value' => sanitize_key($a['state']),
        ));
        if (!empty($a['assignee'])) {
            $meta_query[] = array('key' => self::META_ASSIGNEE, 'value' => (int) $a['assignee']);
        }

        $q = new WP_Query(array(
            'post_type'      => array('post', 'page'),
            'post_status'    => array('draft', 'pending', 'publish'),
            'meta_query'     => $meta_query,
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'posts_per_page' => max(1, (int) $a['per_page']),
            'paged'          => max(1, (int) $a['page']),
        ));

        $items = array();
        foreach ($q->posts as $p) {
            $items[] = self::get_full($p->ID);
        }
        return array(
            'items' => $items,
            'total' => (int) $q->found_posts,
            'pages' => (int) $q->max_num_pages,
        );
    }

    public static function counts() {
        global $wpdb;
        $sql = $wpdb->prepare(
            "SELECT meta_value AS state, COUNT(*) AS n
               FROM {$wpdb->postmeta}
              WHERE meta_key = %s
              GROUP BY meta_value",
            self::META_STATE
        );
        $rows = $wpdb->get_results($sql, ARRAY_A);
        $out = array_fill_keys(array_keys(self::states()), 0);
        foreach ((array) $rows as $r) {
            $s = (string) $r['state'];
            if (isset($out[$s])) $out[$s] = (int) $r['n'];
        }
        return $out;
    }
}
