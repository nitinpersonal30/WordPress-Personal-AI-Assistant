<?php
/**
 * Brand voice profiles — Phase 2.4.
 *
 * Profiles are stored as a single option (`wpcw_brand_voices`) with the
 * shape: array<id, profile> where each profile has a name, description,
 * tone tags, sample text, do/don't lists, target reading level and a
 * cached AI-extracted style guide. Up to 25 profiles per workspace.
 *
 * The active profile is exposed to the AI generator via
 * self::system_prompt() which is concatenated onto the system message
 * in WPCW_API. Authors can also pass `brand_voice` per-request to
 * override the workspace default.
 */

if (!defined('ABSPATH')) exit;

class WPCW_Brand_Voice {

    const OPTION_KEY  = 'wpcw_brand_voices';
    const ACTIVE_KEY  = 'wpcw_brand_voices_active';
    const MAX_VOICES  = 25;
    const SAMPLE_MAX  = 12000; // characters per sample.

    public static function defaults() {
        return array(
            'id'           => '',
            'name'         => '',
            'description'  => '',
            'tone_tags'    => array(),
            'reading_level'=> 'general',
            'sample'       => '',
            'do_list'      => array(),
            'dont_list'    => array(),
            'guide'        => '', // AI-summarised style guide.
            'created_at'   => 0,
            'updated_at'   => 0,
        );
    }

    public static function get_all() {
        $rows = get_option(self::OPTION_KEY, array());
        if (!is_array($rows)) return array();
        $clean = array();
        foreach ($rows as $id => $row) {
            if (!is_array($row)) continue;
            $row['id'] = (string) $id;
            $clean[$id] = wp_parse_args($row, self::defaults());
        }
        return $clean;
    }

    public static function get($id) {
        $all = self::get_all();
        $id  = sanitize_key($id);
        return isset($all[$id]) ? $all[$id] : null;
    }

    public static function active_id() {
        return (string) get_option(self::ACTIVE_KEY, '');
    }

    public static function set_active($id) {
        $id = sanitize_key($id);
        if ('' === $id) {
            delete_option(self::ACTIVE_KEY);
            return true;
        }
        if (!self::get($id)) return new WP_Error('not_found', 'Brand voice not found.');
        update_option(self::ACTIVE_KEY, $id, false);
        return true;
    }

    public static function save($id, $data) {
        $all  = self::get_all();
        $id   = $id ? sanitize_key($id) : self::generate_id($data['name'] ?? 'voice');
        if (!isset($all[$id]) && count($all) >= self::MAX_VOICES) {
            return new WP_Error('limit', sprintf('Maximum %d brand voices reached.', self::MAX_VOICES));
        }
        $existing = isset($all[$id]) ? $all[$id] : self::defaults();

        $row = wp_parse_args(array(
            'id'            => $id,
            'name'          => isset($data['name'])         ? sanitize_text_field($data['name'])         : $existing['name'],
            'description'   => isset($data['description'])  ? sanitize_textarea_field($data['description']) : $existing['description'],
            'tone_tags'     => isset($data['tone_tags'])    ? self::sanitize_list($data['tone_tags'])     : $existing['tone_tags'],
            'reading_level' => isset($data['reading_level'])? sanitize_key($data['reading_level'])        : $existing['reading_level'],
            'sample'        => isset($data['sample'])       ? substr((string) $data['sample'], 0, self::SAMPLE_MAX) : $existing['sample'],
            'do_list'       => isset($data['do_list'])      ? self::sanitize_list($data['do_list'])       : $existing['do_list'],
            'dont_list'     => isset($data['dont_list'])    ? self::sanitize_list($data['dont_list'])     : $existing['dont_list'],
            'guide'         => isset($data['guide'])        ? sanitize_textarea_field($data['guide'])     : $existing['guide'],
            'created_at'    => $existing['created_at'] ?: time(),
            'updated_at'    => time(),
        ), self::defaults());

        if ('' === $row['name']) return new WP_Error('missing_name', 'Brand voice name is required.');

        $all[$id] = $row;
        update_option(self::OPTION_KEY, $all, false);

        if (class_exists('WPCW_Activity_Log')) {
            WPCW_Activity_Log::log('brand_voice.saved', array(
                'object_type' => 'brand_voice',
                'message'     => sprintf('Brand voice "%s" saved', $row['name']),
                'meta'        => array('id' => $id),
            ));
        }
        return $row;
    }

    public static function delete($id) {
        $all = self::get_all();
        $id  = sanitize_key($id);
        if (!isset($all[$id])) return new WP_Error('not_found', 'Brand voice not found.');
        unset($all[$id]);
        update_option(self::OPTION_KEY, $all, false);
        if (self::active_id() === $id) delete_option(self::ACTIVE_KEY);
        if (class_exists('WPCW_Activity_Log')) {
            WPCW_Activity_Log::log('brand_voice.deleted', array(
                'object_type' => 'brand_voice',
                'message'     => sprintf('Brand voice deleted (%s)', $id),
                'meta'        => array('id' => $id),
            ));
        }
        return true;
    }

    /**
     * Build a system-prompt fragment to append to the AI system message.
     * Caller may pass an override id, otherwise the active workspace
     * voice is used.
     */
    public static function system_prompt($override_id = '') {
        $id = $override_id ? sanitize_key($override_id) : self::active_id();
        if (!$id) return '';
        $voice = self::get($id);
        if (!$voice) return '';

        $parts = array();
        $parts[] = sprintf('Write in the brand voice "%s".', $voice['name']);
        if ($voice['description']) $parts[] = $voice['description'];
        if (!empty($voice['tone_tags'])) {
            $parts[] = 'Tone: ' . implode(', ', $voice['tone_tags']) . '.';
        }
        if ($voice['reading_level']) {
            $parts[] = 'Reading level: ' . $voice['reading_level'] . '.';
        }
        if (!empty($voice['do_list'])) {
            $parts[] = 'Always: ' . implode('; ', $voice['do_list']) . '.';
        }
        if (!empty($voice['dont_list'])) {
            $parts[] = 'Never: ' . implode('; ', $voice['dont_list']) . '.';
        }
        if ($voice['guide']) {
            $parts[] = "Style guide:\n" . $voice['guide'];
        }
        if ($voice['sample']) {
            // Trim sample to avoid blowing up the prompt budget.
            $sample = substr($voice['sample'], 0, 2000);
            $parts[] = "Mimic the style of this writing sample:\n\"\"\"\n{$sample}\n\"\"\"";
        }
        return implode("\n", $parts);
    }

    /**
     * Build a prompt for the AI to derive a concise style guide from a
     * raw sample. Returns the prompt string — callers run it through
     * the provider manager and store the result with self::save().
     */
    public static function analysis_prompt($sample) {
        $sample = substr((string) $sample, 0, self::SAMPLE_MAX);
        return "You are a professional brand voice analyst. Read the writing sample below and produce a concise (<= 200 words) style guide that captures: 1) Tone and personality, 2) Sentence rhythm and length, 3) Vocabulary preferences, 4) What this brand never does. Output as plain prose, no headings.\n\nSAMPLE:\n\"\"\"\n{$sample}\n\"\"\"";
    }

    private static function sanitize_list($list) {
        if (is_string($list)) $list = preg_split('/[\r\n,;]+/', $list);
        if (!is_array($list)) return array();
        $out = array();
        foreach ($list as $item) {
            $item = trim((string) $item);
            if ('' === $item) continue;
            $out[] = sanitize_text_field($item);
            if (count($out) >= 25) break;
        }
        return $out;
    }

    private static function generate_id($name) {
        $base = sanitize_key($name) ?: 'voice';
        $id   = $base;
        $all  = self::get_all();
        $i    = 1;
        while (isset($all[$id])) {
            $id = $base . '-' . (++$i);
            if ($i > 99) { $id = $base . '-' . wp_generate_password(6, false, false); break; }
        }
        return $id;
    }
}
